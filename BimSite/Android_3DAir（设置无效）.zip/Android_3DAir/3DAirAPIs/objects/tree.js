/**
 * Created by Administrator on 2016/10/18.
 */

var cfg={gap:10};
function makeTree(dom,conf){/*把一个dom 变成tree*/
    if(typeof(dom)=="string")	dom=document.getElementById(dom);
    for(var i=0;i<dom.childNodes.length;){
        var c=dom.childNodes[i];
        if(c.nodeType==3)	dom.removeChild(c);
        else 	i++;
    }
    var len=dom.children.length;
    for(var i=0;i<len;i++){
        var node=dom.children[i];
        var v=parseInt(node.v);
        node.v=v;
        node.c=0;
        if(v>1)	node.c=v-1;
        /*要压缩的级别 compress  第三级进入可视区域要把所有都压缩一级  第四级压缩两级  以此类推*/
        node.style.marginLeft=v*cfg.gap+"px";

        if(i>0&&dom.children[i-1].v==node.v-1){
            dom.children[i-1].className="node";
            dom.children[i-1].isNode=true;
            dom.children[i-1].onclick=nodeClick;
        }else if(i>0){
            dom.children[i-1].className="leaf";
        }

        if(i>0&&dom.children[i-1].v>1)	{
            cssAdd(dom.children[i-1],"hide");
        }/*默认只显示第一级别子节点*/
    }
    if(len>0){
        dom.children[len-1].className="leaf";
        if(dom.children[len-1].v>1) cssAdd(dom.children[len-1],"hide");
    }/*最后一个必定是叶节点*/
}

function nodeClick(evt){/*展示子节点*/
    var node=evt.target;
    if(node.v==undefined )return;

    var ifOpen=getOpen(node,"open");
    if(ifOpen){
        node.className="node";
        pickUP(node);
    }else {
        node.className="node open";
        open(node);
    }
}

function pickUP(node){

    var target=node,v=node.v,c=node.c;

    while(target!=null) {
        target = target.nextSibling;
        if(target==null || target.v==v) return;
        if(target.v==undefined || target.v!==v+1)	continue;
        if(target.className=="node open")	pickUP(target);
        cssAdd(target,"hide");
    }
}

function open(node){

    var target=node,v=node.v;

    while(target!=null){
        target=target.nextSibling;
        if(target==null || target.v==v) return;
        if(target.v==undefined || target.v!==v+1)	continue;

        target.style.marginLeft=target.v*cfg.gap+"px";

        cssRm(target,"hide");/*子部分--展示*/

        if(target.className=="node open")	open(target);

    }
}

function getOpen(dom,css1){
    if(dom&&dom.className!=null){
        var css=dom.className.split(/\s+/g);;
        var p=css.indexOf(css1);
        if(p>=0) return true;
    }
    return false;
}

function cssAdd(dom,css1){/*给元素添加样式--隐藏*/
    if(dom&&dom.className!=null){
        var css=dom.className.split(/\s+/g);
        if(css.indexOf(css1)<0){/*如果没有该样式 方添加*/
            css.push(css1);
            dom.className=css.join(" ").trim();
        }
    }
    else	dom.className=css1;
}
function cssRm(dom,css1){//--显示
    if(dom&&dom.className!=null){
        var css=dom.className.split(/\s+/g);
        var p=css.indexOf(css1);
        if(p>=0){
            css.splice(p,1);;
            dom.className=css.join(" ");
        }
    }
}