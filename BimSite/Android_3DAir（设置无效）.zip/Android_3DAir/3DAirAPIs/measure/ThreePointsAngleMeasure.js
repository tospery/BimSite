/**
 * Created by Administrator on 2017/2/15.
 */
THREE.ThreePointsAngleMeasure = function( editor, measure,pointsMaterial,lineMaterial ) {

    var scope = this;
//点对象相关变量
    var pointsObject = undefined;
    var points = [];var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];var lcolors = [];
    var lineDistance =[];//长度数据
    var indexts =[];
    var count =0;

    var color = new THREE.Vector3(0.35294117647059,0.27058823529412,0.03921568627451);
    var tempObject = undefined;
    var tempPoint = undefined;
    var downCount =0;

    this.name = 'TPAM';

    this.restColor = function(indext){

        updatePointColor(indext,color);//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        return '#5a450a';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        return 'red';
    };
    //当处于创建过程时，则删除临时对象
    this.deleteTempObject = function(){

        deleteTempObject();
        editor.signals.updateRender.dispatch();
    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
        indexts =[];count =0;

        deleteTempObject();
    };

    this.onPointerDown = function(event,point,face,object){

        if(tempObject !== undefined){

            (tempObject.geometry.vertices[downCount-1].distanceTo(point)>0.0001)?(downCount++):undefined;
            if(downCount>=3){createLines();deleteTempObject();}
        }else {

            createTempObject(point);
        }
    };
    this.onPointerMove = function(event,point,face,object){

        if(tempObject !== undefined){

            tempObject.geometry.vertices[downCount].copy(point);
            tempObject.geometry.verticesNeedUpdate = true;
        }
    };
    this.onPointerUp = function(event){
    };

    this.fromObject = function(object0,object1){

        var positions = (object1.geometry.getAttribute( 'position' )).array;
        var pcolors = (object1.geometry.getAttribute( 'customColor' )).array;
        for(var i =0;i<positions.length/3;i++){

            points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
            colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        }
        createPoints();

        var len = lineDistance.length/7+1;
        var lpositions = (object0.geometry.getAttribute( 'position' )).array;
        var lpcolors = (object0.geometry.getAttribute( 'color' )).array;
        var ld = (object0.geometry.getAttribute( 'lineDistance' )).array;
        for(var j =0;j<lpositions.length/3;j++){

            lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
            lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
            lineDistance.push(ld[j]);
        }
        var lindexs = (object0.geometry.getIndex()).array;
        for(var k =0;k<lindexs.length;k++){

            indexts.push(lindexs[k]);
        }
        createLine();

        for(var t =len;t<=lineDistance.length/7;t++){

            var po = new THREE.Vector3(points[t*9-9],points[t*9-8],points[t*9-7]);
            var p1 = new THREE.Vector3(points[t*9-6],points[t*9-5],points[t*9-4]);
            var p2 = new THREE.Vector3(points[t*9-3],points[t*9-2],points[t*9-1]);

            var side0 = po.sub(p1);
            var side1 = p2.sub(p1);

            var angle = side0.angleTo(side1);
            angle = 180/Math.PI * angle;
            var tangle = angle;angle = parseInt(tangle)+"°";tangle -=parseInt(tangle);
            tangle =tangle*60;angle +=parseInt(tangle)+"′";tangle -=parseInt(tangle);
            tangle =tangle*60;angle +=parseInt(tangle)+"″";

            var start = new THREE.Vector3(lpoints[t*21-12],lpoints[t*21-11],lpoints[t*21-10]);
            var end = new THREE.Vector3(lpoints[t*21-9],lpoints[t*21-8],lpoints[t*21-7]);

            createPointLabel((start.add(end).multiplyScalar(0.5)),angle,t);
        }
    };

    function createLines(){

        var point0 = tempObject.geometry.vertices[0];
        var point1 = tempObject.geometry.vertices[1];
        var point2 = tempObject.geometry.vertices[2];
        var angle = null;

        angleValue();

        points.push(point0.x,point0.y,point0.z,point1.x,point1.y,point1.z,point2.x,point2.y,point2.z);
        colors.push(color.x,color.y,color.z,color.x,color.y,color.z,color.x,color.y,color.z);
        createPoints();

        //向顶点数据中加入顶点数据
        lpoints.push(point0.x,point0.y,point0.z,point1.x,point1.y,point1.z,point2.x,point2.y,point2.z);//不动线
        lpoints.push(point0.x,point0.y,point0.z,point2.x,point2.y,point2.z,point0.x,point0.y,point0.z,point2.x,point2.y,point2.z);
        //
        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
        //向长度数据中加入长度数据
        var dis0 = point0.distanceTo(point1);var dis1 = point2.distanceTo(point1);
        lineDistance.push( dis0*10,0,dis1*10, 0,0,60,60 );
        //索引值数据
        indexts.push(count*7+1,count*7,count*7+1,count*7+2,count*7+3,count*7+4,count*7+3,count*7+5,count*7+4,count*7+6);
        createLine();

        createPointLabel(((point0.add(point2)).multiplyScalar(0.5)),angle,lineDistance.length/7);

        function angleValue(){

            var side0 = (point0.clone()).sub(point1);
            var side1 = (point2.clone()).sub(point1);

            angle = side0.angleTo(side1);
            angle = 180/Math.PI * angle;

            var tangle = angle;angle = parseInt(tangle)+"°";tangle -=parseInt(tangle);
            tangle =tangle*60;angle +=parseInt(tangle)+"′";tangle -=parseInt(tangle);
            tangle =tangle*60;angle +=parseInt(tangle)+"″";
        }
    }
    function createPoints(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name='TPAM';

        editor.measureGroup.add(pointsObject);//放入线对象
    }
    function createLine(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indexts ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name='TPAM';

        count = lpoints.length/21;

        editor.measureGroup.add(linesObject);//放入线对象
    }
    function createPointLabel(apoint,angle,len){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="∠ = "+angle;
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#5a450a';
        label.innerHTML=label.infor;

        measure.addLabelEvents(label);
    }

    //更新连线颜色--7
    function updateLineColor(indext,color){

        var i = indext;
        var lineColor = linesObject.geometry.getAttribute( 'color' );
        var lineColorArray = lineColor.array;
        for(var j =21;j>0;){

            lineColorArray[i*21-j] = color.x;j--;
            lineColorArray[i*21-j] = color.y;j--;
            lineColorArray[i*21-j] = color.z;j--;
        }

        lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        var i = indext;
        var moveDist = (point.clone()).sub(point0);

        //更新连线位置
        var linePosition = linesObject.geometry.getAttribute( 'position' );
        var linePositionArray = linePosition.array;
        linePositionArray[i*21-7] += moveDist.z;linePositionArray[i*21-10] += moveDist.z;
        linePositionArray[i*21-8] += moveDist.y;linePositionArray[i*21-11] += moveDist.y;
        linePositionArray[i*21-9] += moveDist.x;linePositionArray[i*21-12] += moveDist.x;

        lpoints[i*21-7] += moveDist.z;lpoints[i*21-10] += moveDist.z;
        lpoints[i*21-8] += moveDist.y;lpoints[i*21-11] += moveDist.y;
        lpoints[i*21-9] += moveDist.x;lpoints[i*21-12] += moveDist.x;

        linePosition.needsUpdate = true;
        //更新连线间距
        var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        var lDistanceArray = lDistance.array;
        var dis = ((new THREE.Vector3(lpoints[i*21-7],lpoints[i*21-8],lpoints[i*21-9])).distanceTo(
                new THREE.Vector3(lpoints[i*21-1],lpoints[i*21-2],lpoints[i*21-3])
            ))*20;
        lDistanceArray[i*7-1] = lDistanceArray[i*7-2] = dis;

        lineDistance[i*7-1] = lineDistance[i*7-2] = dis;

        lDistance.needsUpdate = true;
    };
    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext*3;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = pointColorArray[i*3-4] = pointColorArray[i*3-7] = color.z;
        pointColorArray[i*3-2] = pointColorArray[i*3-5] = pointColorArray[i*3-8] = color.y;
        pointColorArray[i*3-3] = pointColorArray[i*3-6] = pointColorArray[i*3-9] = color.x;

        pointColor.needsUpdate = true;
    }

    //临时对象方法
    function createTempObject(point){

        var geometry = new THREE.Geometry();

        geometry.vertices[0]=point.clone();geometry.vertices[1]=point.clone();geometry.vertices[2]=point.clone();

        tempObject = new THREE.Line( geometry,new THREE.LineBasicMaterial( { color: 0xFFFFFF } ) );
        editor.sceneHelpers.add(tempObject);//放入线对象

        tempPoint = new THREE.Points( geometry,new THREE.PointsMaterial( { size: 4, sizeAttenuation: false,color: 0xFFFFFF, depthTest :false } ) );
        editor.sceneHelpers.add(tempPoint);//放入对象

        downCount=1;
    }
    function deleteTempObject(){

        editor.sceneHelpers.remove(tempObject);//放入线对象
        tempObject = undefined;
        editor.sceneHelpers.remove(tempPoint);
        tempPoint = undefined;

        downCount=0;
    }

};