/**
 * Created by Administrator on 2017/2/8.
 */
THREE.PointToPlaneDistanceMeasure = function( editor, measure,pointsMaterial,lineMaterial,planeMaterial ) {

    var scope = this;
//点对象相关变量
    var pointsObject = undefined;
    var points = [];
    var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];
    var lcolors = [];
    var lineDistance =[];//长度数据
    var indexts =[];
    var count =0;
//平面对象相关变量
    var facesObject = undefined;
    var translates = [];
    var fcolors = [];
    var mcol0 = [];
    var mcol1 = [];
    var mcol2 =[];

    var color = new THREE.Vector3( 1.0,0.74117647058824 ,0.098039215686275 );
    var tempObject = undefined;
    var tempObject0 = undefined;

    this.name = 'PTPDM';

    this.restColor = function(indext){

        updatePointColor(indext,color);//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        updatePlaneColor(indext,new THREE.Vector3(1.0,1.0,1.0));
        return '#ffbd19';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        updatePlaneColor(indext,new THREE.Vector3(1.0,0.0,0.0));
        return 'red';
    };
    //当处于创建过程时，则删除临时对象
    this.deleteTempObject = function(){

        deleteTempObject0();
        deleteTempObject();
        editor.signals.updateRender.dispatch();
    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
        indexts =[];count =0;

        editor.measureGroup.remove(facesObject);
        facesObject = undefined;
        translates = [];fcolors = [];
        mcol0 = [];mcol1 = [];mcol2 =[];

        deleteTempObject0();
        deleteTempObject();
    };

    this.onPointerDown = function(event,point,face,object){

        if(tempObject !== undefined){

            createFaceAndLine(point,face,object);
            deleteTempObject0();
            deleteTempObject();
        }else {

            createTempObject(point,face,object);
        }
    };
    this.onPointerMove = function(event,point,face,object){

        if(tempObject !== undefined){

            processTempObject0(point,face,object);
        }
    };
    this.onPointerUp = function(event){

    };

    this.fromObject = function(object0,object1,object2){

        var translate = (object2.geometry.getAttribute( 'translate' )).array;
        var fpcolors = (object2.geometry.getAttribute( 'color' )).array;
        var fmcol0 = (object2.geometry.getAttribute( 'mcol0' )).array;
        var fmcol1 = (object2.geometry.getAttribute( 'mcol1' )).array;
        var fmcol2 = (object2.geometry.getAttribute( 'mcol2' )).array;
        for(var l =0;l<translate.length/3;l++){

            translates.push(translate[l*3],translate[l*3+1],translate[l*3+2]);
            fcolors.push(fpcolors[l*3],fpcolors[l*3+1],fpcolors[l*3+2]);
            mcol0.push(fmcol0[l*3],fmcol0[l*3+1],fmcol0[l*3+2]);
            mcol1.push(fmcol1[l*3],fmcol1[l*3+1],fmcol1[l*3+2]);
            mcol2.push(fmcol2[l*3],fmcol2[l*3+1],fmcol2[l*3+2]);
        }
        createFaces();

        var positions = (object1.geometry.getAttribute( 'position' )).array;
        var pcolors = (object1.geometry.getAttribute( 'customColor' )).array;
        for(var i =0;i<positions.length/3;i++){

            points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
            colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        }
        createPoints();

        var len = lineDistance.length/7+1;
        var lpositions = (object0.geometry.getAttribute( 'position' )).array;
        var lpcolors = (object0.geometry.getAttribute( 'color' )).array;
        var ld = (object0.geometry.getAttribute( 'lineDistance' )).array;
        for(var j =0;j<lpositions.length/3;j++){

            lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
            lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
            lineDistance.push(ld[j]);
        }
        var lindexs = (object0.geometry.getIndex()).array;
        for(var k =0;k<lindexs.length;k++){

            indexts.push(lindexs[k]);
        }
        createLine();

        for(var t =len;t<=lineDistance.length/7;t++){

            var start = new THREE.Vector3(lpoints[t*21-15],lpoints[t*21-14],lpoints[t*21-13]);
            var end = new THREE.Vector3(lpoints[t*21-12],lpoints[t*21-11],lpoints[t*21-10]);
            createPointLabel(((start.clone()).add(end).multiplyScalar(0.5)),t,(start.distanceTo(end)));
        }

    };

    function createFaceAndLine(point,face,object){

        var c = new THREE.Vector3();
        var a = new THREE.Vector3(tempObject.position.x,tempObject.position.y,tempObject.position.z);
        var distance = 0;
        if(pointToSurfaceDistance(point,face,object)){

            //向位置数据中加入位置数据
            translates.push(point.x,point.y,point.z);fcolors.push(1.0,1.0,1.0);
            //
            var me = tempObject0.matrix.elements;
            mcol0.push(me[ 0 ], me[ 1 ], me[ 2 ]);
            mcol1.push(me[ 4 ], me[ 5 ], me[ 6 ]);
            mcol2.push(me[ 8 ], me[ 9 ], me[ 10 ]);
            createFaces();

            points.push(a.x,a.y,a.z,c.x,c.y,c.z);colors.push(color.x,color.y,color.z,color.x,color.y,color.z);
            createPoints();

            //向顶点数据中加入顶点数据
            lpoints.push(a.x,a.y,a.z,c.x,c.y,c.z,a.x,a.y,a.z,c.x,c.y,c.z);
            lpoints.push(a.x,a.y,a.z,c.x,c.y,c.z,point.x,point.y,point.z);
            //
            lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
            lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
            //向长度数据中加入长度数据
            var dis = a.distanceTo(c);
            lineDistance.push( 0,dis*10, 0,0, 60,60 );
            dis = c.distanceTo(point);
            lineDistance.push( dis*10 );
            //索引值数据
            indexts.push(count*7,count*7+1, count*7+2,count*7+3,count*7+4,count*7+2, count*7+5,count*7+3,count*7+1,count*7+6);
            createLine();

            createPointLabel(((c.add(a)).multiplyScalar(0.5)),lineDistance.length/7,distance);
        }

        //计算点到面的最短距离
        function pointToSurfaceDistance(b,face,object){

            //求两面之间的一条线段（向量）
            var ab = (b.clone()).sub(a);
            //求法线
            var nor = (face.normal.clone()).applyMatrix4(object.matrixWorld);
            //求点积
            var m = ab.dot(nor);
            //求最短距离
            distance = m/(nor.length());

            if(distance.toFixed(3) == 0.000){
                // alert("点在面上！");
                console.log("点在面上！");
                return false;
            }
            //求三角形的最后一个点
            c = (nor.multiplyScalar(distance)).add(a);
            return true;
        }
    }
    function createFaces(){

        var geometry = new THREE.InstancedBufferGeometry();
        geometry.copy( new THREE.PlaneBufferGeometry( 1, 1, 1, 1 ) );

        geometry.addAttribute( "mcol0", new THREE.InstancedBufferAttribute( new Float32Array(mcol0), 3, 1 ) );
        geometry.addAttribute( "mcol1", new THREE.InstancedBufferAttribute( new Float32Array(mcol1), 3, 1 ) );
        geometry.addAttribute( "mcol2", new THREE.InstancedBufferAttribute( new Float32Array(mcol2), 3, 1 ) );
        geometry.addAttribute( "translate", new THREE.InstancedBufferAttribute( new Float32Array(translates), 3, 1 ) );
        geometry.addAttribute( "color", new THREE.InstancedBufferAttribute( new Float32Array(fcolors), 3, 1 ) );
        if(facesObject!==undefined){

            editor.measureGroup.remove(facesObject);
            facesObject = undefined;
        }
        //创建线对象
        facesObject = new THREE.Mesh( geometry, planeMaterial );
        facesObject.name='PTPDM';
        facesObject.frustumCulled=false;//移除屏幕也绘制标志位

        editor.measureGroup.add(facesObject);//放入对象
    }
    function createPoints(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name='PTPDM';

        editor.measureGroup.add(pointsObject);//放入线对象
    }
    function createLine(){//a,c,b
        /*
         (4)0- - -1(5)- - - -6
         |     |
         |     |
         2-----3
         */
        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indexts ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name='PTPDM';

        count = lpoints.length/21;

        editor.measureGroup.add(linesObject);//放入线对象
    }
    function createPointLabel(apoint,len,distance){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="L = "+(Math.abs(distance.toFixed(3)))+" m";
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#ffbd19';
        label.innerHTML=label.infor;

        measure.addLabelEvents(label);
    }

    //更新连线颜色--7个点
    function updateLineColor(indext,color){

        var lineColor = linesObject.geometry.getAttribute( 'color' );
        var lineColorArray = lineColor.array;
        for(var j =21;j>0;){

            lineColorArray[indext*21-j] = color.x;j--;
            lineColorArray[indext*21-j] = color.y;j--;
            lineColorArray[indext*21-j] = color.z;j--;
        }

        lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        var moveDist = (point.clone()).sub(point0);

        //更新连线位置
        var linePosition = linesObject.geometry.getAttribute( 'position' );
        var linePositionArray = linePosition.array;
        linePositionArray[indext*21-13] += moveDist.z;linePositionArray[indext*21-10] += moveDist.z;
        linePositionArray[indext*21-14] += moveDist.y;linePositionArray[indext*21-11] += moveDist.y;
        linePositionArray[indext*21-15] += moveDist.x;linePositionArray[indext*21-12] += moveDist.x;

        lpoints[indext*21-13] += moveDist.z;lpoints[indext*21-10] += moveDist.z;
        lpoints[indext*21-14] += moveDist.y;lpoints[indext*21-11] += moveDist.y;
        lpoints[indext*21-15] += moveDist.x;lpoints[indext*21-12] += moveDist.x;

        linePosition.needsUpdate = true;
        //更新连线间距
        var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        var lDistanceArray = lDistance.array;
        var dis = ((new THREE.Vector3(lpoints[0],lpoints[1],lpoints[2])).distanceTo(
                new THREE.Vector3(lpoints[indext*21-15],lpoints[indext*21-14],lpoints[indext*21-13])
            ))*20;
        lDistanceArray[indext*7-2] = lDistanceArray[indext*7-3] = dis;
        lineDistance[indext*7-2] = lineDistance[indext*7-3] = dis;

        lDistance.needsUpdate = true;
    };
    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext*2;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = pointColorArray[i*3-4] = color.z;
        pointColorArray[i*3-2] = pointColorArray[i*3-5] = color.y;
        pointColorArray[i*3-3] = pointColorArray[i*3-6] = color.x;

        pointColor.needsUpdate = true;
    }
    //更新面的颜色
    function updatePlaneColor(indext,color){

        var i = indext;
        var faceColor = facesObject.geometry.getAttribute( 'color' );
        var faceColorArray = faceColor.array;
        faceColorArray[i*3-1] = color.z;faceColorArray[i*3-2] = color.y;faceColorArray[i*3-3] = color.x;

        faceColor.needsUpdate = true;
    }

    //临时对象方法
    function createTempObject(point,face,object){

        tempObject=new THREE.Points(
            (function(){
                var geometry = new THREE.Geometry();
                geometry.vertices.push( new THREE.Vector3(0,0,0) );
                return geometry;
            })(),
            new THREE.PointsMaterial( { size: 4, sizeAttenuation: false,color: 0xFFFFFF, depthTest :false } )
        );

        tempObject.position.copy(point);
        editor.sceneHelpers.add(tempObject);//放入对象

        createTempObject0(point,face,object);
    }
    function deleteTempObject(){

        editor.sceneHelpers.remove(tempObject);
        tempObject = undefined;
    }

    function createTempObject0(point,face,object){

        //几何体对象
        var geometry = new THREE.PlaneGeometry(1,1,1,1);
        //创建线对象
        tempObject0 = new THREE.Mesh(geometry,
            new THREE.MeshBasicMaterial({color:0xFFFF00,depthTest :false, opacity:0.3, transparent:true}));

        var nor = (face.normal.clone()).applyMatrix4(object.matrixWorld);
        tempObject0.position.copy(point);
        var normal = (point.clone()).add(nor);
        tempObject0.lookAt(normal);

        editor.sceneHelpers.add(tempObject0);//放入对象
    }
    function processTempObject0(point,face,object){

        var nor = (face.normal.clone()).applyMatrix4(object.matrixWorld);
        tempObject0.position.copy(point);
        var normal = (point.clone()).add(nor);
        tempObject0.lookAt(normal);
    }
    function deleteTempObject0(){

        editor.sceneHelpers.remove(tempObject0);//放入对象
        tempObject0 = undefined;
    }

};