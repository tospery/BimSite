/**
 * @author mrdoob / http://mrdoob.com/
 */

var Loader = function (editor, container) {

    var scope = this;
    var signals = editor.signals;

    this.texturePath = '';
    ///////////////////////////////////////////////////
    var loading = new UI.Loading();
    loading.setId('progress');
    container.add(loading);
    ///////////////////////////////////////////////////////////////////////
    //	var itemsTotal=0;
    //	var itemsLoaded=0;
    var bar = undefined;
    var width = 0;

    this.loadLocalFile = function (dataStr) {
        var data;
        try {

            data = JSON.parse(dataStr);
            //data=dataStr;

        } catch (error) {

            alert(error);
            loading.setDisplay("none");
            return;
        }
        for (var i in data) handleJSON(data[i]);
        loading.setDisplay("none");
    },

    this.loadJsonFile = function (url) {//加载模型文件方法

        loading.setDisplay("block");
        bar = document.getElementById('bar');
        width = container.dom.offsetWidth * 0.6;

        try {

            var req = new XMLHttpRequest();//创建XMLHttpRequest对象
            //重写onreadystatechange事件
            req.onreadystatechange = function () { processObjectLoadObj(req, url) };
            req.open("GET", url, true);//调用open方法
            req.onprogress = function (pe) {
                if (pe.lengthComputable) {

                    var tw = Math.floor(width * (pe.loaded / pe.total));
                    bar.style.width = tw + "px";
                }
            };
            req.overrideMimeType("text/html;charset=gb2312");
            // req.responseType="blob";//设置responseType
            req.responseType = "text";//设置responseType
            req.withCredentials = true;
            req.send(null);//调用send方法

        } catch (error) {

            // alert( error );
            alert('路径错误！！');
            loading.setDisplay("none");
        }

    };

    function processObjectLoadObj(req, url) {//加载模型文件的过程方法

        if (req.readyState == 4) {//数据解析完毕

            if (req.status == 404) {

                alert("路径错误！！");
                loading.setDisplay("none");
            } else if (req.status == 200) {

                var JsonStr = req.responseText;//获取网页信息
                fromJsonStrToObjectData(JsonStr, url);//获取模型相关数据

                //                 var blob = new Blob([req.response],{type: "text/html"});
                //                 console.log(blob);
                //                 blob = blob.slice(427020000);
                //                 console.log(blob);
                //                 var reader = new FileReader();
                // 				reader.addEventListener( 'load', function ( event ) {
                // console.log("===000===========");
                //                     var contents = event.target.result;
                //                     console.log("contents="+contents);
                //                     var data;
                //                     try {
                //
                //                         data = JSON.parse( contents );
                //                         console.log("data="+data);
                //
                //                     } catch ( error ) {
                //
                //                         alert( error );
                //                         // alert( "JSON.parse解析出错" );
                //                         loading.setDisplay( "none" );
                //                     }
                //                 });
                //                 reader.addEventListener( 'abort', function ( event ) {
                //                     console.log("===onabort===========");
                //                 });
                //                 reader.addEventListener( 'error', function ( event ) {
                //                     console.log("===onerror===========");
                //                 });
                //                 reader.addEventListener( 'loadend', function ( event ) {
                //                     console.log("===onloadend===========");
                //                 });
                //                 reader.addEventListener( 'loadstart', function ( event ) {
                //                     console.log("===onloadstart===========");
                //                 });
                //
                // 				reader.readAsText( blob );

            } else {

                alert("不支持该路径的访问！！");
                loading.setDisplay("none");
            }

        }
    }

    function fromJsonStrToObjectData(JsonStr, url) {
        var filename = url.split('/').pop();
        var extension = filename.split('.').pop().toLowerCase();

        switch (extension) {
            case 'json':

                var contents = JsonStr;
                var data;
                try {

                    data = JSON.parse(contents);

                } catch (error) {

                    alert(error);
                    // alert( "JSON.parse解析出错" );
                    loading.setDisplay("none");

                    return;
                }

                for (var i in data) handleJSON(data[i], filename);
                loading.setDisplay("none");

                break;

            default:

                alert('Unsupported file format (' + extension + ').');
                loading.setDisplay("none");

                break;

        }

    }

    this.loadFile = function (file) {
        var extension;
        var filename = file.name;
        extension = filename.split('.').pop().toLowerCase();

        loading.setDisplay("block");
        bar = document.getElementById('bar');
        width = container.dom.offsetWidth * 0.6;

        var reader = new FileReader();
        reader.addEventListener('progress', function (event) {

            var size = '(' + Math.floor(event.total / 1000).format() + ' KB)';
            var progress = Math.floor((event.loaded / event.total) * 100);//+ '%';

            var tw = Math.floor(width * progress * 0.01);
            bar.style.width = tw + "px";

            console.log('Loading', filename, size, progress);

        });

        var data;
        switch (extension) {

            case 'json':

                reader.addEventListener('load', function (event) {

                    // console.log(event.target.result.length);
                    var contents = event.target.result;

                    // >= 3.0


                    try {

                        data = JSON.parse(contents);

                    } catch (error) {

                        alert(error);
                        loading.setDisplay("none");
                        return;
                    }

                    for (var i in data) handleJSON(data[i], filename);

                    //itemsTotal = 0;
                    loading.setDisplay("none");

                }, false);
                reader.readAsText(file);
                break;


            default:

                alert('Unsupported file format (' + extension + ').');
                loading.setDisplay("none");

                break;

        }
    };

    this.loadImageFile = function (file) {

        if (file == undefined) return;

        var filename = file.name;

        var imageType = /image.*/;
        if (!file.type.match(imageType)) {

            alert("不是图片格式!!!");
            return -2;
        }

        var reader = new FileReader();
        reader.addEventListener('progress', function (event) {

            var size = '(' + Math.floor(event.total / 1000).format() + ' KB)';
            var progress = Math.floor((event.loaded / event.total) * 100) + '%';
            console.log('Loading', filename, size, progress);

        });

        reader.addEventListener('load', function (event) {

            THREE_Img = event.target.result;
        }, false);

        reader.readAsDataURL(file);

    };
    //
    //	function getTotalCount(data){
    //
    //		for(var j=0;j<data.length;j++){
    //
    //			if(data[j].object.children!==undefined){
    //				itemsTotal++;
    //				getCount(data[j].object);
    //			}
    //		}
    //
    //		function getCount(object){
    //
    //			itemsTotal +=object.children.length;
    //
    //			for(var i =0;i<object.children.length;i++){
    //
    //				if(object.children[i].children !== undefined){
    //
    //					getCount(object.children[i]);
    //				}
    //			}
    //		}
    //	}
    //	var process = function(){
    ////console.log("===000====");
    //		itemsLoaded++;
    //		var tw = Math.floor( width * (itemsLoaded/itemsTotal));
    //		bar.style.width =tw + "px";
    //	};
    function handleJSON(data, filename) {

        var loader = new THREE.ObjectLoader();
        loader.setTexturePath(scope.texturePath);

        switch (data.type) {

            case 'THREE_labelObject':

                var result = loader.parse(data);
                editor.addLabelObject(result);
                break;

            case 'THREE_labelLine':

                var result = loader.parse(data);
                editor.addLabelLine(result);
                break;

            case 'THREE_label':

                editor.addLabel(data.label);
                break;

            case 'THREE_measure':

                var result = loader.parse(data);
                editor.addMeasure(result);
                break;

            case 'THREE_measureLabel':

                editor.addMeasureLabel(data.measureLabel);
                break;

            case 'THREE_Point':

                editor.addViewPoint(data.point);
                break;

            default:

                var result = loader.parse(data);
                editor.addObject(result);
                break;
        }

        signals.zoomToView.dispatch();
        signals.sceneGraphChanged.dispatch();

    }

};
