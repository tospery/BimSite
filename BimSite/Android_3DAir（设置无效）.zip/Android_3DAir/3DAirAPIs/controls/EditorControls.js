/**
 * @author qiao / https://github.com/qiao
 * @author mrdoob / http://mrdoob.com
 * @author alteredq / http://alteredqualia.com/
 * @author WestLangley / http://github.com/WestLangley
 */

THREE.EditorControls = function ( object, domElement ) {

	domElement = ( domElement !== undefined ) ? domElement : document;

	// API

	this.enabled = true;
	this.center = new THREE.Vector3();
	this.rotateCenter = new THREE.Vector3();

	this.enableRotate = true;
	this.rotateSpeed = 1.0;//0.05;

	// internals

	var scope = this;
	var vector = new THREE.Vector3();

	var STATE = { NONE: - 1, ZOOM: 0, PAN: 1,ROTATE: 2, TOUCH_ROTATE : 3,TOUCH_ZOOM: 4};
	var state = STATE.NONE;

	var center = this.center;
	var tcenter=center.clone();
	var normalMatrix = new THREE.Matrix3();
	var pointer = new THREE.Vector2();
	var pointerOld = new THREE.Vector2();
	var spherical = new THREE.Spherical();

	var sceneBox=new THREE.Box3();

	// events
	var changeEvent = { type: 'change' };

	this.focus = function ( target , value) {

		if(value)sceneBox.setFromObjects(target);
		else sceneBox.setFromObject(target);

		var cen = sceneBox.center();

		scope.toCenter(null,cen);
	};

	this.pan = function ( delta ) {

		var distance = object.position.distanceTo( center );
        //
        delta.multiplyScalar( distance * 0.001 );
        delta.applyMatrix3( normalMatrix.getNormalMatrix( object.matrix ) );

		object.position.add( delta );
		center.add( delta );

		scope.dispatchEvent( changeEvent );

	};

	this.zoom = function ( delta ,scale) {

		var distance = object.position.distanceTo( center );

		delta.multiplyScalar( distance * scale );

		if ( delta.length() > distance || distance<0.0001) return;

		delta.applyMatrix3( normalMatrix.getNormalMatrix( object.matrix ) );

		object.position.add( delta );

		scope.dispatchEvent( changeEvent );

	};

	this.toCenter =function (distance, cen){

		vector.copy( object.position ).sub( center );
		spherical.setFromVector3( vector );
		spherical.makeSafe();

		if(distance!==null)spherical.radius=distance;
		else spherical.radius = 16;

		center.set(cen.x,cen.y,cen.z);

		vector.setFromSpherical( spherical );
		object.position.copy( center ).add( vector );

		object.lookAt( center );

		scope.dispatchEvent( changeEvent );
	};

	this.rotate = function ( delta  ) {

		var mt = new THREE.Matrix4();

		var normal =object.up.clone();//绕y轴旋转
		var nor=new THREE.Vector3().subVectors(object.position,center);
		var normalX=new THREE.Vector3().crossVectors(nor,normal);

		mt = new THREE.Matrix4().makeTranslation(-tcenter.x, -tcenter.y, -tcenter.z);
		mt.multiplyMatrices(new THREE.Matrix4().makeRotationAxis(normal.normalize(), -delta.x* scope.rotateSpeed ), mt);
		mt.multiplyMatrices(new THREE.Matrix4().makeRotationAxis(normalX.normalize(), delta.y* scope.rotateSpeed ), mt);
		mt.multiplyMatrices(new THREE.Matrix4().makeTranslation(tcenter.x, tcenter.y, tcenter.z), mt);
		//
		var rotateOnlyMatrix = new THREE.Matrix4();
		rotateOnlyMatrix.makeRotationAxis(normal.normalize(), -delta.x* scope.rotateSpeed);
		rotateOnlyMatrix.multiplyMatrices(new THREE.Matrix4().makeRotationAxis(normalX.normalize(), delta.y* scope.rotateSpeed ), rotateOnlyMatrix);

		object.position.applyMatrix4(mt);
		object.up.applyMatrix4(rotateOnlyMatrix);
		object.up.normalize();
		//
		center.applyMatrix4(mt);
		object.lookAt(center);
        //
		scope.dispatchEvent( changeEvent );

	};

	this.getDistance = function(){

		return object.position.distanceTo( center );
	};

	this.rotateFace = function(up,cx,cy,cz){

		object.position.set(cx,cy,cz);
		object.up.set(up.x,up.y,up.z);
		object.lookAt(center);

		scope.dispatchEvent( changeEvent );
	};

	// mouse

	function onMouseDown( event ) {

		if ( scope.enabled === false ) return;

		event.preventDefault();

        if ( (THREE_KEY && event.button === 0) ||event.button === 2 || scope.enableRotate === true) {

            state = STATE.ROTATE;
            if((THREE_KEY && event.button === 0) || event.button === 2){
                pointCenter.visible=true;

                THREE_rotateSpeedX = 2 * Math.PI/domElement.offsetWidth;
                THREE_rotateSpeedY = 2 * Math.PI/domElement.offsetHeight;
            }
            tcenter=((THREE_KEY && event.button === 0) ||event.button === 2)?scope.rotateCenter.clone():center.clone();
        }
        else if ( event.button === 1 && scope.enableRotate === false) {

			 state = STATE.PAN;
			domElement.style.cursor="move";
		}

		pointerOld.set( event.clientX, event.clientY );

		domElement.addEventListener( 'mousemove', onMouseMove, false );
		document.addEventListener( 'mouseup', onMouseUp, false );

	}
	function onMouseMove( event ) {

		if ( scope.enabled === false ) return;

		pointer.set( event.clientX, event.clientY );

		var movementX = pointer.x - pointerOld.x;
		var movementY = pointer.y - pointerOld.y;

		if ( state === STATE.ROTATE ) {

			scope.rotate( new THREE.Vector2( movementX*THREE_rotateSpeedX, movementY*THREE_rotateSpeedY));
		}
		else if ( state === STATE.PAN ) {

			scope.pan( new THREE.Vector3( -movementX, movementY, 0 ) );
		}

		pointerOld.set( event.clientX, event.clientY );

	}
	function onMouseUp( event ) {

		domElement.style.cursor="default";
		if(pointCenter.visible){pointCenter.visible=false;scope.dispatchEvent( changeEvent );}

		domElement.removeEventListener( 'mousemove', onMouseMove, false );
		document.removeEventListener( 'mouseup', onMouseUp, false );

		state = STATE.NONE;

	}
	function onMouseWheel( event ) {

		if ( scope.enabled === false ) return;

		event.preventDefault();
		var delta = 0;

		if ( event.wheelDelta ) {

			// WebKit / Opera / Explorer 9

			delta = - event.wheelDelta;

		} else if ( event.detail ) {

			// Firefox

			delta = event.detail * 10;

		}

		scope.zoom( new THREE.Vector3( 0, 0, delta ), 0.0001 );

	}

	function contextmenu( event ) {

		event.preventDefault();

	}

	this.dispose = function() {

		domElement.removeEventListener( 'contextmenu', contextmenu, false );
		domElement.removeEventListener( 'mousedown', onMouseDown, false );
		domElement.removeEventListener( 'mousewheel', onMouseWheel, false );
		domElement.removeEventListener( 'MozMousePixelScroll', onMouseWheel, false ); // firefox

		domElement.removeEventListener( 'mousemove', onMouseMove, false );
		domElement.removeEventListener( 'mouseup', onMouseUp, false );
		domElement.removeEventListener( 'mouseout', onMouseUp, false );
		domElement.removeEventListener( 'dblclick', onMouseUp, false );

		domElement.removeEventListener( 'touchstart', touchStart, false );
		domElement.removeEventListener( 'touchmove', touchMove, false );

	};

	domElement.addEventListener( 'contextmenu', contextmenu, false );
	domElement.addEventListener( 'mousedown', onMouseDown, false );
	domElement.addEventListener( 'mousewheel', onMouseWheel, false );
	domElement.addEventListener( 'MozMousePixelScroll', onMouseWheel, false ); // firefox

	// touch

	var touches = [ new THREE.Vector3(), new THREE.Vector3() ];
	var prevTouches = [ new THREE.Vector3(), new THREE.Vector3() ];

	var prevDistance = null;

	function touchStart( event ) {

		if ( scope.enabled === false ) return;

		state = STATE.NONE;
		switch ( event.touches.length ) {

			case 1:

				if(scope.enableRotate === true){

					touches[ 0 ].set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY,0 );
					touches[ 1 ].set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY,0 );

                    THREE_rotateSpeedX = 2 * Math.PI/domElement.offsetWidth;
                    THREE_rotateSpeedY = 2 * Math.PI/domElement.offsetHeight;

					state = STATE.TOUCH_ROTATE;
					tcenter=center.clone();
				}

				break;

			case 2:
				touches[ 0 ].set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY,0 );
				touches[ 1 ].set( event.touches[ 1 ].pageX, event.touches[ 1 ].pageY,0 );
				prevDistance = touches[ 0 ].distanceTo( touches[ 1 ] );
				state = STATE.TOUCH_ZOOM;

				break;

			default:

				state = STATE.NONE;
			break;
		}

		prevTouches[ 0 ].copy( touches[ 0 ] );
		prevTouches[ 1 ].copy( touches[ 1 ] );

	}
	function touchMove( event ) {

		if ( scope.enabled === false ||THREE_DissectEnabled ===true) return;

		event.preventDefault();

		switch ( event.touches.length ) {

			case 1:

				if ( state === STATE.TOUCH_ROTATE ){

					touches[ 0 ].set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY,0 );
					touches[ 1 ].set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY,0 );

					var rotateDelta=new THREE.Vector2();
					rotateDelta.subVectors( touches[ 0 ], prevTouches[ 0 ] );
                    rotateDelta.x *=THREE_rotateSpeedX;
                    rotateDelta.y *=THREE_rotateSpeedY;

					scope.rotate( rotateDelta );
				}

				break;

			case 2:

				touches[ 0 ].set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY,0 );
				touches[ 1 ].set( event.touches[ 1 ].pageX, event.touches[ 1 ].pageY,0 );

				var distance = touches[ 0 ].distanceTo( touches[ 1 ] );
				if(Math.abs(distance - prevDistance)>5.0){

					scope.zoom( new THREE.Vector3( 0, 0, prevDistance - distance ), 0.005 );
					prevDistance = distance;
				}else{

					var moveX = touches[ 0].x - prevTouches[ 0 ].x;
					var moveY = touches[ 0].y - prevTouches[ 0 ].y;
					scope.pan( new THREE.Vector3(-moveX,moveY,0) );
				}

				break;

		}

		prevTouches[ 0 ].copy( touches[ 0 ] );
		prevTouches[ 1 ].copy( touches[ 1 ] );

	}

	domElement.addEventListener( 'touchstart', touchStart, false );
	domElement.addEventListener( 'touchmove', touchMove, false );

};

THREE.EditorControls.prototype = Object.create( THREE.EventDispatcher.prototype );
THREE.EditorControls.prototype.constructor = THREE.EditorControls;
