/**
 * Created by Administrator on 2017/2/9.
 */
THREE.InstancedBufferGeometryLoader = function ( manager ) {

    this.manager = ( manager !== undefined ) ? manager : THREE.DefaultLoadingManager;

};

Object.assign( THREE.InstancedBufferGeometryLoader.prototype, {

    load: function ( url, onLoad, onProgress, onError ) {

        var scope = this;

        var loader = new THREE.XHRLoader( scope.manager );
        loader.load( url, function ( text ) {

            onLoad( scope.parse( JSON.parse( text ) ) );

        }, onProgress, onError );

    },

    parse: function ( json ) {

        var geometry = new THREE.InstancedBufferGeometry();

        var index = json.data.index;

        var TYPED_ARRAYS = {
            'Int8Array': Int8Array,
            'Uint8Array': Uint8Array,
            'Uint8ClampedArray': Uint8ClampedArray,
            'Int16Array': Int16Array,
            'Uint16Array': Uint16Array,
            'Int32Array': Int32Array,
            'Uint32Array': Uint32Array,
            'Float32Array': Float32Array,
            'Float64Array': Float64Array
        };

        if ( index !== undefined ) {

            var typedArray = new TYPED_ARRAYS[ index.type ]( index.array );
            geometry.setIndex( new THREE.BufferAttribute( typedArray, 1 ) );

        }

        var attributes = json.data.attributes;

        for ( var key in attributes ) {

            var attribute = attributes[ key ];
            var typedArray = new TYPED_ARRAYS[ attribute.type ]( attribute.array );

            switch(key){
                case "position":
                case "normal":
                case "uv":
                    geometry.addAttribute( key, new THREE.BufferAttribute( typedArray, attribute.itemSize, attribute.normalized ) );

                    break;
                default:
                    geometry.addAttribute( key, new THREE.InstancedBufferAttribute( typedArray, attribute.itemSize, attribute.meshPerAttribute ) );

                    break;

            }
        }

        var groups = json.data.groups || json.data.drawcalls || json.data.offsets;

        if ( groups !== undefined ) {

            for ( var i = 0, n = groups.length; i !== n; ++ i ) {

                var group = groups[ i ];

                geometry.addGroup( group.start, group.count, group.materialIndex );

            }

        }

        var boundingSphere = json.data.boundingSphere;

        if ( boundingSphere !== undefined ) {

            var center = new THREE.Vector3();

            if ( boundingSphere.center !== undefined ) {

                center.fromArray( boundingSphere.center );

            }

            geometry.boundingSphere = new THREE.Sphere( center, boundingSphere.radius );

        }

        return geometry;

    }

} );
