/**
 * Created by Administrator on 2017/2/5.
 */
THREE.PointMeasure = function( editor, measure,pointsMaterial,lineMaterial ) {

    var scope = this;

//点对象相关变量
    var pointsObject = undefined;
    var points = [];
    var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];
    var lcolors = [];
    var lineDistance =[];//长度数据

    var color = new THREE.Vector3(0.0234375,0.3046875 ,0.02734375);

    this.name = 'PM';

    this.restColor = function(indext){

        updatePointColor(indext,color);//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        return '#064e07';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        return 'red';
    };

    this.deleteTempObject = function(){

    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
    };

    this.onPointerDown = function(event,point){

        createPointAndLine(point);
    };
    this.onPointerMove = function(event,point){

    };
    this.onPointerUp = function(event){

    };

    this.fromObject = function(object0,object1){

        var positions = (object1.geometry.getAttribute( 'position' )).array;
        var pcolors = (object1.geometry.getAttribute( 'customColor' )).array;
        for(var i =0;i<positions.length/3;i++){

            points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
            colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        }
        createPoints();

        var len = lpoints.length/3;
        var lpositions = (object0.geometry.getAttribute( 'position' )).array;
        var lpcolors = (object0.geometry.getAttribute( 'color' )).array;
        var ld = (object0.geometry.getAttribute( 'lineDistance' )).array;
        for(var j =0;j<lpositions.length/3;j++){

            lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
            lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
            lineDistance.push(ld[j]);
        }
        createLine();

        for(var k =len+2;k<=lpoints.length/3;k +=2){

            var point = new THREE.Vector3(lpoints[k*3-3],lpoints[k*3-2],lpoints[k*3-1]);
            createPointLabel(point,k);
        }
    };

    function createPointAndLine(point){

        points.push(point.x,point.y,point.z);
        colors.push(color.x,color.y,color.z);
        createPoints();

        lpoints.push(point.x,point.y,point.z,point.x,point.y,point.z);
        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0);
        //向长度数据中加入长度数据
        lineDistance.push( 0,60 );
        createLine();

        createPointLabel(point,lpoints.length/3);
    }
    function createPoints(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name = 'PM';

        editor.measureGroup.add(pointsObject);//放入对象
    }
    function createLine(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name = 'PM';

        editor.measureGroup.add(linesObject);//放入线对象
    }
    function createPointLabel(apoint,len){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="X = "+apoint.x.toFixed(3)+"\n"+"Y = "+apoint.y.toFixed(3)+"\n"+"Z = "+apoint.z.toFixed(3);
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#064e07';
        label.innerHTML=label.infor;

        measure.addLabelEvents(label);
    }

    //更新连线颜色
    function updateLineColor(indext,color){

        var lineColor = linesObject.geometry.getAttribute( 'color' );
        var lineColorArray = lineColor.array;
        lineColorArray[indext*3-1] = lineColorArray[indext*3-4] = color.z;
        lineColorArray[indext*3-2] = lineColorArray[indext*3-5] = color.y;
        lineColorArray[indext*3-3] = lineColorArray[indext*3-6] = color.x;

        lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        //更新连线位置
        var linePosition = linesObject.geometry.getAttribute( 'position' );
        var linePositionArray = linePosition.array;
        linePositionArray[indext*3-1] = point.z;linePositionArray[indext*3-2] = point.y;linePositionArray[indext*3-3] = point.x;

        lpoints[indext*3-1] = point.z;lpoints[indext*3-2] = point.y;lpoints[indext*3-3] = point.x;

        linePosition.needsUpdate = true;
        //更新连线间距
        var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        var lDistanceArray = lDistance.array;
        var dis = ((point.clone()).distanceTo(
                new THREE.Vector3(linePositionArray[indext*3-6],linePositionArray[indext*3-5],linePositionArray[indext*3-4])
            ))*20;
        lDistanceArray[indext-1] = dis;

        lineDistance[indext-1] = dis;

        lDistance.needsUpdate = true;
    };

    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext/2;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = color.z;pointColorArray[i*3-2] = color.y;pointColorArray[i*3-3] = color.x;

        pointColor.needsUpdate = true;
    }

};