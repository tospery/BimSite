/**
 * Created by Administrator on 2017/2/6.
 */
THREE.TwoSideDistanceMeasure = function( editor, measure,pointsMaterial,lineMaterial,planeMaterial ) {

    var scope = this;

//点对象相关变量
    var pointsObject = undefined;
    var points = [];
    var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];
    var lcolors = [];
    var lineDistance =[];//长度数据
    var indexts =[];
    var count =0;
//平面对象相关变量
    var facesObject = undefined;
    var translates = [];
    var fcolors = [];
    var mcol0 = [];
    var mcol1 = [];
    var mcol2 =[];

    var tempObject = undefined;

    this.name = 'TSDM';

    this.restColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.74117647058824 ,0.098039215686275));//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        return '#ffbd19';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        return 'red';
    };
    //当处于创建过程时，则删除临时对象
    this.deleteTempObject = function(){

        deleteTempObject();
        editor.signals.updateRender.dispatch();
    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
        indexts =[];count =0;

        deleteTempObject();
    };

    this.onPointerDown = function(event,point,face,object){

        if(tempObject !== undefined){

            createFaceAndLine(point,face,object);

            deleteTempObject();
        }else {

            createTempObject(point,face,object);
        }

        editor.signals.updateRender.dispatch();
    };
    this.onPointerMove = function(event,point){

    };
    this.onPointerUp = function(event){

    };

    this.fromObject = function(object0,object1){

        // pointsObject = object1;
        // var positions = (pointsObject.geometry.getAttribute( 'position' )).array;
        // var pcolors = (pointsObject.geometry.getAttribute( 'customColor' )).array;
        // for(var i =0;i<positions.length/3;i++){
        //
        //     points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
        //     colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        // }
        //
        // linesObject = object0;
        // var lpositions = (linesObject.geometry.getAttribute( 'position' )).array;
        // var lpcolors = (linesObject.geometry.getAttribute( 'color' )).array;
        // var ld = (linesObject.geometry.getAttribute( 'lineDistance' )).array;
        // for(var j =0;j<lpositions.length/3;j++){
        //
        //     lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
        //     lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
        //     lineDistance.push(ld[j]);
        //
        // }
        // var lindexs = (linesObject.geometry.getIndex()).array;
        // for(var k =0;k<lindexs.length;k++){
        //
        //     indexts.push(lindexs[k]);
        // }
        //
        // count = lpoints.length/18;

    };

    function createFaceAndLine(point,face,object){

        var c = new THREE.Vector3();
        var a = new THREE.Vector3(tempObject.position.x,tempObject.position.y,tempObject.position.z);
        var distance = 0;
        surfaceToSurfaceDistance(point,face,object);

        createFaces(a,point,face,object);
        createPoints([point,c],new THREE.Vector3( 1.0,0.74117647058824 ,0.098039215686275 ));
        createLine(c,point,a);
        var center = ((c.clone()).add(point)).multiplyScalar(0.5);
        createPointLabel(center,lineDistance.length/7,distance);

        //计算面到面的最短距离---第一个面到第二个面的距离
        function surfaceToSurfaceDistance(b,face,object){

            //求两面之间的一条线段（向量）
            // var a = new THREE.Vector3(tempObject.position.x,tempObject.position.y,tempObject.position.z);
            var ab = (b.clone()).sub(a);
            //求法线
            var nor = face.normal.clone();
            nor.applyMatrix4(object.matrixWorld);
            //求点积
            var m = (ab.clone()).dot(nor);
            //求最短距离
            distance = m/(nor.length());
            //求三角形的最后一个点
            c = (nor.multiplyScalar(distance)).add(a);

        }
    }
    function createFaces(point0,point1,face,object){

        //向位置数据中加入位置数据
        translates.push(point0.x,point0.y,point0.z,point1.x,point1.y,point1.z);

        fcolors.push(1.0,1.0,1.0,0.0,1.0,1.0);

        var me = tempObject.matrix.elements;
        mcol0.push(me[ 0 ], me[ 1 ], me[ 2 ]);
        mcol1.push(me[ 4 ], me[ 5 ], me[ 6 ]);
        mcol2.push(me[ 8 ], me[ 9 ], me[ 10 ]);

        var nor = (face.normal.clone()).applyMatrix4(object.matrixWorld);
        tempObject.position.copy(point1);
        tempObject.lookAt(((point1.clone()).add(nor)));
        tempObject.updateMatrixWorld();
        me = tempObject.matrix.elements;
        mcol0.push(me[ 0 ], me[ 1 ], me[ 2 ]);
        mcol1.push(me[ 4 ], me[ 5 ], me[ 6 ]);
        mcol2.push(me[ 8 ], me[ 9 ], me[ 10 ]);

        var geometry = new THREE.InstancedBufferGeometry();
        geometry.copy( new THREE.PlaneBufferGeometry( 1, 1, 1, 1 ) );

        geometry.addAttribute( "mcol0", new THREE.InstancedBufferAttribute( new Float32Array(mcol0), 3, 1 ) );
        geometry.addAttribute( "mcol1", new THREE.InstancedBufferAttribute( new Float32Array(mcol1), 3, 1 ) );
        geometry.addAttribute( "mcol2", new THREE.InstancedBufferAttribute( new Float32Array(mcol2), 3, 1 ) );
        geometry.addAttribute( "translate", new THREE.InstancedBufferAttribute( new Float32Array(translates), 3, 1 ) );
        geometry.addAttribute( "color", new THREE.InstancedBufferAttribute( new Float32Array(fcolors), 3, 1 ) );

        if(facesObject!==undefined){

            editor.measureGroup.remove(facesObject);
            linesObject = undefined;
        }
        //创建线对象
        facesObject = new THREE.Mesh( geometry, planeMaterial );
        facesObject.name='TSDM';
        facesObject.frustumCulled=false;//移除屏幕也绘制标志位

        editor.measureGroup.add(facesObject);//放入对象
    }
    function createPoints(point,color){

        for(var i =0;i<point.length;i++){

            points.push(point[i].x,point[i].y,point[i].z);
            colors.push(color.x,color.y,color.z);
        }

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name='TSDM';

        editor.measureGroup.add(pointsObject);//放入线对象

    }
    function createLine(start,end,point){//c,b,a

        /*
         (4)0- - -1(5)
         |     |
         |     |
         2-----3
         */
        //向顶点数据中加入顶点数据
        lpoints.push(start.x,start.y,start.z,end.x,end.y,end.z);//不动线--虚线
        lpoints.push(start.x,start.y,start.z,end.x,end.y,end.z);//可动线--实线
        lpoints.push(start.x,start.y,start.z,end.x,end.y,end.z);//

        lpoints.push(point.x,point.y,point.z);//

        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0);
        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0);
        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0);

        lcolors.push(1.0,1.0,1.0);

        //向长度数据中加入长度数据
        var dis = (start.clone()).distanceTo(end);
        lineDistance.push( 0,dis*10, 0,0, 60,60 );
        dis = (start.clone()).distanceTo(point);
        lineDistance.push( dis*10 );

        //索引值数据
        indexts.push(count*7,count*7+1, count*7+2,count*7+3, count*7+4,count*7+2, count*7+5,count*7+3,count*7,count*7+6);
        // indexts.push(count*6,count*6+1, count*6+2,count*6+3, count*6+4,count*6+2, count*6+5,count*6+3);

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indexts ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name='TSDM';

        // count = lpoints.length/18;
        count = lpoints.length/21;

        editor.measureGroup.add(linesObject);//放入线对象
    }

    function createPointLabel(apoint,len,distance){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="L = "+(distance.toFixed(3))+" m";
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#ffbd19';
        label.innerHTML=label.infor;

        measure.addLabelEvents(label);
    }

    //更新连线颜色
    function updateLineColor(indext,color){

        // var lineColor = linesObject.geometry.getAttribute( 'color' );
        // var lineColorArray = lineColor.array;
        // lineColorArray[indext*18-1] = lineColorArray[indext*18-4] =
        //     lineColorArray[indext*18-7] = lineColorArray[indext*18-10] =
        //         lineColorArray[indext*18-13] = lineColorArray[indext*18-16] = color.z;
        //
        // lineColorArray[indext*18-2] = lineColorArray[indext*18-5] =
        //     lineColorArray[indext*18-8] = lineColorArray[indext*18-11] =
        //         lineColorArray[indext*18-14] = lineColorArray[indext*18-17] = color.y;
        //
        // lineColorArray[indext*18-3] = lineColorArray[indext*18-6] =
        //     lineColorArray[indext*18-9] = lineColorArray[indext*18-12] =
        //         lineColorArray[indext*18-15] = lineColorArray[indext*18-18] = color.x;
        //
        // lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        // var moveDist = (point.clone()).sub(point0);
        //
        // //更新连线位置
        // var linePosition = linesObject.geometry.getAttribute( 'position' );
        // var linePositionArray = linePosition.array;
        // linePositionArray[indext*18-7] += moveDist.z;linePositionArray[indext*18-10] += moveDist.z;
        // linePositionArray[indext*18-8] += moveDist.y;linePositionArray[indext*18-11] += moveDist.y;
        // linePositionArray[indext*18-9] += moveDist.x;linePositionArray[indext*18-12] += moveDist.x;
        //
        // lpoints[indext*18-7] += moveDist.z;lpoints[indext*18-10] += moveDist.z;
        // lpoints[indext*18-8] += moveDist.y;lpoints[indext*18-11] += moveDist.y;
        // lpoints[indext*18-9] += moveDist.x;lpoints[indext*18-12] += moveDist.x;
        //
        // linePosition.needsUpdate = true;
        // //更新连线间距
        // var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        // var lDistanceArray = lDistance.array;
        // var dis = ((new THREE.Vector3(lpoints[0],lpoints[1],lpoints[2])).distanceTo(
        //         new THREE.Vector3(lpoints[indext*18-10],lpoints[indext*18-11],lpoints[indext*18-12])
        //     ))*20;
        // lDistanceArray[indext*6-1] = lDistanceArray[indext*6-2] = dis;
        //
        // lineDistance[indext*6-1] = lineDistance[indext*6-2] = dis;
        //
        // lDistance.needsUpdate = true;
    };
    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext*2;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = pointColorArray[i*3-4] = color.z;
        pointColorArray[i*3-2] = pointColorArray[i*3-5] = color.y;
        pointColorArray[i*3-3] = pointColorArray[i*3-6] = color.x;

        pointColor.needsUpdate = true;
    }

    //临时对象方法
    function createTempObject(point,face,object){

        //几何体对象
        var geometry = new THREE.PlaneGeometry(1,1,1,1);
        //创建线对象
        tempObject = new THREE.Mesh(geometry,
            new THREE.MeshBasicMaterial({color:0xFFFFFF,depthTest :false, opacity:0.3, transparent:true}));

        var nor = face.normal.clone();
        nor.applyMatrix4(object.matrixWorld);

        tempObject.position.copy(point);
        var normal = (point.clone()).add(nor);
        tempObject.lookAt(normal);

        editor.sceneHelpers.add(tempObject);//放入对象
    }
    function deleteTempObject(){

        editor.sceneHelpers.remove(tempObject);
        tempObject = undefined;
    }

};