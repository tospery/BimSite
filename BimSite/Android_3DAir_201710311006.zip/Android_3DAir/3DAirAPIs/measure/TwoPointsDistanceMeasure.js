/**
 * Created by Administrator on 2017/2/5.
 */
THREE.TwoPointsDistanceMeasure = function( editor, measure,pointsMaterial,lineMaterial ) {

    var scope = this;
//点对象相关变量
    var pointsObject = undefined;
    var points = [];
    var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];
    var lcolors = [];
    var lineDistance =[];//长度数据
    var indexts =[];
    var count =0;

    var color = new THREE.Vector3( 1.0,0.74117647058824 ,0.098039215686275 );
    var tempObject = undefined;
    var tempLabel = undefined;

    this.name = 'TPDM';

    this.restColor = function(indext){

        updatePointColor(indext,color);//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        return '#ffbd19';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        return 'red';
    };
    //当处于创建过程时，则删除临时对象
    this.deleteTempObject = function(){

        (tempObject!==undefined&&tempLabel!==undefined)?measure.removeLabel(tempLabel):undefined;
        tempLabel = undefined;
        deleteTempObject();
        editor.signals.updateRender.dispatch();
    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
        indexts =[];count =0;

        deleteTempObject();
        tempLabel = undefined;
    };

    this.onPointerDown = function(event,point){

        if(tempObject !== undefined){

            var start = tempObject.geometry.vertices[0];
            var dis = parseFloat(tempLabel.infor.substring(3,tempLabel.infor.length-1));
            (dis!==0)?createPointAndLine(start,point):measure.removeLabel(tempLabel);

            deleteTempObject();
            tempLabel = undefined;
        }else {

            createTempObject(point);
        }

        editor.signals.updateRender.dispatch();
    };
    this.onPointerMove = function(event,point){

        if(tempObject !== undefined){

            processTempObject(point);
        }

    };
    this.onPointerUp = function(event){

    };

    this.fromObject = function(object0,object1){

        var positions = (object1.geometry.getAttribute( 'position' )).array;
        var pcolors = (object1.geometry.getAttribute( 'customColor' )).array;
        for(var i =0;i<positions.length/3;i++){

            points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
            colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        }
        createPoints();

        var len = lineDistance.length/6+1;
        var lpositions = (object0.geometry.getAttribute( 'position' )).array;
        var lpcolors = (object0.geometry.getAttribute( 'color' )).array;
        var ld = (object0.geometry.getAttribute( 'lineDistance' )).array;
        for(var j =0;j<lpositions.length/3;j++){

            lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
            lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
            lineDistance.push(ld[j]);
        }
        var lindexs = (object0.geometry.getIndex()).array;
        for(var k =0;k<lindexs.length;k++){

            indexts.push(lindexs[k]);
        }
        createLine();

        for(var t =len;t<=lineDistance.length/6;t++){

            var start = new THREE.Vector3(points[t*6-6],points[t*6-5],points[t*6-4]);
            var end = new THREE.Vector3(points[t*6-3],points[t*6-2],points[t*6-1]);
            createPointLabel((start.add(end).divideScalar(2.0)),t,(start.distanceTo(end).toFixed(2)));
        }
    };

    function createPointAndLine(point0,point){

        points.push(point0.x,point0.y,point0.z,point.x,point.y,point.z);
        colors.push(color.x,color.y,color.z,color.x,color.y,color.z);
        createPoints();

        //向顶点数据中加入顶点数据
        lpoints.push(point0.x,point0.y,point0.z,point.x,point.y,point.z);//不动线--虚线
        lpoints.push(point0.x,point0.y,point0.z,point.x,point.y,point.z);//可动线--实线
        lpoints.push(point0.x,point0.y,point0.z,point.x,point.y,point.z);//

        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
        lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0);
        //向长度数据中加入长度数据
        var dis = point0.distanceTo(point);
        lineDistance.push( 0,dis*10, 0,0, 60,60 );
        //索引值数据
        indexts.push(count*6,count*6+1, count*6+2,count*6+3, count*6+4,count*6+2, count*6+5,count*6+3);
        createLine();
    }
    function createPoints(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name='TPDM';

        editor.measureGroup.add(pointsObject);//放入线对象
    }
    function createLine(){

        /*
     (4)0- - -1(5)
        |     |
        |     |
        2-----3
         */
        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indexts ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name='TPDM';

        count = lpoints.length/18;

        editor.measureGroup.add(linesObject);//放入线对象
    }

    // function createArrow(){
    //
    //     var normal =object.position.clone();//绕Z轴旋转
    //
    //     mt = new THREE.Matrix4().makeTranslation(-tcenter.x, -tcenter.y, -tcenter.z);
    //     mt.multiplyMatrices(new THREE.Matrix4().makeRotationAxis(normal.normalize(), -delta.x* scope.rotateSpeed ), mt);
    //     mt.multiplyMatrices(new THREE.Matrix4().makeTranslation(tcenter.x, tcenter.y, tcenter.z), mt);
    //     //
    //     var rotateOnlyMatrix = new THREE.Matrix4();
    //     rotateOnlyMatrix.makeRotationAxis(normal.normalize(), -delta.x* scope.rotateSpeed);
    //     rotateOnlyMatrix.multiplyMatrices(new THREE.Matrix4().makeRotationAxis(normalX.normalize(), delta.y* scope.rotateSpeed ), rotateOnlyMatrix);
    //
    //     object.position.applyMatrix4(mt);
    //
    // }

    function createPointLabel(apoint,len,distance){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="L = "+distance+" m";
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#ffbd19';
        label.innerHTML=label.infor;

        tempLabel = label;

        measure.addLabelEvents(label);
    }

    //更新连线颜色
    function updateLineColor(indext,color){

        var lineColor = linesObject.geometry.getAttribute( 'color' );
        var lineColorArray = lineColor.array;
        for(var j =18;j>0;){

            lineColorArray[indext*18-j] = color.x;j--;
            lineColorArray[indext*18-j] = color.y;j--;
            lineColorArray[indext*18-j] = color.z;j--;
        }
        lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        var moveDist = (point.clone()).sub(point0);

        //更新连线位置
        var linePosition = linesObject.geometry.getAttribute( 'position' );
        var linePositionArray = linePosition.array;
        linePositionArray[indext*18-7] += moveDist.z;linePositionArray[indext*18-10] += moveDist.z;
        linePositionArray[indext*18-8] += moveDist.y;linePositionArray[indext*18-11] += moveDist.y;
        linePositionArray[indext*18-9] += moveDist.x;linePositionArray[indext*18-12] += moveDist.x;

        lpoints[indext*18-7] += moveDist.z;lpoints[indext*18-10] += moveDist.z;
        lpoints[indext*18-8] += moveDist.y;lpoints[indext*18-11] += moveDist.y;
        lpoints[indext*18-9] += moveDist.x;lpoints[indext*18-12] += moveDist.x;

        linePosition.needsUpdate = true;
        //更新连线间距
        var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        var lDistanceArray = lDistance.array;
        var dis = ((new THREE.Vector3(lpoints[0],lpoints[1],lpoints[2])).distanceTo(
            new THREE.Vector3(lpoints[indext*18-10],lpoints[indext*18-11],lpoints[indext*18-12])
            ))*20;
        lDistanceArray[indext*6-1] = lDistanceArray[indext*6-2] = dis;
        lineDistance[indext*6-1] = lineDistance[indext*6-2] = dis;

        lDistance.needsUpdate = true;
    };
    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext*2;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = pointColorArray[i*3-4] = color.z;
        pointColorArray[i*3-2] = pointColorArray[i*3-5] = color.y;
        pointColorArray[i*3-3] = pointColorArray[i*3-6] = color.x;

        pointColor.needsUpdate = true;
    }

    //临时对象方法
    function createTempObject(point){
        //几何体对象
        var geometry = new THREE.Geometry();
        geometry.vertices.push( point.clone());geometry.vertices.push( point.clone() );
        //创建线对象
        tempObject = new THREE.LineSegments(geometry,new THREE.LineBasicMaterial({color:0xFFFFFF,depthTest :false}));

        editor.sceneHelpers.add(tempObject);//放入线对象
        //创建两点距离标签
        createPointLabel(point,lineDistance.length/6+1,0.00);
    }
    function deleteTempObject(){

        editor.sceneHelpers.remove(tempObject);//放入线对象
        tempObject = undefined;
    }
    function processTempObject(point){

        tempObject.geometry.vertices[1].copy(point);
        tempObject.geometry.verticesNeedUpdate =true;

        //两点距离标签更新
        var start = tempObject.geometry.vertices[0].clone();
        var distance = start.distanceTo(point).toFixed(2);
        tempLabel.position =  start.add(point).divideScalar(2.0);
        tempLabel.infor="L = "+distance+" m";
        tempLabel.innerHTML =tempLabel.infor;
    }

};