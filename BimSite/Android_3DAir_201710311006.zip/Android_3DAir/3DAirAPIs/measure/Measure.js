/**
 * Created by Administrator on 2017/2/4.
 */

THREE.Measure = function( editor,container, controls ) {

    var scope = this;

    var measureDiv=new UI.Div();
    container.add(measureDiv);

    var enable = false;
    var buttonNum = -1;

    //临时点对象
    var pointObject = document.createElement( 'div' );
    pointObject.id = "measure-point";
    container.dom.appendChild(pointObject);

    var selected=null;
    var point=new THREE.Vector2();
    var measureType = undefined;
    var tempObject = undefined;

    //测量对象
    var pointsMaterial = pointsShader();
    var lineMaterial = lineShader();
    var planeMaterial = planeShader();
    var pointMeasure = new THREE.PointMeasure(editor,this,pointsMaterial,lineMaterial);//坐标测量对象
    var twoPointsMeasure = new THREE.TwoPointsDistanceMeasure(editor,this,pointsMaterial,lineMaterial);//两点距离对象
    var pointToLineMeasure = new THREE.PointToLineDistanceMeasure(editor,this,pointsMaterial,lineMaterial);//点线距离对象
    // var twoSideMeasure = new THREE.TwoSideDistanceMeasure(editor,this,pointsMaterial,lineMaterial,planeMaterial);//两面距离对象
    var pointToPlaneMeasure = new THREE.PointToPlaneDistanceMeasure(editor,this,pointsMaterial,lineMaterial,planeMaterial);//点面距离对象
    var straightAngleMeasure = new THREE.StraightAngleMeasure(editor,this,pointsMaterial,lineMaterial);//直线夹角对象
    var threePointsAngleMeasure = new THREE.ThreePointsAngleMeasure(editor,this,pointsMaterial,lineMaterial);//三点角度对象

    this.addEvents = function(value){

        measureType = value;
        tempObject = (value=="坐标测量")?pointMeasure:
            (value=="两点距离")?twoPointsMeasure:
            (value=="点线距离")?pointToLineMeasure:
            (value=="点面距离")?pointToPlaneMeasure:
            (value=="直线夹角")?straightAngleMeasure:threePointsAngleMeasure;

        enable=true;
        container.dom.addEventListener( "mousedown", onPointerDown, false );
        container.dom.addEventListener( "mousemove", onPointerMove, false );

    };
    this.removeEvents = function(){

        (tempObject !== undefined)?tempObject.deleteTempObject():undefined;

        measureType = undefined;
        tempObject = undefined;

        enable=false;
        pointObject.style.display = 'none';
        container.dom.removeEventListener( "mousedown", onPointerDown );
        container.dom.removeEventListener( "mousemove", onPointerMove );
        container.dom.removeEventListener( "mouseup", onPointerUp );
    };

    this.clearMeasure = function(){

        measureDiv.dom.innerHTML='';
        selected=null;

        pointMeasure.clear();
        twoPointsMeasure.clear();
        // twoSideMeasure.clear();
        pointToLineMeasure.clear();
        pointToPlaneMeasure.clear();
        straightAngleMeasure.clear();
        threePointsAngleMeasure.clear();

        scope.removeEvents();
    };

    this.updatePositions = function(camera,width,height) {

        for(var i=0; i<measureDiv.dom.children.length; i++){

            var label=measureDiv.dom.children[i];

            var hh= label.offsetHeight;
            var ww= label.offsetWidth;

            var coords2d = get2DCoords(label.position.clone(),width,height,camera);

            label.style.left = (coords2d.x-ww/2) + 'px';
            label.style.top = (coords2d.y-hh/2) + 'px';
        }

        function get2DCoords(position,width,height,camera) {

            var vector = position.project(camera);

            vector.x = (vector.x +1)* width;
            vector.y = (1-vector.y) * height;

            return vector;
        }
    };

    this.restColor = function(){

        if(selected!==null){

            selected.style.color= selected.parent.restColor(selected.indext);//恢复颜色
            editor.signals.updateRender.dispatch();
        }
        selected=null;
    };
    this.selectColor = function(){

        if(selected!==null){

            selected.style.color = selected.parent.selectColor(selected.indext);//选中颜色
        }
    };

    this.addLabelEvents = function(label){

        label.addEventListener('mousedown', mousedown, false);

        //event
        var mouseX,mouseY;
        function mousedown(event){

            if(THREE_DissectEnabled || enable || event.button !== 0 )return;

            editor.signals.setViewEvent.dispatch(false);//撤销主鼠标监听事件
            event.preventDefault();

            var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
            mouseX = pointer.clientX;mouseY = pointer.clientY;

            if(selected !== label){

                scope.restColor();//还原颜色
                selected=label;
                scope.selectColor();//选中颜色

                editor.signals.updateRender.dispatch();
            }

            document.addEventListener( 'mousemove', mousemove, false );
            document.addEventListener('mouseup', mouseup, false);
        }
        function mousemove(event){

            var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
            if(mouseX == pointer.clientX && mouseY == pointer.clientY)return;

            var rect = container.dom.getBoundingClientRect();
            var hh= label.offsetHeight;
            var ww= label.offsetWidth;
            ww = pointer.clientX-rect.left-ww/2;
            hh = pointer.clientY-rect.top-hh/2;

            label.style.left = ww+ 'px';
            label.style.top = hh + 'px';

        }
        function mouseup(event){

            event.preventDefault();

            var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
            if(mouseX !== pointer.clientX && mouseY !== pointer.clientY){

                point.fromArray( THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY ) );
                THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),label.position.clone() );
                raycaster.setFromCamera( point, editor.camera );
                var intersection = new THREE.Vector3();
                if ( raycaster.ray.intersectPlane( THREE_Plane, intersection ) ) {

                    updateLinePosition(intersection); //更新连线位置数据
                    label.position = intersection;
                    editor.signals.updateRender.dispatch();
                }
            }

            document.removeEventListener( 'mousemove', mousemove );
            document.removeEventListener('mouseup', mouseup );

            editor.signals.setViewEvent.dispatch(true);

        }

        measureDiv.dom.appendChild(label);
    };
    this.removeLabel = function(label){

        measureDiv.dom.removeChild(label);//appendChild(label);
    };

    function fromObject(){

        for(var i =0;i<editor.measureGroupHelpers.children.length;){

            var object = editor.measureGroupHelpers.children[i++];
            switch(object.name){
                case 'PM':
                    pointMeasure.fromObject(object,editor.measureGroupHelpers.children[i++]);
                break;
                case 'TPDM':
                    twoPointsMeasure.fromObject(object,editor.measureGroupHelpers.children[i++]);
                break;
                case 'PTLDM':
                    pointToLineMeasure.fromObject(object,editor.measureGroupHelpers.children[i++]);
                break;
                case 'PTPDM':
                    pointToPlaneMeasure.fromObject(object,editor.measureGroupHelpers.children[i++],editor.measureGroupHelpers.children[i++]);
                break;
                case 'SAM':
                    straightAngleMeasure.fromObject(object,editor.measureGroupHelpers.children[i++]);
                break;
                case 'TPAM':
                    threePointsAngleMeasure.fromObject(object,editor.measureGroupHelpers.children[i++]);
                break;
                default:
                    i++;
            }
        }
    }
    this.toJSON = function(){

        var output = {};
        output.measureLabel =[];

        for(var i=0; i<measureDiv.dom.children.length; i++){

            var label=measureDiv.dom.children[i];

            var labelInfor = {
                point:label.position,
                infor:label.infor,
                indext:label.indext,
                parent: label.parent.name,
                color:label.style.color
            };

            output.measureLabel.push(labelInfor);
        }
        output.type = 'THREE_measureLabel';
        return output;
    };
    this.fromJSON = function(data){

        fromObject();//进行测量物体初始化

        // for(var i=0; i< data.length; i++){
        //
        //     var inform = data[i];
        //     var point = new THREE.Vector3(inform.point.x,inform.point.y,inform.point.z);
        //
        //     var label = document.createElement( 'div' );
        //     label.id = "measure-lable";
        //
        //     label.position=point;
        //     label.infor=inform.infor;
        //     label.indext = inform.indext;
        //     label.parent =(inform.parent=='PM')?pointMeasure:
        //         (inform.parent=='TPDM')?twoPointsMeasure:
        //         (inform.parent=='PTLDM')?pointToLineMeasure:
        //         // (inform.parent=='TSDM')?twoSideMeasure:
        //         (inform.parent=='PTPDM')?pointToPlaneMeasure:
        //         (inform.parent=='SAM')?straightAngleMeasure:threePointsAngleMeasure;
        //
        //     label.style.whiteSpace='pre';
        //     label.style.color = inform.color;
        //     label.innerHTML=label.infor;
        //
        //     scope.addLabelEvents(label);
        //
        // }
    };

    function updateLinePosition(point){

        if(selected!==null)selected.parent.updateLinePosition(selected.indext,point,selected.position); //更新连线位置数据
    }
    //event
    function onPointerDown(event){

        buttonNum = event.button;
        if(!enable ||  buttonNum!== 0 )return;

        event.preventDefault();

        var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
        point.fromArray( THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY ) );

        var intersects = THREE_getIntersects(point, editor.camera, editor.sceneGroup.children,true);
        if (intersects.length > 0) {

            tempObject.onPointerDown(event,intersects[0].point,intersects[0].face,intersects[0].object);

            editor.signals.updateRender.dispatch();
            container.dom.removeEventListener( "mousemove", onPointerMove );
            container.dom.addEventListener( "mouseup", onPointerUp, false );
        }
    }
    function onPointerMove(event){

        var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
        point.fromArray( THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY ) );

        var intersects = THREE_getIntersects(point, editor.camera, editor.sceneGroup.children,true);
        if (intersects.length > 0) {

            pointObject.style.display = 'inline';

            var rect = container.dom.getBoundingClientRect();
            var hh= pointObject.offsetHeight;
            var ww= pointObject.offsetWidth;
            ww = pointer.clientX-rect.left-ww/2;
            hh = pointer.clientY-rect.top-hh/2;

            pointObject.style.left = ww+ 'px';
            pointObject.style.top = hh + 'px';

            tempObject.onPointerMove(event,intersects[0].point,intersects[0].face,intersects[0].object);
        }else {
            pointObject.style.display = 'none';
        }

        editor.signals.updateRender.dispatch();
    }
    function onPointerUp(event){

        tempObject.onPointerUp(event);
        container.dom.addEventListener( "mousemove", onPointerMove, false );
        container.dom.removeEventListener( "mouseup", onPointerUp );
    }

    //点材质
    function pointsShader(){

        var pointShader = THREE.ShaderLib[ "pointShader" ];
        var pointUniforms = THREE.UniformsUtils.clone( pointShader.uniforms );

        return (new THREE.ShaderMaterial( {
            depthTest :false,
            uniforms: pointUniforms,
            vertexShader:  pointShader.vertexShader,
            fragmentShader:  pointShader.fragmentShader
        } ));
    }
    //连线材质
    function lineShader(){

        var lineShader = THREE.ShaderLib[ "lineShader" ];
        var lineUniforms = THREE.UniformsUtils.clone( lineShader.uniforms );

        return (new THREE.ShaderMaterial( {
            depthTest :false,
            uniforms: lineUniforms,
            vertexShader:  lineShader.vertexShader,
            fragmentShader:  lineShader.fragmentShader
        } ));
    }
    //平面材质
    function planeShader(){

        var planeShader = THREE.ShaderLib[ "InstancedPlane" ];
        var planeUniforms = THREE.UniformsUtils.clone( planeShader.uniforms );

        return (new THREE.ShaderMaterial( {

            uniforms: planeUniforms,
            vertexShader:  planeShader.vertexShader,
            fragmentShader:  planeShader.fragmentShader,
            opacity:0.2,
            side:THREE.DoubleSide,
            transparent: true,
            depthTest :false
        } ));
    }

    //绘制2D数据
    editor.signals.drawImage.add( drawImage );
    function drawImage(context,height){

        for(var i=0; i<measureDiv.dom.children.length; i++){

            var label=measureDiv.dom.children[i];
            var offsetX = parseInt(((label.style.left).split("px"))[0]);
            var offsetY = parseInt(((label.style.top).split("px"))[0]);

            context.font=label.style.fontSize;
            context.textAlign="center";
            context.textBaseline="middle";
            context.whiteSpace = label.style.whiteSpace;
            context.fillStyle=label.style.color;
            context.fillText(label.innerHTML,offsetX+label.offsetWidth/2,offsetY+label.offsetHeight/2);

        }
    }
};