/**
 * Created by Administrator on 2017/2/15.
 */
THREE.PointToLineDistanceMeasure = function( editor, measure,pointsMaterial,lineMaterial ) {

    var scope = this;
//点对象相关变量
    var pointsObject = undefined;
    var points = [];
    var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];
    var lcolors = [];
    var lineDistance =[];//长度数据
    var indexts =[];
    var count =0;

    var color = new THREE.Vector3( 1.0,0.74117647058824 ,0.098039215686275 );
    var tempObject = undefined;
    var tempObject0 = undefined;
    var line = undefined;

    this.name = 'PTLDM';

    this.restColor = function(indext){

        updatePointColor(indext,color);//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        return '#ffbd19';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        return 'red';
    };
    //当处于创建过程时，则删除临时对象
    this.deleteTempObject = function(){

        deleteTempObject0();
        deleteTempObject();
        editor.signals.updateRender.dispatch();
    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
        indexts =[];count =0;

        deleteTempObject0();
        deleteTempObject();
    };

    this.onPointerDown = function(event,point,face,object){

        if(tempObject !== undefined){

            createPointAndLine();

            deleteTempObject0();
            deleteTempObject();
        }else {
            createTempObject(point);
        }
    };
    this.onPointerMove = function(event,point,face,object){

        if(tempObject !== undefined){

            line = undefined;
            line  = createTempLine(face,object);
            line.updateMatrixWorld(true);
            var intersects = raycaster.intersectObject( line);

            if (intersects.length > 0) {

                var i = intersects[0].index;
                var start = line.geometry.vertices[i].clone();
                var end = line.geometry.vertices[i+1].clone();
                createTempObject0(start,end,object);
            }else{

                if(tempObject0!==undefined)tempObject0.visible = false;
            }
        }
    };
    this.onPointerUp = function(event){

    };

    this.fromObject = function(object0,object1){

        var positions = (object1.geometry.getAttribute( 'position' )).array;
        var pcolors = (object1.geometry.getAttribute( 'customColor' )).array;
        for(var i =0;i<positions.length/3;i++){

            points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
            colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        }
        createPoints();

        var len = lineDistance.length/7+1;
        var lpositions = (object0.geometry.getAttribute( 'position' )).array;
        var lpcolors = (object0.geometry.getAttribute( 'color' )).array;
        var ld = (object0.geometry.getAttribute( 'lineDistance' )).array;
        for(var j =0;j<lpositions.length/3;j++){

            lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
            lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
            lineDistance.push(ld[j]);
        }
        var lindexs = (object0.geometry.getIndex()).array;
        for(var k =0;k<lindexs.length;k++){

            indexts.push(lindexs[k]);
        }
        createLine();

        for(var t =len;t<=lineDistance.length/7;t++){

            var start = new THREE.Vector3(lpoints[t*21-9],lpoints[t*21-8],lpoints[t*21-7]);
            var end = new THREE.Vector3(lpoints[t*21-12],lpoints[t*21-11],lpoints[t*21-10]);
            createPointLabel(((start.clone()).add(end).multiplyScalar(0.5)),t,(start.distanceTo(end)));
        }
    };

    function createPointAndLine(){

        var a = new THREE.Vector3();
        var b = new THREE.Vector3();
        var c = tempObject.position.clone();
        var distance = 0;

        if(pointToLineDistance()){

            points.push(b.x,b.y,b.z,c.x,c.y,c.z);
            colors.push(color.x,color.y,color.z,color.x,color.y,color.z);
            createPoints();

            //向顶点数据中加入顶点数据
            lpoints.push(a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z);//不动线
            lpoints.push(b.x,b.y,b.z,c.x,c.y,c.z,b.x,b.y,b.z,c.x,c.y,c.z);
            //
            lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
            lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
            //向长度数据中加入长度数据
            var dis = c.distanceTo(b);
            lineDistance.push(0,0, dis*10, 0,0, 60,60);
            //索引值数据
            indexts.push(count*7,count*7+1, count*7+1,count*7+2,count*7+3,count*7+4, count*7+3,count*7+5,count*7+4,count*7+6);
            createLine();

            createPointLabel(((c.add(b)).multiplyScalar(0.5)),lineDistance.length/7,distance);
        }

        //计算点到线的最短距离---p到ab的距离
        function pointToLineDistance(){

            var p = tempObject.position.clone();
            var la = tempObject0.geometry.vertices[0].clone();
            var lb = tempObject0.geometry.vertices[1].clone();

            var lab = (lb.clone()).sub(la);
            var lap = p.sub(la);

            var n = lap.cross(lab);
            distance = (n.length())/(lab.length());
            if(distance<0.005){

                // alert("点到线的距离小于0.005!");
                console.log("点到线的距离小于0.005!");
                return false;
            }

            var nor = n.cross(lab).normalize();
            b = nor.multiplyScalar(distance).add(c);
            // console.log((b.distanceTo(c)));
            a = (la.distanceToSquared(b)>lb.distanceToSquared(b))?la:lb;

            return true;
        }
    }
    function createPoints(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name='PTLDM';

        editor.measureGroup.add(pointsObject);//放入线对象
    }
    function createLine(){//abc
        /*
         c(4)0- - -1(5)b- - - -6a
         |     |
         |     |
         2-----3
         */
        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indexts ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name='PTLDM';

        count = lpoints.length/21;

        editor.measureGroup.add(linesObject);//放入线对象
    }
    function createPointLabel(apoint,len,distance){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="L = "+(distance.toFixed(3))+" m";
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#ffbd19';
        label.innerHTML=label.infor;

        measure.addLabelEvents(label);
    }

    //更新连线颜色--7个点
    function updateLineColor(indext,color){

        var lineColor = linesObject.geometry.getAttribute( 'color' );
        var lineColorArray = lineColor.array;
        for(var j =21;j>0;){

            lineColorArray[indext*21-j] = color.x;j--;
            lineColorArray[indext*21-j] = color.y;j--;
            lineColorArray[indext*21-j] = color.z;j--;
        }

        lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        var moveDist = (point.clone()).sub(point0);

        //更新连线位置
        var linePosition = linesObject.geometry.getAttribute( 'position' );
        var linePositionArray = linePosition.array;
        linePositionArray[indext*21-7] += moveDist.z;linePositionArray[indext*21-10] += moveDist.z;
        linePositionArray[indext*21-8] += moveDist.y;linePositionArray[indext*21-11] += moveDist.y;
        linePositionArray[indext*21-9] += moveDist.x;linePositionArray[indext*21-12] += moveDist.x;
        lpoints[indext*21-7] += moveDist.z;lpoints[indext*21-10] += moveDist.z;
        lpoints[indext*21-8] += moveDist.y;lpoints[indext*21-11] += moveDist.y;
        lpoints[indext*21-9] += moveDist.x;lpoints[indext*21-12] += moveDist.x;

        linePosition.needsUpdate = true;
        //更新连线间距
        var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        var lDistanceArray = lDistance.array;
        var dis = ((new THREE.Vector3(lpoints[indext*21-3],lpoints[indext*21-2],lpoints[indext*21-1])).distanceTo(
                new THREE.Vector3(lpoints[indext*21-9],lpoints[indext*21-8],lpoints[indext*21-7])
            ))*20;
        lDistanceArray[indext*7-1] = lDistanceArray[indext*7-2] = dis;
        lineDistance[indext*7-1] = lineDistance[indext*7-2] = dis;

        lDistance.needsUpdate = true;
    };
    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext*2;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = pointColorArray[i*3-4] = color.z;
        pointColorArray[i*3-2] = pointColorArray[i*3-5] = color.y;
        pointColorArray[i*3-3] = pointColorArray[i*3-6] = color.x;

        pointColor.needsUpdate = true;
    }

    //临时对象方法
    function createTempObject(point){

        tempObject=new THREE.Points(
            (function(){
                var geometry = new THREE.Geometry();
                geometry.vertices.push( new THREE.Vector3(0,0,0) );
                return geometry;
            })(),
            new THREE.PointsMaterial( { size: 4, sizeAttenuation: false,color: 0xFFFFFF, depthTest :false } )
        );

        tempObject.position.copy(point);
        editor.sceneHelpers.add(tempObject);//放入对象
    }
    function deleteTempObject(){

        editor.sceneHelpers.remove(tempObject);
        tempObject = undefined;
    }

    function createTempObject0(start,end){

        var visible = (tempObject0!==undefined);
        var geometry = (visible)?tempObject0.geometry:new THREE.Geometry();

        geometry.vertices[0] = start;
        geometry.vertices[1] = end;

        if(!visible){

            tempObject0 = new THREE.LineSegments( geometry,new THREE.LineBasicMaterial( { color: 0xFFFF00 } ) );
            editor.sceneHelpers.add(tempObject0);//放入线对象
        }else{

            tempObject0.geometry.verticesNeedUpdate =true;
        }

        tempObject0.visible = true;
    }
    function deleteTempObject0(){

        editor.sceneHelpers.remove(tempObject0);//放入线对象
        tempObject0 = undefined;
    }

    function createTempLine(face,object){

        var geometry = new THREE.Geometry();

        var point0 = (object.geometry.vertices[face.a].clone()).applyMatrix4(object.matrixWorld);
        var point1 = (object.geometry.vertices[face.b].clone()).applyMatrix4(object.matrixWorld);
        var point2 = (object.geometry.vertices[face.c].clone()).applyMatrix4(object.matrixWorld);

        geometry.vertices[0] = geometry.vertices[5] = point0;
        geometry.vertices[1] = geometry.vertices[2] = point1;
        geometry.vertices[3] = geometry.vertices[4] = point2;

        var color = new THREE.Color(0xFFC0CB);
        geometry.colors[0] = color;geometry.colors[1] = color;
        geometry.colors[2] = color;geometry.colors[3] = color;
        geometry.colors[4] = color;geometry.colors[5] = color;

        line = new THREE.LineSegments( geometry,new THREE.LineBasicMaterial( { vertexColors: THREE.VertexColors } ) );

        return line;
    }

};