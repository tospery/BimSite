/**
 * Created by Administrator on 2016/10/12.
 */
CubeCamera = function ( editor , transformControls ) {

    var scene = new THREE.Scene();

    var ortCamera = new THREE.OrthographicCamera(-1, 1, 1, -1,1, 500);
    ortCamera.position.set(10,10,10);//设置摄像机位置
    ortCamera.lookAt(scene.position);

    var cube=[];//前，后，左，右，上，下
    var cubeName=[
        "前左上角","前右上角","前右下角","前左下角",
        "后左上角","后右上角","后右下角","后左下角",
        "前","后","左","右","上","下"
    ];
    var controls ;
    var SELECTED;

    cubeControls();
    function cubeControls(){
        //cube操控器对象
        var points=[
            -0.4,0.4,0.4,0.4,0.4,0.4,
            0.4,-0.4,0.4,-0.4,-0.4,0.4,

            -0.4,0.4,-0.4,0.4,0.4,-0.4,
            0.4,-0.4,-0.4, -0.4,-0.4,-0.4
        ];
        var cubeGeo;
        for ( var i=0; i < points.length/3; i ++ ) {
            cubeGeo = new THREE.BoxGeometry(0.2,0.2,0.2,1,1,1);
            cubeGeo.translate(points[3*i],points[3*i+1],points[3*i+2]);
            cube[i]=new THREE.Mesh(cubeGeo, new THREE.MeshBasicMaterial({color: 0xFFFFFF}));
            cube[i].name=cubeName[i];
            scene.add(cube[i]);
        }

        var plane = new THREE.BufferGeometry();
        var positions = [];
        var uvs = [];
        var indices_array =[1,4,3,3,2,1, 4,7,6,6,5,4, 7,10,9,9,8,7, 10,1,0,0,11,10, 1,10,7,7,4,1];
        var vertices=[
            -0.5,0.3, -0.3,0.3, -0.3,0.5, 0.3,0.5, 0.3,0.3, 0.5,0.3,
            0.5,-0.3, 0.3,-0.3, 0.3,-0.5, -0.3,-0.5, -0.3,-0.3, -0.5,-0.3
        ];
        var us=[
            0,0.8, 0.2,0.8, 0.2,1.0, 0.8,1.0, 0.8,0.8, 1.0,0.8,
            1.0,0.2, 0.8,0.2, 0.8,0, 0.2,0, 0.2,0.2, 0,0.2
        ];

        for(var j=0;j<vertices.length/2;j++){

            positions.push(vertices[2*j],vertices[2*j+1],0.0);
            uvs.push(us[2*j],us[2*j+1]);
        }
        plane.setIndex( new THREE.BufferAttribute( new Uint16Array( indices_array ), 1 ) );
        plane.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( positions ), 3 ) );
        plane.addAttribute( 'uv', new THREE.BufferAttribute( new Float32Array( uvs ), 2 ) );

        var textLoader = new THREE.TextureLoader();
        var indext=0;

        //前
        textLoader.load(THREE_PATH+'3DAirAPIs/Textures/5.jpg',function ( texture ) {
            var geometry = plane.clone();
            geometry.translate(0,0,0.5);
            cube[8] = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({map: texture,transparent:true}));
            //,color: 0x4682B4,transparent:true,opacity:0.4}));
            cube[8].name=cubeName[8];
            scene.add(cube[8]);

            indext++;
            if(indext==6)editor.signals.windowResize.dispatch();
        });
        //后
        textLoader.load(THREE_PATH+'3DAirAPIs/Textures/6.jpg',function ( texture ) {
            var geometry = plane.clone();
            geometry.rotateY( Math.PI );
            geometry.translate(0,0,-0.5);
            cube[9] = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({map: texture,transparent:true}));
            cube[9].name=cubeName[9];
            scene.add(cube[9]);

            indext++;
            if(indext==6)editor.signals.windowResize.dispatch();
        });
        //左
        textLoader.load(THREE_PATH+'3DAirAPIs/Textures/2.jpg',function ( texture ) {
            var geometry = plane.clone();
            geometry.rotateY(- Math.PI / 2);
            geometry.translate(-0.5,0,0);
            cube[10] = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({map: texture,transparent:true}));
            cube[10].name=cubeName[10];
            scene.add(cube[10]);

            indext++;
            if(indext==6)editor.signals.windowResize.dispatch();
        });
        //右
        textLoader.load(THREE_PATH+'3DAirAPIs/Textures/1.jpg',function ( texture ) {
            var geometry = plane.clone();
            geometry.rotateY( Math.PI / 2);
            geometry.translate(0.5,0,0);
            cube[11] = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({map: texture,transparent:true}));
            cube[11].name=cubeName[11];
            scene.add(cube[11]);

            indext++;
            if(indext==6)editor.signals.windowResize.dispatch();
        });
        //上
        textLoader.load(THREE_PATH+'3DAirAPIs/Textures/3.jpg',function ( texture ) {
            var geometry = plane.clone();
            geometry.rotateX(- Math.PI / 2);
            geometry.translate(0,0.5,0);
            cube[12] = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({map: texture,transparent:true}));
            cube[12].name=cubeName[12];
            scene.add(cube[12]);

            indext++;
            if(indext==6)editor.signals.windowResize.dispatch();
        });
        //下
        textLoader.load(THREE_PATH+'3DAirAPIs/Textures/4.jpg',function ( texture ) {
            var geometry = plane.clone();
            geometry.rotateX( Math.PI / 2);
            geometry.translate(0,-0.5,0);
            cube[13] = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({map: texture,transparent:true}));
            cube[13].name=cubeName[13];
            scene.add(cube[13]);

            indext++;
            if(indext==6)editor.signals.windowResize.dispatch();
        });

        cubeGeo = new THREE.PlaneGeometry(1.2,1.2,1,1);
        cubeGeo.rotateX( -Math.PI / 2);
        var mesh = new THREE.Mesh(cubeGeo,
            new THREE.MeshBasicMaterial({color: 0x4682B4, opacity:0.2, transparent:true,side:THREE.DoubleSide}));
        mesh.position.set(0,-0.6,0);
        scene.add(mesh);
    }

    var enabled=true;

    var renderer;
    var dom;

    this.setRenderer=function(rend,domElement){

        renderer=rend;
        dom=domElement;

        controls = new THREE.CubeControls(ortCamera,renderer.domElement);
        controls.addEventListener( 'start', function () {

            THREE_LabelEnable = false;
            editor.signals.cameraChangedStart.dispatch(ortCamera);

        } );
        controls.addEventListener( 'end', function () {

            THREE_LabelEnable = true;
            divEnabled=false;
            editor.signals.cameraChangedEnd.dispatch(ortCamera);

        } );
        dom.addEventListener( 'mousedown', onDocumentMouseDown, false );
        dom.addEventListener( 'touchstart', onDocumentMouseDown, false );

    };

    this.updateRenderer=function(rend) {

        renderer=rend;
        controls.domElement=renderer.domElement;
        controls.updateDomElement();
    };

    this.getCamPos = function(){
        return ortCamera.position;
    };
    this.setCamera = function(position,up){

        ortCamera.position.set(position.x,position.y,position.z);
        ortCamera.up.set(up.x,up.y,up.z);
        controls.update();
    };

    this.sizeChange=function(){

        THREE_offset=(dom.offsetWidth>dom.offsetHeight)?dom.offsetHeight*0.13:dom.offsetWidth*0.13;
    };

    this.clear=function(){

        controls.reset();
    };

    this.setView = function(id){

        rotateCamera(cubeName[id]);
    };

    this.renderScene=function(){

        renderer.clearDepth();
        renderer.setViewport(dom.offsetWidth-THREE_offset,dom.offsetHeight-THREE_offset,THREE_offset,THREE_offset);
        renderer.render(scene,ortCamera);//绘制右上角的正方体

    };

    this.setControls=function(value){
        controls.enabled=value;
        enabled=value;
    };

    var mouse = new THREE.Vector2();
    var raycaster = new THREE.Raycaster();

    var onDownPosition = new THREE.Vector2();
    var onUpPosition = new THREE.Vector2();

    function getIntersects( point, objects ) {

        mouse.set( ( point.x * 2 ) - 1, - ( point.y * 2 ) + 1 );

        raycaster.setFromCamera( mouse, ortCamera );

        return raycaster.intersectObjects( objects );

    }

    function getMousePosition(  x, y ) {

        var rect = dom.getBoundingClientRect();
        return [ ( x - (rect.left+rect.width-THREE_offset) ) / THREE_offset, ( y - rect.top) / THREE_offset ];

    }

    function onDocumentMouseDown(event){

        if ( enabled === false ) return;
        event.preventDefault();

        var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;

        var array = getMousePosition(  pointer.clientX, pointer.clientY );
        onDownPosition.fromArray( array );

        renderer.domElement.removeEventListener( 'mousemove', onDocumentMousemove, false );
        renderer.domElement.addEventListener( "mouseup", onDocumentMouseup,false );

        renderer.domElement.addEventListener( "touchend", onDocumentMouseup,false );
    }
    function onDocumentMousemove(event){

        event.preventDefault();

        var point=new THREE.Vector2();
        point.fromArray( getMousePosition(  event.clientX, event.clientY ) );
        var intersects = getIntersects( point, cube );
        if ( intersects.length > 0 ) {//如果判断鼠标投射到了物体上
            if ( SELECTED != intersects[ 0 ].object ) {

                if ( SELECTED ) SELECTED.material.color.setHex( SELECTED.currentHex );

                SELECTED = intersects[ 0 ].object;
                SELECTED.currentHex = SELECTED.material.color.getHex();
                SELECTED.material.color.setHex( 0xB0E0E6 );

                editor.signals.cameraChanged.dispatch(ortCamera);
            }
        }else {
            if ( SELECTED ) {
                SELECTED.material.color.setHex( SELECTED.currentHex );

                editor.signals.cameraChanged.dispatch(ortCamera);
            }
            SELECTED = null;
        }

    }
    function onDocumentMouseup(event){

        var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;

        var array = getMousePosition( pointer.clientX, pointer.clientY );
        onUpPosition.fromArray( array );

        //点击事件
        if ( onDownPosition.distanceTo( onUpPosition ) === 0 ) {

            var intersects = getIntersects( onUpPosition, cube );
            if ( intersects.length > 0 ) {

                    var INTERSECTED = intersects[0].object;
                    rotateCamera(INTERSECTED.name);
                    console.log("INTERSECTED.name="+INTERSECTED.name);
            }

        }

        renderer.domElement.addEventListener( 'mousemove', onDocumentMousemove, false );
        renderer.domElement.removeEventListener( 'mouseup', onDocumentMouseup, false );

        renderer.domElement.removeEventListener( "touchend", onDocumentMouseup,false );

    }

    function rotateCamera(name){

        var distion=controls.getDistance();
        var cDistion = transformControls.getDistance();

        var TanValue=0.7071067812;
        var disY=distion*TanValue;
        var disXZ=disY*TanValue;

        var cDisY=cDistion*TanValue;
        var cDisXZ=cDisY*TanValue;

        editor.signals.setEditorCenter.dispatch();
        var center=transformControls.center;

        var delta=new THREE.Vector3();

        switch(name){
            case '前':

                delta.set(0,1,0);
                controls.rotateFace(delta,0,0,distion);
                transformControls.rotateFace(delta,center.x,center.y,cDistion+center.z);

            break;
            case '后':

                delta.set(0,1,0);
                controls.rotateFace(delta,0,0,-distion);
                transformControls.rotateFace(delta,center.x,center.y,-cDistion+center.z);

            break;
            case '左':

                delta.set(0,1,0);
                controls.rotateFace(delta,-distion,0,0);
                transformControls.rotateFace(delta,-cDistion+center.x,center.y,center.z);

            break;
            case '右':

                delta.set(0,1,0);
                controls.rotateFace(delta,distion,0,0);
                transformControls.rotateFace(delta,cDistion+center.x,center.y,center.z);

            break;
            case '上':

                delta.set(0,0,-1);
                controls.rotateFace(delta,0,distion,0);
                transformControls.rotateFace(delta,center.x,cDistion+center.y,center.z);

            break;
            case '下':

                delta.set(0,0,1);
                controls.rotateFace(delta,0,-distion,0);
                transformControls.rotateFace(delta,center.x,-cDistion+center.y,center.z);

            break;

            case '前左上角':

                delta.set(1,1,-1);
                controls.rotateFace(delta,-disXZ,disY,disXZ);
                transformControls.rotateFace(delta,-cDisXZ+center.x,cDisY+center.y,cDisXZ+center.z);

            break;
            case '前右上角':

                delta.set(-1,1,-1);
                controls.rotateFace(delta,disXZ,disY,disXZ);
                transformControls.rotateFace(delta,cDisXZ+center.x,cDisY+center.y,cDisXZ+center.z);

            break;
            case '前右下角':

                delta.set(1,-1,1);
                controls.rotateFace(delta,disXZ,-disY,disXZ);
                transformControls.rotateFace(delta,cDisXZ+center.x,-cDisY+center.y,cDisXZ+center.z);

            break;
            case '前左下角':

                delta.set(-1,-1,1);
                controls.rotateFace(delta,-disXZ,-disY,disXZ);
                transformControls.rotateFace(delta,-cDisXZ+center.x,-cDisY+center.y,cDisXZ+center.z);

            break;
            case '后左上角':

                delta.set(1,1,1);
                controls.rotateFace(delta,-disXZ,disY,-disXZ);
                transformControls.rotateFace(delta,-cDisXZ+center.x,cDisY+center.y,-cDisXZ+center.z);

            break;
            case '后右上角':

                delta.set(-1,1,1);
                controls.rotateFace(delta,disXZ,disY,-disXZ);
                transformControls.rotateFace(delta,cDisXZ+center.x,cDisY+center.y,-cDisXZ+center.z);

            break;
            case '后右下角':

                delta.set(1,-1,-1);
                controls.rotateFace(delta,disXZ,-disY,-disXZ);
                transformControls.rotateFace(delta,cDisXZ+center.x,-cDisY+center.y,-cDisXZ+center.z);

            break;
            case '后左下角':

                delta.set(-1,-1,-1);
                controls.rotateFace(delta,-disXZ,-disY,-disXZ);
                transformControls.rotateFace(delta,-cDisXZ+center.x,-cDisY+center.y,-cDisXZ+center.z);

            break;

        }
        //console.log("ortCamera:"+ortCamera.position.x+";"+ortCamera.position.y+";"+ortCamera.position.z);
    }

};