/**
 * Created by Administrator on 2016/10/12.
 */
THREE.CubeControls = function ( object, domElement  ) {

    this.object = object;

    this.domElement = ( domElement !== undefined ) ? domElement : document;

    this.enabled = true;
    this.target = new THREE.Vector3();

    this.enableRotate = true;
    this.rotateSpeed = 1.0;

    // Mouse buttons
    this.mouseButtons = { ORBIT: THREE.MOUSE.LEFT, ZOOM: THREE.MOUSE.MIDDLE, PAN: THREE.MOUSE.RIGHT };

    this.target0 = this.target.clone();
    this.position0 = this.object.position.clone();
    this.up0 = this.object.up.clone();

    this.update = function() {

        return function () {

            var normal =scope.object.up.clone();
            var nor=new THREE.Vector3().subVectors(scope.object.position,scope.target);
            var normalX=new THREE.Vector3().crossVectors(nor,normal);

            var rotateOnlyMatrix = new THREE.Matrix4();
            rotateOnlyMatrix.makeRotationAxis(normal.normalize(), -rotateDelta.x* scope.rotateSpeed);
            rotateOnlyMatrix.multiplyMatrices(new THREE.Matrix4().makeRotationAxis(normalX.normalize(), rotateDelta.y* scope.rotateSpeed ), rotateOnlyMatrix);

            scope.object.position.applyMatrix4(rotateOnlyMatrix);
            scope.object.up.applyMatrix4(rotateOnlyMatrix);
            scope.object.up.normalize();
            //
            scope.target.applyMatrix4(rotateOnlyMatrix);
            scope.object.lookAt(scope.target);

            return false;
        };
    }();

    this.getDistance = function(){

        var distance = scope.object.position.distanceTo( scope.target );
        return distance;
    };

    this.rotateFace = function(up,cx,cy,cz){

        scope.object.position.set(cx,cy,cz);
        scope.object.up.set(up.x,up.y,up.z);
        scope.object.lookAt(scope.target);
    };

    this.reset = function(){

        scope.target.copy( scope.target0 );
        scope.object.position.copy( scope.position0 );
        scope.object.up.copy( scope.up0 );
        scope.object.updateProjectionMatrix();

        rotateDelta.set(0,0);
        scope.update();

        state = STATE.NONE;

    };

    this.updateDomElement= function(){

        scope.domElement.addEventListener( 'mousedown', onCMouseDown, false );
        scope.domElement.addEventListener( 'touchstart', onTouchStart, false );
        //scope.domElement.addEventListener( 'touchend', onTouchEnd, false );
        //scope.domElement.addEventListener( 'touchmove', onTouchMove, false );
    };

    var scope = this;

    var startEvent = { type: 'start' };
    var endEvent = { type: 'end' };
    //var changeEvent = { type: 'change' };

    var STATE = { NONE : - 1, ROTATE : 0, DOLLY : 1, PAN : 2, TOUCH_ROTATE : 3, TOUCH_DOLLY : 4, TOUCH_PAN : 5 };

    var state = STATE.NONE;
    var rotateStart = new THREE.Vector2();
    var rotateEnd = new THREE.Vector2();
    var rotateDelta = new THREE.Vector2();

    function handleMouseDownRotate( event ) {

        //console.log( 'handleMouseDownRotate' );
        rotateStart.set( event.clientX, event.clientY );
    }
    function handleMouseMoveRotate( event ) {

        //console.log( 'handleMouseMoveRotate' );

        rotateEnd.set( event.clientX, event.clientY );

        rotateDelta.subVectors( rotateEnd, rotateStart );
        rotateDelta.x *=THREE_rotateSpeedX;
        rotateDelta.y *=THREE_rotateSpeedY;

        rotateStart.copy( rotateEnd );

        scope.update();

        //scope.dispatchEvent( changeEvent );

    }
    function handleMouseUp( event ) {

        //console.log( 'handleMouseUp' );

    }

    function onCMouseDown( event ) {

        if ( scope.enabled === false ) return;

        event.preventDefault();

        if ( event.button === scope.mouseButtons.ORBIT || event.button === 2) {


            if ( scope.enableRotate === false ) return;

            if(event.button!=2 && !THREE_KEY){

                THREE_rotateSpeedX = 0.05;
                THREE_rotateSpeedY = 0.05;

                var rect = scope.domElement.getBoundingClientRect();
                var touchX=event.clientX-(rect.left+rect.width-THREE_offset);
                if(touchX<0||event.clientY<rect.top||event.clientY>(THREE_offset+rect.top))return;
            }

            handleMouseDownRotate( event );

            state = STATE.ROTATE;

        }

        if ( state !== STATE.NONE ) {

            scope.domElement.addEventListener( 'mousemove', onCMouseMove, false );
            //scope.domElement.addEventListener( 'mouseup', onCMouseUp, false );
            document.addEventListener( 'mouseup', onCMouseUp, false );
            //scope.domElement.addEventListener( 'mouseout', onCMouseUp, false );

            scope.dispatchEvent( startEvent );

        }

    }
    function onCMouseMove( event ) {

        if ( scope.enabled === false ) return;

        if ( state === STATE.ROTATE ) {

            divEnabled=true;

            if ( scope.enableRotate === false ) return;
            if(rotateStart.x==event.clientX&&rotateStart.y==event.clientY)return;
            handleMouseMoveRotate( event );

        }

    }
    function onCMouseUp( event ) {

        if ( scope.enabled === false ) return;

        handleMouseUp( event );

        scope.domElement.removeEventListener( 'mousemove', onCMouseMove, false );
        document.removeEventListener( 'mouseup', onCMouseUp, false );
        //scope.domElement.removeEventListener( 'mouseup', onCMouseUp, false );
        //scope.domElement.removeEventListener( 'mouseout', onCMouseUp, false );

        scope.dispatchEvent( endEvent );

        state = STATE.NONE;

    }

    function handleTouchStartRotate( event ) {

        //console.log( 'handleTouchStartRotate' );
        rotateStart.set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY );

    }
    function handleTouchMoveRotate( event ) {

        //console.log( 'handleTouchMoveRotate' );

        rotateEnd.set( event.touches[ 0 ].pageX, event.touches[ 0 ].pageY );

        rotateDelta.subVectors( rotateEnd, rotateStart );
        rotateDelta.x *=THREE_rotateSpeedX;
        rotateDelta.y *=THREE_rotateSpeedY;

        rotateStart.copy( rotateEnd );

        scope.update();

    }
    function handleTouchEnd( event ) {

        //console.log( 'handleTouchEnd' );

    }

    function onTouchStart( event ) {

        if ( scope.enabled === false) return;

        switch ( event.touches.length ) {

            case 1:	// one-fingered touch: rotate

                if ( scope.enableRotate === false ) return;

                //var rect = scope.domElement.getBoundingClientRect();
                //var touchX=event.touches[ 0 ].pageX-(rect.left+rect.width-THREE_offset);
                //if(touchX<0||event.touches[ 0 ].pageY<rect.top||event.touches[ 0 ].pageY>(THREE_offset+rect.top))return;

                handleTouchStartRotate( event );
                state = STATE.TOUCH_ROTATE;

            break;

            default:

                state = STATE.NONE;

        }

        if ( state !== STATE.NONE ) {

            scope.domElement.addEventListener( 'touchend', onTouchEnd, false );
            scope.domElement.addEventListener( 'touchmove', onTouchMove, false );
            scope.dispatchEvent( startEvent );

        }

    }
    function onTouchMove( event ) {

        if ( scope.enabled === false ||THREE_DissectEnabled ===true) return;

        event.preventDefault();//阻止滑动

        switch ( event.touches.length ) {

            case 1: // one-fingered touch: rotate

                if ( scope.enableRotate === false ) return;
                if ( state !== STATE.TOUCH_ROTATE ) return; // is this needed?...
                if(rotateStart.x==event.touches[ 0 ].pageX&&rotateStart.y==event.touches[ 0 ].pageY)return;

                handleTouchMoveRotate( event );

            break;
            default:

                state = STATE.NONE;

        }

    }
    function onTouchEnd( event ) {

        if ( scope.enabled === false ) return;

        handleTouchEnd( event );

        scope.domElement.removeEventListener( 'touchmove', onTouchMove );
        scope.domElement.removeEventListener( 'touchend', onTouchEnd );

        scope.dispatchEvent( endEvent );

        state = STATE.NONE;

    }

    this.updateDomElement();
    this.update();

};

THREE.CubeControls.prototype = Object.create( THREE.EventDispatcher.prototype );
THREE.CubeControls.prototype.constructor = THREE.CubeControls;