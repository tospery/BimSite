﻿/**
 * Created by Administrator on 2016/10/24.
 */

/**
 * Created by Administrator on 2016/10/24.
 */

var editor;
//
function initView(){

    if(editor){

        if ( confirm( 'Already initialized!!!' ) ) {
        }
        return;
    }

    editor = new Editor('viewer');
    var value = editor.setView("",false);//'/name/'

    function onWindowResize( event ) {

        editor.signals.windowResize.dispatch();

    }
    window.addEventListener( 'resize', onWindowResize, false );
    onWindowResize();
}

function inputJson(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    var fileInput = document.getElementById( 'input' );
    fileInput.value="";
    fileInput.click();

}
function openLocalModel(fileInput){

    if(fileInput.value=="")return;

    editor.openLocalModel(fileInput.files[ 0 ]);
}
//
function openModel(url,path){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    var name =[
        "A1/A1.3gd.json",
        "B1/B1.3gd.json",
        "C1/C1.3gd.json",
        "D1/D1.3gd.json",
        "E1/E1.3gd.json",
        "F3/F3.3gd.json",
        "G1/G1.3gd.json",
        "LJ1/LJ1.3gd.json",
        "TFSD/TFSD.3gd.json",
        "w1/w1.3gd.json"
    ];
    var name0 =[
        "A1/A1/",
        "B1/B1/",
        "C1/C1/",
        "D1/D1/",
        "E1/E1/",
        "F3/F3/",
        "G1/G1/",
        "LJ1/LJ1/",
        "TFSD/TFSD/",
        "w1/w1/"
    ];
    editor.openModel(url,path);//("json/WebGlTest/","json/C匝道(C1)/" );
//    editor.openModel(url);//中建一局/楼房/墙/ceshi6
}
//
function openLocalSDModel(dataStr){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.openLocalSDModel(dataStr);//中建一局/楼房/墙/ceshi6
}
//
function addJson(url,path){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.addModel(url,path);//中建一局/楼房/墙/小房子
}

//获取结构树
function getTreeData_android(uuid){

    var jsonObjects = editor.getTreeData_android(uuid);
    androidShare.jsMethod(JSON.stringify(jsonObjects),0);
    for(var i=0;i<jsonObjects.length;i++){

        var id = jsonObjects[i].uuid;
        getTreeData(id,1);
    }
    androidShare.endTreeDatas();//结构树获取结束方法
}
function getTreeData(uuid,level){

    var jsonObjects = editor.getTreeData_android(uuid);
    androidShare.jsMethod(JSON.stringify(jsonObjects),level);

    for(var i=0;i<jsonObjects.length;i++){

        var id = jsonObjects[i].uuid;
        getTreeData(id,level+1);
    }
}
//===========================卸载===========start================
//
function unloadModel(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    alert(editor.unloadModel(editor.getObjectUuid()));//editor.getObjectUuid()
}
//
function clearView(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    return editor.clear();
    //alert(editor.clear());
}
//===========================卸载===========end==================

//===========================保存===========start==================
function saveFile(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.toJSON('scene.json');
}
function saveImage(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    alert(editor.toImage('img.gif'));
}
//===========================保存===========end====================

//===========================适应居中===========start================
//选中居中--指定uuid
function centerSelected(uuid){
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    //alert(uuid);
//    editor.selectByUuid(uuid);
    try{
        var code=editor.centerSelected(uuid);
        //alert(code);
    }catch(e){
       alert("centerSelected()报错");
    }
}
//选中居中
function selectedToCenter(){
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    var uuid=editor.getObjectUuid();
    uuid=uuid.replace(/\*undefined/g, "");
    centerSelected(uuid);
    //alert(editor.centerSelected(uuid));
}
//缩放至视窗
function zoomToView(){
    //alert("还没有实现");
    editor.zoomToView();
}
//===========================适应居中===========end==================

//=====================圈阅批注==========start====================================

function textLabel(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.textLabel();
}

var ImageLabel = false;
function imageLabel(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    ImageLabel = !ImageLabel;
    if(ImageLabel) {

        var fileInput = document.getElementById( 'input0' );
        fileInput.value="";
        fileInput.click();

    }else editor.imageLabel();
}
function openImage(fileInput){

    if(fileInput.value=="")return;

    editor.imageLabel(fileInput.files[ 0 ]);
}

function textLabeling(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.textLabeling();
}
function roundLabel(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.roundLabel();
}
function rectLabel(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.rectLabel();
}

function updateTextLabel(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.updateTextLabel({infor:"Welcome to 中国！",tColor:'rgb(0,255,70)',bColor:'rgb(0, 0, 255)',size:'24px',font:'黑体'});
}
function displayRemarks(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.displayRemarks(true);
}
function displayRemarks0(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.displayRemarks(false);
}
function setRemarks(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.setRemarks('！');
}

function getLabelInfor(){

    var str = editor.getLabelInfor();
    console.log(str);
}

function getLabelInfors(){

    var infor =editor.getLabelInfors();
    // console.log(infor);
}
function getInforToCreateLabel(){

    editor.getInforToCreateLabel(editor.getLabelInfors());
}
//=====================圈阅批注==========end======================================

//=====================测量==========start====================================
//两点距离
//var tpdEnable = true;
function twoPointsDistance(value){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.twoPointsDistance(value);
//    tpdEnable = !tpdEnable;
}

// //两面距离
// var tsdEnable = true;
// function twoSideDistance(){
//
//     panel.classList.toggle( 'collapsed' );
//     if(editor==null || editor===undefined){
//
//         if ( confirm( 'Please initialize!!!' ) ) {
//         }
//         return;
//     }
//
//     editor.reset();
//     editor.twoSideDistance(tsdEnable);
//     tsdEnable = !tsdEnable;
// }

//点线距离
var pldEnable = true;
function pointToLineDistance(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.pointToLineDistance(pldEnable);
    pldEnable = !pldEnable;
}

//点面距离
var ppdEnable = true;
function pointToPlaneDistance(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.pointToPlaneDistance(ppdEnable);
    ppdEnable = !ppdEnable;
}

//坐标测量
var cmEnable = true;
function coordinateMeasurement(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.coordinateMeasurement(cmEnable);
    cmEnable = !cmEnable;
}

//直线夹角
var saEnable = true;
function straightAngleMeasurement(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.straightAngleMeasurement(saEnable);
    saEnable = !saEnable;
}

//三点角度
var tpaEnable = true;
function threePointsAngleMeasure(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.threePointsAngleMeasure(tpaEnable);
    tpaEnable = !tpaEnable;
}
//=====================测量===========end======================================

//===========================视图===========start=====================
//3/4视图
function mainView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.mainView();
}
//前视图
function frontView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.frontView();
}
//后视图
function backView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.backView();
}
//左视图
function leftView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.leftView();
}
//右视图
function rightView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.rightView();
}
//顶视图
function topView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.topView();
}
//底视图
function bottomView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.bottomView();
}
//===========================视图===========end========================

//===========================剖视=============start=====================
//XY剖视
//var disXY = true;
function dissectXY(value){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.dissectXY(value);
//    disXY = !disXY;
}
//YZ剖视
var disYZ = true;
function dissectYZ(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.dissectYZ(disYZ);
    disYZ = !disYZ;
}
//XZ剖视
var disXZ = true;
function dissectXZ(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.dissectXZ(disXZ);
    disXZ = !disXZ;
}
//法线剖视
var disNor = true;
function dissectNormal(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.dissectNormal(disNor);
    disNor = !disNor;
}
//自由剖视
var dis = true;
function dissect(){

    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.reset();
    editor.dissect(dis);
    dis = !dis;
}
//===========================剖视=============end========================

//===========================视图===========start=====================
//保存视图
function saveView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    editor.saveView();
}
//打开视图
function openView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    alert(editor.openView(0));
}
//删除视图
function deleteView(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    alert(editor.deleteView(2));
}
//获取视图数组
function getViewPointArray(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    var viewPoint = editor.getViewPointArray();
    console.log(viewPoint);
}
//===========================视图===========end========================

//=====================渲染模式=============start======================
//颜色渲染
function colorRender(){
    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.colorRender();
}
//线框渲染
function lineRender(){
    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.lineRender();
}
//=====================渲染模式=========end============================
//设置抗锯齿
function enabledAntialias(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    alert(editor.setAntialias(true));
}
function disabledAntialias(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    alert(editor.setAntialias(false));
}
//设置背面剔除
function enabledFaceCulling(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.setFaceCulling(true);
}
function disabledFaceCulling(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.setFaceCulling(false);
}

//=====================3D查看操作=========start============================
function endableFlightMode(){
    //alert("还没有实现");
    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.flightMode(true);
}
function disableFlightMode(){
    //alert("还没有实现");
    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.flightMode(false);
}
//=====================3D查看操作=========end==============================

//=====================选择模式=========start==============================
//选择组件
function selectAssembly(){
    //alert("还没有实现");
    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.selectMode(0);
}
//选择构件
function selectComponent(){
    //alert("还没有实现");
    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.selectMode(1);
}
//选择零件
function selectParts(){
    //alert("还没有实现");
    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.selectMode(2);
}
//=====================选择模式=========end================================

//=====================隐藏=========start==============================
//
//隐藏指定对象
function hideObject(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }

    alert(editor.hideObject(editor.getObjectUuid()));
}
//隐藏非指定对象
function viewSeparately(){
    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.viewSeparately(editor.getObjectUuid());
}
//恢复隐藏
function resumeHiding(){

    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.resumeHiding();
}
//=====================隐藏=========end================================

//=====================半隐=========start==============================
//半隐指定对象
function halfHideObject(){
    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.halfHideObject(editor.getObjectUuid());
}
//半隐非指定对象
function halfViewSeparately(){
    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.halfViewSeparately(editor.getObjectUuid());
}
//恢复半隐对象
function resumeHalfHiding(){
    //alert("还没有实现");
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.resumeHalfHiding();
}
//=====================半隐=========end================================

//=====================属性=========start==============================
//颜色设置
function setColor(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.setColor(editor.getObjectUuid(),'rgb(255,255,60)');//rgb(255,255,60)
}
//颜色恢复
function recoveryColor(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.recoveryColor();//editor.getObjectUuid()
    // editor.recoveryColor();
}
//透明度设置
function setOpacity(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    editor.setOpacity(editor.getObjectUuid(),0.5);
}
//选中高亮
function setSelected(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    alert(editor.setSelected(editor.getObjectUuid()));//editor.getObjectUuid());b11a3d49-3140-4761-a9c1-2c9050e7775f
}
//=====================属性=========end================================

//=====================个性化=========start=================================
//Logo设置
function setLogo(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    var x=10;
    var y=10;
    var width=100;
    var height=100;
    var url='picture/yj.png';//'3DAirAPIs/css/root.gif';//picture/yj.png
    editor.setLogo(x,y, width, height, url);
}
//背景色设置
function setBackground(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    var startColor='rgb(0, 255, 70)';
    var endColor='rgb(192, 255, 87)';
    editor.setBackground(startColor,endColor);
}
//高亮颜色设置
function setHighlight(){

    panel.classList.toggle( 'collapsed' );
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    var color='rgb(0, 255, 70)';
    var opacity=0.5;
    editor.setHighlight(color,opacity);
}
//=====================个性化=========end====================================


function Base64() {
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
            _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }
 
    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }
 
    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
 
        }
        return utftext;
    }
 
    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while ( i < utftext.length ) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i+1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i+1);
                c3 = utftext.charCodeAt(i+2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}

function isiOSClient(){
    var u = navigator.userAgent;
    var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    return isiOS;
}

function downloadFile(downLoadUrl, fileName) {
	if (isiOSClient())
		location.href = "rrcc://downloadFileWidthUrl_andFileName_?"
				+ downLoadUrl + "&" + fileName
	else
		BimSiteInterface.downloadFile(downLoadUrl, fileName);
}

function initModelFile(downLoadUrl,fileName){
	//alert("downLoadUrl:"+downLoadUrl+"|fileName:"+fileName);
	downloadFile(downLoadUrl,fileName);
	//"XXX-SD-D1-000000-3D-0518C.json"
}

//===========================工程量===========start================
function getAmount(){
	var type=2;
	var pbs=editor.getObjectUuid();
	//pbs="e63c11a3-eefc-4604-83fa-f7ea46d35b87";
	//alert(editor.getObjectUuid());
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
    if(editor.getObjectUuid().length==0){
    	$("#my-popover").css("display","block");
    	 setTimeout(function () {  
    	        $("#my-popover").css("display","none");  
    	    }, 1500)
 
    }else{
    	$.post(Addr+"/SimuBimSiteApp/BIMSiteService.asmx/AppGetAmount",
    			  {
					token:token,
    			    type:type,
    			    pbs:pbs,
					name:"",
					page:"",
					pageSize:""
    			  },
    			  function(data,status){
					isPost=false;
					var string=data.getElementsByTagName('string');
          			var json=JSON.parse(string[0].innerHTML);
          			if(json.Status=="F"){
          			  	yincang();
	          			$.AMUI.progress.done();
	          			alert(json.StatusDesc);
	          			return;
	          		}else{
						var res=json.Result;
						var length=res.length;
						var html="";
						for(var i=0;i<length;i++){
							html+="工程量编码:"+res[i].Id+"<br>";
							html+="名称:"+res[i].Name+"<br>";
							html+="单位:"+res[i].Unit+"<br>";
							html+="数量:"+res[i].Quantity+"<br><br>";
						}
						$("#amount").html(html);
					}
    			  });
    	$("#doc-oc-demo2").offCanvas('open');
    }
  
}
//===========================属性===========start================
function getModelProperty(){
	//alert(1);
	//var fileId=document.getElementById("fileId1").value;
	var fileId=tempFileId;
   	//alert(tempFileId);
	//var guid="e63c11a3-eefc-4604-83fa-f7ea46d35b87"; 
	//var fileId="02572E032FF84379A0162B639871F06D";
	
	
	var guid=editor.getObjectUuid().replace(/\*undefined/g, "");
	//alert(guid);
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
	 if(editor.getObjectUuid().length==0){
		 $("#my-popover").css("display","block");
    	 setTimeout(function () {  
    	        $("#my-popover").css("display","none");  
    	    }, 1500)
 
	    }else{
	    	$.post(Addr+"/SimuBimSiteApp/BIMSiteService.asmx/GetModelProperty",
	    			  {
						token:token,
	    			    guid:guid,
	    			    fileId:fileId
	    			  },
	    			  function(data,status){
	    			     isPost=false;
						var string=data.getElementsByTagName('string');
          			  	var json=JSON.parse(string[0].innerHTML);
          			  	if(json.Status=="F"){
          			  		yincang();
	          			  	$.AMUI.progress.done();
	          			  	alert(json.StatusDesc);
	          			  	return;
	          			  }else{
							  var res=json.Result[0];
							  var html="";
							  for(var i=0;i<json.Result.length;i++){
							    html+=json.Result[i].name+":"+json.Result[i].value+"<br>"
							  }
							  $("#property").html(html);
						  }
	    			  });
	    	$("#doc-oc-demo3").offCanvas('open');
	    }
}

//===========================人员定位===========start================
function getPersonPosition(){
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    }
	 $.post(Addr+"/SimuBimSiteApp/BIMSiteService.asmx/AppGetPersonPosition",
		{
			token:token,
			page:0,
			pageSize:1000
		},
	    			  function(data,status){
	    			    isPost=false;
						var string=data.getElementsByTagName('string');
          			  	var json=JSON.parse(string[0].innerHTML);
          			  	if(json.Status=="F"){
          			  		yincang();
	          			  	$.AMUI.progress.done();
	          			  	alert(json.StatusDesc);
	          			  	return;
	          			  }else{
							  var res=json.Result[0];
							  var html="姓名:"+res.Name+"<br>隧道名称:"+res.TunnelName+"<br>入隧时间:"+res.InTime+"<br>Distance:"+res.Distance+"<br>X坐标:"+res.X+"<br>Y坐标:"+res.Y;
							
							  $("#position").html(html);
						  }
	    			  });
	    	$("#doc-oc-demo5").offCanvas('open');
	    
}
//===========================图纸===========start================
function getPictures(){
	// alert(editor.getObjectUuid());
	var type=2;
	var pbs=editor.getObjectUuid();
	//pbs="e63c11a3-eefc-4604-83fa-f7ea46d35b87"; 
    if(editor==null || editor===undefined){
        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    } 
    if(editor.getObjectUuid().length==0){
    	$("#my-popover").css("display","block");
   	 setTimeout(function () {  
   	        $("#my-popover").css("display","none");  
   	    }, 1500)

    }else{
    	$.post(Addr+"/SimuBimSiteApp/BIMSiteService.asmx/AppGetPictures",
  			  {
				token:token,
    		    type:type,
			    pbs:pbs,
				name:"",
				page:"",
				pageSize:""
  			  },
  			  function(data,status){
				  
				isPost=false;
				var string=data.getElementsByTagName('string');
          		var json=JSON.parse(string[0].innerHTML);
          		if(json.Status=="F"){
          			yincang();
	          		$.AMUI.progress.done();
	          		alert(json.StatusDesc);
	          		return;
	          	}else{
					var res=json.Result;
					var length=res.length;
					var html="";
					for(var i=0;i<length;i++){
						html+="<a onclick=online('"+res[i].Id+"','"+res[i].Name+"')>"
						
						html+="图纸编号:"+res[i].Id+"<br>";
						html+="PBS编码:"+res[i].Pbs+"<br>";
						html+="图纸名称:"+res[i].Name+"<br>";
						html+="上传时间:"+res[i].CreatedOn+"<br>";
						html+="上传人员:"+res[i].CreatedBy+"<br>";
						html+="</a><br>";
					}
					
					alert(length);
					$("#pictures").html(html);
				}
				
  			  });
    	$("#doc-oc-demo4").offCanvas('open');
    }
}
//===========================质量隐患===========start================
function getQuality(){
 	//editor.setSelected("e63c11a3-eefc-4604-83fa-f7ea46d35b87*2df425fd-2552-41df-8717-2e3fafb02a78*");
	  //  alert(editor.setSelected(editor.getObjectUuid()));
	  
	editor.resumeHalfHiding ();
	editor.recoveryColor(); 
	var pbs="";
    if(editor==null || editor===undefined){

        if ( confirm( 'Please initialize!!!' ) ) {
        }
        return;
    } 
	$.post(Addr+"/SimuBimSiteApp/BIMSiteService.asmx/AppGetGuids",
			{
				token:token,
				type:"1"
			},
			function(data,status){
				var string=data.getElementsByTagName('string');
		        var json=JSON.parse(string[0].innerHTML);
		        if(json.Status=="F"){
			        //alert(json.StatusDesc);
			        return;
			     }else{
					var res=json.Result;
			     	if (res!=null) {
			     		res=res.replace(/#/g,"*");
					}
					//alert(res);
					editor.setSelected(res);
				}
			});
	// alert(editor.setSelected(editor.getObjectUuid()));
	editor.setRemarks("质量");
					  
	editor.halfViewSeparately("e63c11a3-eefc-4604-83fa-f7ea46d35b87*2df425fd-2552-41df-8717-2e3fafb02a78*") ;
	editor.setColor("e63c11a3-eefc-4604-83fa-f7ea46d35b87*2df425fd-2552-41df-8717-2e3fafb02a78*", "rgb(255,0,0)");

}

//===========================安全问题===========start================
function getSafety(){
		editor.resumeHalfHiding();
		editor.recoveryColor(); 
		if(editor==null || editor===undefined){

			if ( confirm( 'Please initialize!!!' ) ) {
			}
			return;
		}
		$.post(Addr+"/SimuBimSiteApp/BIMSiteService.asmx/AppGetGuids",
			{
				token:token,
				type:"2"
			},
			function(data,status){
				var string=data.getElementsByTagName('string');
		        var json=JSON.parse(string[0].innerHTML);
		        if(json.Status=="F"){
			        //alert(json.StatusDesc);
			        return;
			     }else{
					var res=json.Result;
			     	if (res!=null) {
			     		res=res.replace(/#/g,"*");
					}
					//alert(res);
					editor.setSelected(res);
				}
			});
    	editor.halfViewSeparately("e63c11a3-eefc-4604-83fa-f7ea46d35b87*2df425fd-2552-41df-8717-2e3fafb02a78*") ;
    	editor.setColor("e63c11a3-eefc-4604-83fa-f7ea46d35b87*2df425fd-2552-41df-8717-2e3fafb02a78*", "rgb(255,0,0)");
    	//updateTextLabel();
}
