/**
 * @author mrdoob / http://mrdoob.com/
 */

var Viewport = function ( editor ) {

	var signals = editor.signals;

	//容器
	var container = new UI.Panel();
	container.setId( 'viewport' );
	container.setPosition( 'absolute' );
	//container.add( new Viewport.Info( editor ) );

	//框选对象
	var div=undefined;
	var logo=undefined;

	var backGroupStart='rgb(134,179,255)';
	var backGroupEnd='rgb(255,255,255)';

	var scene = editor.scene;
	var sceneHelpers = editor.sceneHelpers;

	//scene的包围盒
	var sceneBox=new THREE.Box3();
	//scene中的所有物体数组
	var objects = [];
    // var wireframeObjects = [];
	var objectColors=[];
	var hideObjects=[];
	var halfHideObjects=[];
	var leftMove=false;

	//添加灯光
	var lightGroup=new THREE.Group();
	lightGroup.add(new THREE.AmbientLight( 0xFFFFFF,0.5));
    //
    var directionalLight=new THREE.DirectionalLight(0xFFFFFF,0.4);
    directionalLight.position.set( 1, 0, 0);
    lightGroup.add(directionalLight);

	scene.add(lightGroup);
	//
	sceneHelpers.add( pointCenter );

	sceneHelpers.add(editor.labelGroup);
	sceneHelpers.add(editor.lineGroup);

    sceneHelpers.add(editor.measureGroup);
	//

	var camera = editor.camera;
	//整个场景中心点
	var objectCenter = new THREE.Vector3(0,0,0);

	//选中物体对象
	var selectionObject=[];
	var highlightColor='rgb(255,0,0)';
	var highlightOpacity=1.0;

	//抗锯齿标志位
	var _antialias = true;
	//背面剔除标志位
	var _faceCulling = true;

	function getSelectionObjects(object,objects){

		if(object.children.length==0 && objects.indexOf(object)<0){
			objects.push(object);
			return;
		}

		for(var i=0;i<object.children.length;i++){

			if(object.children[i].children.length>0)getSelectionObjects(object.children[i],objects);
			else if(objects.indexOf(object.children[i])<0)objects.push(object.children[i]);
		}

	}

	function getRenderer(){

		var renderer = new THREE.WebGLRenderer( { antialias: _antialias, alpha:true} );
		renderer.autoClear = false;
		renderer.autoUpdateScene = false;

		renderer.setClearColor( 0xaaaaaa ,0.1);
		renderer.setPixelRatio( window.devicePixelRatio );

		renderer.clippingPlanes = dissectPlanes;
		renderer.localClippingEnabled=true;

		return renderer;
	}

	// object picking
	var onDownPosition = new THREE.Vector2();
	var onUpPosition = new THREE.Vector2();
	var onDoubleClickPosition = new THREE.Vector2();

	var onDownPositionD = new THREE.Vector2();
	var onUpPositionD = new THREE.Vector2();

	var move=new THREE.Vector2();

	var imgData;

	function handleClick() {

		if(div!==undefined){

			container.remove(div);
			div=undefined;

			if(leftMove && Math.abs(onUpPositionD.distanceTo(onDownPositionD))>40.0){

				selectionObject=[];

				var halfWidth = container.dom.offsetWidth / 2;
				var halfHeight = container.dom.offsetHeight / 2;

				for(var i=0;i<objects.length;i++){

					if(objects[i].geometry == undefined || !objects[i].visible) continue;

					var world_vector=objects[i].localToWorld(objects[i].geometry.boundingBox.min.clone());

					var vector =world_vector.project(camera);
					var resultMin = {
						x: Math.round(vector.x * halfWidth + halfWidth),
						y: Math.round(-vector.y * halfHeight + halfHeight)
					};

					world_vector=objects[i].localToWorld(objects[i].geometry.boundingBox.max.clone());
					vector =world_vector.project(camera);
					var resultMax = {
						x: Math.round(vector.x * halfWidth + halfWidth),
						y: Math.round(-vector.y * halfHeight + halfHeight)
					};

					var min=new THREE.Vector2();
					min.x=(resultMin.x>resultMax.x)?resultMax.x:resultMin.x;
					min.y=(resultMin.y>resultMax.y)?resultMax.y:resultMin.y;
					var max=new THREE.Vector2();
					max.x=(resultMin.x<resultMax.x)?resultMax.x:resultMin.x;
					max.y=(resultMin.y<resultMax.y)?resultMax.y:resultMin.y;

					if(onDownPositionD.x<max.x&&min.x<onUpPositionD.x
						&&onDownPositionD.y<max.y&&min.y<onUpPositionD.y){

						if(editor.seModeType=="Assembly"){
							object=objects[i];
							while(object && object.parent!=null && object.parent.name!=='Scene')object=object.parent;
							editor.select( object );
							break;
						}

						signals.changeColor.dispatch(objects[i],true);
						selectionObject.push(objects[i]);

					}else{

						signals.changeColor.dispatch(objects[i],false);
					}
				}
                onUpPositionD.set(0,0);onDownPositionD.set(0,0);
				render();
				return;
			}

		}

		//点击事件
		if ( onDownPosition.distanceTo( onUpPosition ) === 0) {

			//判断圆形或者矩形标注拾取
			//if (!getSelLebel()) {

				var intersects = THREE_getIntersects(onUpPosition, camera, objects);
				if (intersects.length > 0) {

					var object = intersects[0].object;
					switch (editor.seModeType) {
						case "Assembly"://组件--找到最大根

							while (object && object.parent != null && object.parent.name !== 'Scene')object = object.parent;
							break;
						case "Component"://构件--找到最近根

							if (object && object.parent != null && object.parent.type !== 'Scene')object = object.parent;
							break;
						default:
							break;
					}

					editor.select(object);

				} else {

					editor.select(null);
				}
			//}
		}
	}

	function onMouseDown( event ) {

		//飞行模式下
		if(THREE_KEY || flightMode.enabled || divEnabled || THREE_DissectEnabled) return;

		event.preventDefault();

		//左键操作
		if( event.button === 0 || (event.button==undefined &&  event.touches.length==1) ){

			deSelectedLabel();//取消标签选中

			var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;

			var array = THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY );
			onDownPosition.fromArray( array );

			if (!pickedLabel(onDownPosition,event)){

				move.set(event.clientX, event.clientY);

				div = new UI.Div();
				div.setId( 'tempDiv' );
				container.add(div);

				document.addEventListener( 'mouseup', onMouseUp, false );
				document.addEventListener( "touchend", onMouseUp,false );

                // container.dom.addEventListener( 'mouseout', onMouseUp, false );

				container.dom.addEventListener( 'mousemove', onMouseMove, false );

			}
		}

	}
	function onMouseMove(event){

		if(div!==undefined){

			if(divEnabled || THREE_DissectEnabled){

				container.remove(div);
				div=undefined;
				return;
			}

			var rect = container.dom.getBoundingClientRect();
			onDownPositionD.x= Math.min(event.clientX, move.x)-rect.left;
			onDownPositionD.y= Math.min(event.clientY, move.y)- rect.top;
			var w=Math.abs(move.x - event.clientX);
			var h=Math.abs(move.y - event.clientY);

			div.setLeft( onDownPositionD.x+ "px");div.setTop( onDownPositionD.y + "px");
			div.setWidth(w+"px");div.setHeight(h+"px");

			onUpPositionD.set(onDownPositionD.x+w,onDownPositionD.y+h);

			leftMove=true;
		}

	}
	function onMouseUp( event ) {

		var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
		var array = THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY );
		onUpPosition.fromArray( array );

		handleClick();

		leftMove=false;
		divEnabled=false;

		container.dom.removeEventListener( 'mousemove', onMouseMove, false );
		document.removeEventListener( 'mouseup', onMouseUp, false );

        // container.dom.removeEventListener( 'mouseout', onMouseUp, false );

		document.removeEventListener( "touchend", onMouseUp,false );

	}

	function keyDown(event){

        event = (event) ? event : window.event;
        if(event.ctrlKey){

            THREE_KEY = true;
            document.addEventListener( 'keyup', keyup, false );
		}
	}
    function keyup(event){

        THREE_KEY = false;
        document.removeEventListener( 'keyup', keyup );
    }

    var startTime = 0;
    var endTime = 0;
    var clickCount = 0;
    function onContextMenu( event ) {

        if(clickCount == 0){

            startTime=new Date();
            clickCount++;
        }else if(clickCount == 1 ){

            endTime=new Date();

            if (Math.abs(endTime-startTime)<400){

                //双击 function
                clickCount=0;

                var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
                onDoubleClickPosition.fromArray( array );
                var intersects = THREE_getIntersects( onDoubleClickPosition, camera, objects );

                if(intersects.length > 0){

                    if(event.button==2){//设置旋转中心
                        pointCenter.position.set(intersects[0].point.x,intersects[0].point.y,intersects[0].point.z);
                        controls.rotateCenter.set(pointCenter.position.x,pointCenter.position.y,pointCenter.position.z);
                    }

                }

            }else{

                startTime=new Date();
            }

        }

        event.preventDefault();
    }

    container.dom.addEventListener( 'contextmenu', onContextMenu, false );
    document.addEventListener( 'keydown', keyDown, false );

	container.dom.addEventListener( 'mousedown', onMouseDown, false );
	container.dom.addEventListener( 'touchstart', onMouseDown, false );

	//监听/注销鼠标事件
	signals.setViewEvent.add( function (value) {

		if(value){

			container.dom.addEventListener( 'mousedown', onMouseDown, false );
			container.dom.addEventListener( 'touchstart', onMouseDown, false );
		}
		else{

			container.dom.removeEventListener( "mousedown", onMouseDown );
			container.dom.removeEventListener( "touchstart", onMouseDown );
		}
	} );

	 //controls need to be added *after* main logic,otherwise controls.enabled doesn't work.
	//场景控制器
	var controls = new THREE.EditorControls( camera,  container.dom );
	controls.enableRotate=false;
	controls.addEventListener( 'change', function () {

		signals.cameraChanged.dispatch( camera );

	} );

	//==========================标注===============start========================
	var label = new THREE.TextLabel(editor,container, controls);

	var tempLabel = new THREE.RoundOrRectLabel(editor,container,controls, label);

	function clearLabel(){
		label.clearLabel();
        tempLabel.clearLabel();
        measure.clearMeasure();
	}
	// function deleteLabel(){tempLabel.clearLabel();}

	function updateLabels(){
		//更新批注标签位置
		label.updatePositions(camera,container.dom.offsetWidth / 2, container.dom.offsetHeight / 2);
		//更新测量标签位置
        measure.updatePositions(camera,container.dom.offsetWidth / 2, container.dom.offsetHeight / 2);
	}
	function deSelectedLabel(){

		label.selectedLabel();//取消批注选中
        measure.restColor();//取消测量选中
	}

	function pickedLabel(point,event){return tempLabel.pickLabel(point,event);}
	function getSelLebel(){ return tempLabel.getSelected();}
	function updateCenterLabel(){ tempLabel.updateCenterLabel(camera);}

	signals.setLabel.add( function (value,value0) {
		//value表示是否创建标签；value0表示是2D标签还是3D标注
		if(value){

			container.dom.removeEventListener( "mousedown", onMouseDown );
			container.dom.removeEventListener( "touchstart", onMouseDown );
			if(value0){label.addEvents();tempLabel.removeEvents();}//2D标签/标注
			else {tempLabel.addEvents();label.removeEvents();}//3D标注
		}
		else {

			container.dom.addEventListener( 'mousedown', onMouseDown, false );
			container.dom.addEventListener( 'touchstart', onMouseDown, false );
			label.removeEvents();
			tempLabel.removeEvents();
		}
	} );
	signals.saveLabel.add( function (output) {
		output.push( label.toJSON());
	} );
	signals.readLabel.add( function (data) {
		label.fromJSON(data);
	} );
	signals.updateTextLabel.add( function(parameters){
		label.updateLabel(parameters);
	});
	signals.getLabelInfor.add( function(){

		editor.selectedLabel = label.getSelected();
	});

    signals.getLabelInfors.add( function(infor){

        label.getLabelInfor(infor);
    });
    signals.getInforToCreateLabel.add( function(infor){

        label.getInforToCreateLabel(infor);
    });
    signals.getLabelObject.add( function(){

        editor.selectedLabel = tempLabel.getSelected();
    });

	signals.displayRemarks.add( function(value){

		var selectionLabel = getSelLebel();
		if(selectionLabel!==undefined) {

			label.setDisplay(value,selectionLabel.tagg);
		}

	});
	signals.setRemarks.add( function(value){

		var selectionLabel = getSelLebel();
		if(selectionLabel!==undefined){

			label.setLabelText(selectionLabel.tagg,value);
		}

	});
	//==========================标注===============end===========================

    //==========================测量===============start========================
    var measure = new THREE.Measure(editor,container, controls);

    signals.setMeasure.add( function (value,value1) {
        //value表示是否进行测量，value1测量类型
        if(value){

            container.dom.removeEventListener( "mousedown", onMouseDown );
            container.dom.removeEventListener( "touchstart", onMouseDown );
            measure.addEvents(value1);
        }else {

            container.dom.addEventListener( 'mousedown', onMouseDown, false );
            container.dom.addEventListener( 'touchstart', onMouseDown, false );
            measure.removeEvents();
        }
    } );
    signals.saveMeasureLabel.add( function (output) {
        output.push( measure.toJSON());
    } );
    signals.readMeasureLabel.add( function (data) {
        measure.fromJSON(data);
    } );
    signals.restColor.add( function (value) {

		(value)?measure.selectColor():measure.restColor();
    } );
    //==========================测量===============end===========================
    //
	//==============================剖视================start=====================================
	//创建剖视具体对象
	function createDissect(dissect){

		signals.setSceneBox.dispatch();
		dissect.createDissect(sceneBox);
	}
	//启动剖视
	function enableDissect(dissect,objects){

		signals.setSceneBox.dispatch();
		dissect.addEvents(objects,sceneBox);
	}
	//删除剖视具体对象
	function deleteDissect(dissect){

		dissect.removeDissect();
	}
	//清空所有剖视对象
	function clearDissects(){

		XYdissect.removeDissect();
		XZdissect.removeDissect();
		YZdissect.removeDissect();
		normalDissect.removeDissect();
		XYZdissect.removeDissect();
	}
	//剖视平面数组
	var dissectPlanes = [];
	//剖视对象
	var XYdissect = new THREE.DissectObject(editor,container,dissectPlanes,0xFF0000,'XY',controls);
	var XZdissect = new THREE.DissectObject(editor,container,dissectPlanes,0x0000FF,'XZ',controls);
	var YZdissect = new THREE.DissectObject(editor,container,dissectPlanes,0x008000,'YZ',controls);
	var normalDissect =new THREE.DissectObject(editor,container,dissectPlanes,0x808080,'normal',controls);
	var XYZdissect =new THREE.DissectObject(editor,container,dissectPlanes,0xFFFF00,'XYZ',controls);
	//供editor调用--即外部调用
	signals.setDissect.add( function ( value, value0) {

		switch(value){
			case 'XY剖视':

				var enable=XYdissect.getEnable();
				signals.setFlightInfor.dispatch((value0)?"XY剖视":"正常操作");
				if(!enable && value0) createDissect(XYdissect);
				else if(!value0 &&enable)deleteDissect(XYdissect);
				break;

			case 'YZ剖视':

				var enable=YZdissect.getEnable();
				signals.setFlightInfor.dispatch((value0)?"YZ剖视":"正常操作");
				if(!enable) createDissect(YZdissect);
				else if(!value0 &&enable)deleteDissect(YZdissect);
				break;

			case 'XZ剖视':

				var enable=XZdissect.getEnable();
				signals.setFlightInfor.dispatch((value0)?"XZ剖视":"正常操作");
				if(!enable) createDissect(XZdissect);
				else if(!value0 &&enable)deleteDissect(XZdissect);
				break;

			case '法线剖视':

				var enable=normalDissect.getEnable();
				signals.setFlightInfor.dispatch((value0)?"法线剖视":"正常操作");
				if(!enable) enableDissect(normalDissect,objects);
				else if(!value0 &&enable)deleteDissect(normalDissect);
				break;

			case '自由剖视':

				var enable=XYZdissect.getEnable();
				signals.setFlightInfor.dispatch((value0)?"自由剖视":"正常操作");
				if(!enable) enableDissect(XYZdissect);
				else if(!value0 &&enable)deleteDissect(XYZdissect);
				break;
		}

		render();
	} );
	//==============================剖视================end========================================
    //
	//==============================飞行模式================start=====================================
	//飞行模式
	var pcamera=new THREE.PerspectiveCamera(45, 1, 0.1, 10000);
	var flightMode = new THREE.FlyControls( pcamera , container.dom );
	flightMode.addEventListener( 'change', function () { signals.updateRender.dispatch(); } );

	//==============================飞行模式================end========================================
    //
    //==============================视点================start========================================
    //视点对象
    var viewPoint = new THREE.ViewPoint();

    function clearViewPoint(){

    	//清空视点
    	viewPoint.clearPoints();
    }

    signals.saveView.add( function () {

		viewPoint.addPoint(camera.position,camera.up,controls.center,cubeCamera.getCamPos());
    } );
    signals.openView.add( function (value) {

    	var tcamera = viewPoint.openPoint(value);
    	if(tcamera == undefined) return;

    	camera.position.set(tcamera.position.x,tcamera.position.y,tcamera.position.z);
    	camera.up.set(tcamera.up.x,tcamera.up.y,tcamera.up.z);
    	camera.lookAt(new THREE.Vector3(tcamera.eye.x,tcamera.eye.y,tcamera.eye.z));
    	cubeCamera.setCamera(tcamera.pos,tcamera.up);

    	signals.updateRender.dispatch();
        THREE_RETURN = 0;
    } );
    signals.deleteView.add( function (value) {

    	return viewPoint.deletePoint(value);
    } );
    signals.getViewPointArray.add( function () {

        THREE_ViewPoint = viewPoint.getPoints();
    } );
    signals.saveViewPoint.add( function (output) {
    	output.push( viewPoint.toJSON());
    } );
    signals.readViewPoint.add( function (data) {
    	viewPoint.fromJSON(data);
    } );
    //==============================视点================end==========================================

	// signals
	//
    signals.restViewControl.add( function () {

        signals.setViewEvent.dispatch(true);//恢复主鼠标监听事件

        measure.removeEvents();//禁止测量操作
        // signals.setMeasure.dispatch(false);

        label.removeEvents();//禁止圈阅批注操作
        tempLabel.removeEvents();//禁止圈阅批注操作
        // signals.setLabel.dispatch(false);//禁止圈阅批注操作

		(normalDissect.getBoxEmpty())?normalDissect.restDissect():undefined;
		(XYZdissect.getBoxEmpty())?XYZdissect.restDissect():undefined;

        signals.flightMode.dispatch(false);//禁止飞行模式

    } );

	signals.editorCleared.add( function () {

		controls.center.set( 0, 0, 0 );
		cubeCamera.clear();
		scene.userData.wireframe=false;

		flightMode.enabledControls(false);
		//控制器
		controls.enabled = true;
		cubeCamera.setControls(controls.enabled);
		//摄像机
		camera=editor.camera;
		//
		div=undefined;
		//scene中的所有物体数组
		objects = [];
        // editor.wireframeObjects = [];
        objectColors = [];
		hideObjects=[];
		leftMove=false;
		halfHideObjects=[];

		//选中物体对象
		selectionObject=[];
		//highlightColor='rgb(255,0,0)';
		//highlightOpacity=1.0;

		//清空标签
		clearLabel();//清除2D批注
		// deleteLabel();//清除3D批注
		//清空视点
		clearViewPoint();
		//清空剖视
		clearDissects();

        editor.signals.setViewEvent.dispatch(true);

        editor.sceneHelpers.add(editor.measureGroup);//重新添加测量组对象

    } );
	signals.updateRender.add( function () {

		render();
	} );

	signals.getUuid.add( function () {

		editor.uuids='';
		for(var i in selectionObject){

			if(editor.uuids!=='')editor.uuids +='*';
			editor.uuids +=selectionObject[i].uuid;
		}

	} );

	signals.selectedCenter.add( function (object) {

		controls.focus( object , true );

	} );
	signals.zoomToView.add( function () {

		signals.setSceneBox.dispatch();
		var center=sceneBox.center();
		objectCenter=center;

		var radius=(sceneBox.max.sub(sceneBox.min)).length();
		var distance=(radius/2.0)/(Math.tan(camera.fov/2.0*0.017453));

		controls.rotateCenter.set(center.x,center.y,center.z);
		controls.toCenter(distance,center);

		pointCenter.position.set(center.x,center.y,center.z);

	} );
	signals.setSceneBox.add( function () {

		var object=(editor.sceneGroup.visible)?scene:sceneHelpers;
		sceneBox.setFromObject(object);
	} );

	//设置视图
	signals.setView.add( function (id) {

		cubeCamera.setView(id);
	} );

	signals.RenderType.add( function (type) {

		switch(type){
			case 'COLOR':
				scene.userData.wireframe=false;
			break;

			case 'LINE':
				scene.userData.wireframe=true;
			break;

			default:
				alert( 'No such render mode.' );
			break;
		}

		render();

	} );

	signals.flightMode.add( function (value){

		flightMode.enabledControls(value);
		if(flightMode.enabled)pcamera.copy( camera );

		signals.setFlightInfor.dispatch((value)?"飞行模式":"正常操作");
		//控制器
		controls.enabled = !flightMode.enabled;
		cubeCamera.setControls(controls.enabled);
		//摄像机
		camera=(flightMode.enabled)?pcamera:editor.camera;

		render();
	});

	signals.hideObject.add( function (object) {

		if(object.visible){

			object.visible=false;
			hideObjects.push(object);
			signals.changeColor.dispatch(object,false);
		}

	} );
	signals.viewSeparately.add( function (object) {

		hideObjects=[];
		var tObjects=[];
		for(var i in object){

			getSelectionObjects(object[i],tObjects);
		}

		for(var i=0;i<objects.length;i++){

			if(objects[i].children.length>0 || tObjects.indexOf(objects[i])>=0 ){objects[i].visible=true;continue;}//(!objects[i].visible)

			objects[i].visible=false;
			hideObjects.push(objects[i]);
		}
	} );
	signals.resumeHiding.add( function () {

		while(hideObjects.length>0){
			var object=hideObjects.pop();
			object.visible=true;
		}

	} );

	signals.halfHideObject.add( function (object) {

		var tObjects=[];
		for(var i in object){

			if(object[i].visible && !object[i].userData.opacity){
				getSelectionObjects(object[i],tObjects);
			}
		}

		for(var i=0;i<tObjects.length;i++){

			if(tObjects[i].material!==undefined && !tObjects[i].userData.opacity){
				tObjects[i].material.opacity *=0.5;
				tObjects[i].userData.opa = tObjects[i].material.opacity;

				tObjects[i].userData.opacity=true;
				halfHideObjects.push(tObjects[i]);
			}
		}

	} );
	signals.halfViewSeparately.add( function (object) {

		var tObjects=[];
		halfHideObjects=[];
		for(var i in object){

			if(object[i].visible )getSelectionObjects(object[i],tObjects);
		}

		for(var i=0;i<objects.length;i++){

			if(objects[i].children.length>0)continue;

			var obj=objects[i];

			if(tObjects.indexOf(obj)>=0){

				if( obj.material!==undefined ){//obj.userData.opacity &&

					obj.material.opacity =obj.userData.topacity;
				}

				if(obj.material!==undefined)obj.userData.opa = obj.material.opacity;

				delete obj.userData.opacity;
			}else{

				if(!obj.userData.opacity && obj.material!==undefined){
					obj.material.opacity *=0.5;
					obj.userData.opa = obj.material.opacity;
					obj.userData.opacity=true;
				}

				halfHideObjects.push(obj);
			}

		}

	} );
	signals.resumeHalfHiding.add( function () {

		while(halfHideObjects.length>0){

			var object=halfHideObjects.pop();
			if(object.material!== undefined){

				object.material.opacity =object.userData.topacity;
				object.userData.opa=object.material.opacity;
			}

			delete object.userData.opacity;
		}

	} );

	signals.setColor.add( function (object,color) {

		var tObjects=[];
		for(var i in object){

			if(object[i].visible )getSelectionObjects(object[i],tObjects);
		}

		for(var i=0;i<tObjects.length;i++){

			if( tObjects[i].material!==undefined ){
				tObjects[i].material.color.setStyle(color);
                objectColors.push(tObjects[i]);
            }//setHex(color);
		}

	} );
	signals.recoveryColor.add( function (object) {

        var tObjects=[];

		if(object===undefined)tObjects = objectColors.slice(0);
		else {
            for(var i in object){

                if(object[i].visible )getSelectionObjects(object[i],tObjects);
            }
		}

		for(var i=0;i<tObjects.length;i++){

            var index = objectColors.indexOf(tObjects[i]);

			if( index!==-1 && tObjects[i].material!==undefined ){

				tObjects[i].material.color.setHex(tObjects[i].material.userData.color);
                objectColors.splice(index,1);
            }
		}
// console.log(objectColors.length);
	} );
	signals.setOpacity.add( function (object,opacity) {

		var tObjects=[];
		for(var i in object){

			if(object[i].visible )getSelectionObjects(object[i],tObjects);
		}

		for(var i=0;i<tObjects.length;i++){

			if( tObjects[i].material!==undefined ){

				tObjects[i].material.opacity = opacity;
				tObjects[i].userData.topacity = opacity;
				tObjects[i].userData.opa=tObjects[i].material.opacity;
			}
		}

	} );

	signals.setAntialias.add( function (value) {

		if(_antialias === value) return;

        _antialias = value;

		container.dom.removeChild(renderer.domElement);
		delete renderer;
		renderer=getRenderer();
		renderer.setSize( container.dom.offsetWidth, container.dom.offsetHeight );
		container.dom.appendChild( renderer.domElement );

		cubeCamera.updateRenderer(renderer);

        //设置背面剔除
        if(_faceCulling === false){

            _faceCulling = true;
            signals.setFaceCulling.dispatch( false);
        }

		render();
	} );
	signals.setFaceCulling.add( function (value) {

        if(_faceCulling === value) return;

        _faceCulling = value;

		renderer.setFaceCulling(((value)?THREE.CullFaceBack:THREE.CullFaceNone));
		renderer.setFaceCull(value);

		render();

	} );

	signals.setLogo.add( function (x,y, width, height,url) {

        var image = new Image();
        image.src = url;
        image.onerror = function(){

        	alert("图片路径错误！！");
        	// console.error(error);
		};
        image.onload = function(){

            if(logo==undefined){

                logo =new UI.Img;
                logo.setId('logoImage');
                container.add(logo);
            }
            logo.setLeft(x+'px');
            logo.setTop(y+'px');
            logo.setWidth(width+'px');
            logo.setHeight(width+'px');
            logo.setBackground('url('+image.src+') no-repeat');
            logo.setBackgroundSize('contain');

		};

	} );
	signals.setBackground.add( function (value0,value1) {

		var view=document.getElementById( "viewport" );
		view.style.background = ' -webkit-linear-gradient(top,'+value0+','+value1+')';
		view.style.background = '  -ms-linear-gradient(top,'+value0+','+value1+')';

		backGroupStart=value0;backGroupEnd=value1;

	} );
	signals.setHighlight.add( function (color,opacity) {

		highlightColor=color;
		highlightOpacity=opacity;

	} );

	signals.setEditorCenter.add( function () {
		controls.center.set(objectCenter.x,objectCenter.y,objectCenter.z);
	} );
	//
	signals.sceneGraphChanged.add( function () {

		render();
	} );
	//
	signals.changeColor.add( function ( object , change ) {

		for(var i=0;i<object.children.length;i++){

			var obb=object.children[i];
			if(obb.children.length>0)signals.changeColor.dispatch(obb,change);
			else setChange(obb);
		}
		setChange(object);

		function setChange(obj){

			if(obj.material !== undefined){

				if( change && obj.currentHex==undefined ){

					obj.currentHex = obj.material.emissive.getHex();
                    // obj.currentHex = obj.material.color.getHex();
					obj.userData.opa = obj.material.opacity;

                    // obj.material.color.setStyle(highlightColor);
					obj.material.emissive.setStyle(highlightColor);
					obj.material.opacity=highlightOpacity;

				}else if( !change && obj.currentHex!==undefined){

					obj.material.emissive.setHex( obj.currentHex );
					obj.material.opacity = obj.userData.opa;

					obj.currentHex=undefined;
					delete obj.userData.opa;
				}
			}
		}

	} );
	//
	signals.cameraChanged.add( function () {

		render();

	} );
	signals.cameraChangedStart.add( function () {

		controls.enableRotate=true;
	} );
	signals.cameraChangedEnd.add( function () {

		controls.enableRotate=false;
	} );
	//
	signals.objectSelected.add( function ( object , value) {

		while(selectionObject.length>0){
			var sobj=selectionObject.pop();
			signals.changeColor.dispatch(sobj,false);
		}

		if(value){

			var tObjects=[];
			for(var i in object){

				if(object[i].visible )getSelectionObjects(object[i],tObjects);
			}

			for(var i=0;i<tObjects.length;i++){

				signals.changeColor.dispatch(tObjects[i],true);
				selectionObject.push(tObjects[i]);
			}

		}else if ( object !== null ) {

			//现选中物体进行处理
			signals.changeColor.dispatch(object,true);
			selectionObject.push(object);
		}

		render();

	} );
	//
	signals.objectFocused.add( function ( object ) {

		controls.focus( object );

	} );
	//
	signals.objectAdded.add( function ( object ) {

		object.traverse( function ( child ) {

			//if(child.geometry!==undefined){
            //
			//	var box = new THREE.BoxHelper( child );
			//	box.rotateX(-Math.PI / 2);
			//	editor.sceneGroup.add( box );
			//}

			// if(child.geometry!==undefined){
            //
			// 	var edges = new THREE.EdgesGeometry( child.geometry );
			// 	var line = new THREE.LineSegments( edges );
			// 	line.rotateX(-Math.PI / 2);
			// 	editor.sceneGroup.add( line );
			// }

            // if(child.geometry!==undefined){
            //
            // 	var line = new THREE.WireframeHelper( child );
            // 	// editor.sceneGroup.add( line );
            //     objects.push( line );
            // }

			objects.push( child );

		} );

		// function createWireframe

	} );

	signals.objectRemoved.add( function ( object ) {

		object.traverse( function ( child ) {

			objects.splice( objects.indexOf( child ), 1 );

		} );

	} );
	//
	signals.toImage.add( function (filename) {

		//获取3D数据
		render();
		var gl=renderer.domElement;
		imgData = gl.toDataURL("image/png");

		//下载后的路径名
		// var filename = '3DAir' + (new Date()).getTime() + '.' + 'jpg';

		var imge = new Image();
		imge.src=imgData;

		imge.onload=function(){

			var canvasData=createImage();//获取2D数据
			saveFile(canvasData,filename);
		};

		function createImage(){

			var canvas = document.createElement( 'canvas' );
			canvas.width = container.dom.offsetWidth;canvas.height =  container.dom.offsetHeight;

			var context = canvas.getContext( '2d');
			//绘制背景
			var grd=context.createLinearGradient(0,0,0,container.dom.offsetHeight);
			grd.addColorStop(0,backGroupStart);
			grd.addColorStop(1,backGroupEnd);
			context.fillStyle=grd;
			context.fillRect(0,0,container.dom.offsetWidth,container.dom.offsetHeight);

			//context.globalAlpha=0.9;
			//绘制3D数据
			context.fillStyle = 'white';
			context.drawImage(imge,0,0);

			//绘制2D数据
			signals.drawImage.dispatch(context,container.dom.offsetHeight);

			return canvas;

		}
		//download
		function saveFile(data, filename){

			if (window.navigator.msSaveOrOpenBlob) {//IE

				var blob = data.msToBlob();
				navigator.msSaveBlob(blob, filename);
			}else{

				editor.link.href = data.toDataURL();//'image/png'
				editor.link.download = filename;
				editor.link.click();
			}

		}

	} );
	//
	signals.windowResize.add( function () {

		// TODO: Move this out?

		editor.DEFAULT_CAMERA.aspect = container.dom.offsetWidth / container.dom.offsetHeight;
		editor.DEFAULT_CAMERA.updateProjectionMatrix();

		editor.camera.aspect = container.dom.offsetWidth / container.dom.offsetHeight;
		editor.camera.updateProjectionMatrix();

		renderer.setSize( container.dom.offsetWidth, container.dom.offsetHeight );

		//
		cubeCamera.sizeChange();

		render();

	} );
	//




	var cubeCamera=new CubeCamera( editor,controls);
	//
	var renderer = getRenderer();

    cubeCamera.setRenderer(renderer,container.dom);
	container.dom.appendChild( renderer.domElement );
	//
	// cubeCamera.setRenderer(renderer,container.dom);

	animate();
	function animate(){

		requestAnimationFrame( animate );
		if(flightMode.enabled)flightMode.update();
	}

	render();

	function render() {

        scene.updateMatrixWorld();
        sceneHelpers.updateMatrixWorld();

		directionalLight.position.set(camera.position.x,camera.position.y+10.0,camera.position.z);

		renderer.clear();
		renderer.setViewport(0, 0, container.dom.offsetWidth, container.dom.offsetHeight);
		renderer.render( scene, camera );//绘制3D主场景

		var value = renderer.clippingPlanes;
		renderer.clippingPlanes = [];

		renderer.render( sceneHelpers, camera );

		cubeCamera.renderScene();

		renderer.clippingPlanes = value;

        updateLabels();
        updateCenterLabel();
        // updateMeasureLabel();

	}

	return container;
};
