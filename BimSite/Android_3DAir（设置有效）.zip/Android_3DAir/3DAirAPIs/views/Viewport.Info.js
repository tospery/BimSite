/**
 * @author mrdoob / http://mrdoob.com/
 */

Viewport.Info = function ( editor ) {

	var signals = editor.signals;

	var container = new UI.Panel();
	container.setId( 'info' );
	container.setPosition( 'absolute' );
	container.setLeft( '0px' );
	container.setBottom( '0px' );
	container.setFontSize( '12px' );
	container.setColor( '#000' );
	//物体信息
	/*var objectsText = new UI.Text( '0' ).setMarginLeft( '6px' );
	var verticesText = new UI.Text( '0' ).setMarginLeft( '6px' );
	var trianglesText = new UI.Text( '0' ).setMarginLeft( '6px' );
	var inforText = new UI.Text( '正常操作' ).setMarginLeft( '6px' );

	container.add( new UI.Text( 'objects:' ), objectsText, new UI.Break() );
	container.add( new UI.Text( 'vertices:' ), verticesText, new UI.Break() );
	container.add( new UI.Text( 'triangles:' ), trianglesText, new UI.Break() );
	container.add( new UI.Text( '提示:' ), inforText, new UI.Break() );

	signals.objectAdded.add( update );
	signals.sceneGraphChanged.add( update );

	signals.setFlightInfor.add( updateInfor );

	signals.drawImage.add( drawImage );

	//
	//更新物体信息数据
	function update() {

		var scene = editor.sceneGroup;

		var objects = 0, vertices = 0, triangles = 0;

		for ( var i = 0, l = scene.children.length; i < l; i ++ ) {

			var object = scene.children[ i ];

			object.traverseVisible( function ( object ) {

				objects ++;

				if ( object instanceof THREE.Mesh ) {

					var geometry = object.geometry;

					if ( geometry instanceof THREE.Geometry ) {

						vertices += geometry.vertices.length;
						triangles += geometry.faces.length;

					} else if ( geometry instanceof THREE.BufferGeometry ) {

						if ( geometry.index !== null ) {

							vertices += geometry.index.count * 3;
							triangles += geometry.index.count;

						} else {

							vertices += geometry.attributes.position.count;
							triangles += geometry.attributes.position.count / 3;

						}

					}

				}

			} );

		}

		objectsText.setValue( objects.format() );
		verticesText.setValue( vertices.format() );
		trianglesText.setValue( triangles.format() );

	}

	function updateInfor(value){

		inforText.setValue( value );
	}

	function drawImage(context,height){

		context.font='12px';
		context.fillStyle = '#000';
		context.fillText("提示:  "+inforText.getValue(),10,height-10);
		context.fillText("triangles:  "+trianglesText.getValue(),10,height-10-12);
		context.fillText("vertices:  "+verticesText.getValue(),10,height-10-12*2);
		context.fillText("objects:  "+objectsText.getValue(),10,height-10-12*3);
	}*/

	return container;

};
