/**
 * @author mrdoob / http://mrdoob.com/
 */

document.write("<link href='3DAirAPIs/css/main.css' type='text/css' rel='stylesheet'/>");
document.write("<link href='3DAirAPIs/css/tree.css' type='text/css' rel='stylesheet' />");

document.write("<script src='3DAirAPIs/build/three.js'></script>");
document.write("<script src='3DAirAPIs/utils/VarUtils.js'></script>");

document.write("<script src='3DAirAPIs/libs/signals.min.js'></script>");
document.write("<script src='3DAirAPIs/libs/ui.js'></script>");
document.write("<script src='3DAirAPIs/libs/ui.three.js'></script>");

document.write("<script src='3DAirAPIs/controls/EditorControls.js'></script>");
document.write("<script src='3DAirAPIs/controls/FlyControls.js'></script>");
document.write("<script src='3DAirAPIs/controls/CubeControls.js'></script>");
document.write("<script src='3DAirAPIs/controls/DissectControls.js'></script>");

document.write("<script src='3DAirAPIs/shaders/ShaderUtil.js'></script>");

document.write("<script src='3DAirAPIs/objects/CubeCamera.js'></script>");
document.write("<script src='3DAirAPIs/objects/ViewPoint.js'></script>");
document.write("<script src='3DAirAPIs/objects/Label.js'></script>");
document.write("<script src='3DAirAPIs/objects/DissectObject.js'></script>");
document.write("<script src='3DAirAPIs/objects/tree.js'></script>");

document.write("<script src='3DAirAPIs/measure/Measure.js'></script>");
document.write("<script src='3DAirAPIs/measure/PointMeasure.js'></script>");
document.write("<script src='3DAirAPIs/measure/TwoPointsDistanceMeasure.js'></script>");
// document.write("<script src='3DAirAPIs/measure/TwoSideDistanceMeasure.js'></script>");
document.write("<script src='3DAirAPIs/measure/PointToLineDistanceMeasure.js'></script>");
document.write("<script src='3DAirAPIs/measure/PointToPlaneDistanceMeasure.js'></script>");
document.write("<script src='3DAirAPIs/measure/StraightAngleMeasure.js'></script>");
document.write("<script src='3DAirAPIs/measure/ThreePointsAngleMeasure.js'></script>");

document.write("<script src='3DAirAPIs/views/Viewport.js'></script>");
document.write("<script src='3DAirAPIs/views/Viewport.Info.js'></script>");

document.write("<script src='3DAirAPIs/leftSidebar/LeftSidebar.js'></script>");
document.write("<script src='3DAirAPIs/leftSidebar/LeftSidebar.Assemble.js'></script>");

document.write("<script src='3DAirAPIs/Loader.js'></script>");

var Editor;//声明editor对象
Editor = function (value) {

	Number.prototype.format = function (){
		return this.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
	};

	//摄像机对象
	this.DEFAULT_CAMERA = new THREE.PerspectiveCamera(45, 1, 0.1, 10000);
	this.DEFAULT_CAMERA.name = 'Camera';
	this.DEFAULT_CAMERA.position.set(20, 10, 20);
	this.DEFAULT_CAMERA.lookAt(new THREE.Vector3());

	var Signal = signals.Signal;

	this.signals = {

		updateRender: new Signal(),//纯更新绘制
		editorCleared: new Signal(),//view清理

		getUuid: new Signal(),//获取物体uuid号

		selectedCenter: new Signal(),//选中居中
		zoomToView:new Signal(),//缩放至屏幕中心
		setSceneBox:new Signal(),//设置界面包围盒
		setView:new Signal(),//设置界面视图（前视图、后视图。。。。。）

		RenderType: new Signal(),//渲染模式（颜色渲染、线框渲染）

		flightMode:new Signal(),//飞行模式
		setFlightInfor:new Signal(),//设置界面操作信息
		//隐藏相关方法
		hideObject:new Signal(),//隐藏指定物体
		viewSeparately:new Signal(),//隐藏非指定物体
		resumeHiding:new Signal(),//恢复隐藏
		//半隐相关方法
		halfHideObject: new Signal(),//半隐指定物体
		halfViewSeparately: new Signal(),//半隐非指定物体
		resumeHalfHiding: new Signal(),//恢复半隐

		setColor: new Signal(),//设置指定物体颜色
		recoveryColor: new Signal(),//恢复物体颜色
		setOpacity: new Signal(),//设置指定物体透明度

		setAntialias: new Signal(),//是否开启抗锯齿
		setFaceCulling: new Signal(),//是否开启背面剪裁

		setLogo: new Signal(),//设置logo图标
		setBackground: new Signal(),//设置背景颜色
		setHighlight: new Signal(),//设置选中高亮样式

		toImage: new Signal(),//保存图片
		drawImage: new Signal(),//绘制2D图

		setDissect: new Signal(),//设置剖切
		//标签相关方法
		getLabelInfor: new Signal(),//获取选中标签的标签信息
        getLabelInfors: new Signal(),//获取所有标签的标签信息
        getInforToCreateLabel: new Signal(),//根据标签信息创建标签
		getLabelObject: new Signal(),//获取选中标签对象
        updateLabelObject: new Signal(),//更新标签选中状态--用于保存json文件
		setLabel: new Signal(),//设置标签
		saveLabel: new Signal(),//保存标签
		readLabel: new Signal(),//读取json中的标签信息并创建相应标签
		updateTextLabel: new Signal(),//更新标签
		displayRemarks: new Signal(),//是否隐藏3D标签中的2D标签
		setRemarks: new Signal(),//设置3D标签中2D标签文字信息
        updateLabelToLine: new Signal(),//在2D标签中更新标签连线
        updateObjectToLine: new Signal(),//在3D标签中更新标签连线

		createRingLabel: new Signal(),//根据标签信息创建3D圆环标签
        createRectLabel: new Signal(),//根据标签信息创建3D矩形标签
		//测量相关方法
        setMeasure: new Signal(),//设置测量
        saveMeasureLabel: new Signal(),//保存测量标注
        readMeasureLabel: new Signal(),//读取json中的测量标注信息并创建测量标注
		restColor: new Signal(),//恢复测量标注颜色--用于保存json文件

		setViewEvent: new Signal(),//设置view的鼠标监听方法
		//视点相关方法
		saveView: new Signal(),//保存视点
		openView: new Signal(),//打开视点
		deleteView: new Signal(),//删除视点
		getViewPointArray: new Signal(),//获取视点数组
		saveViewPoint: new Signal(),//保存视点信息（Json文件）
		readViewPoint: new Signal(),//读取json中的视点信息并记录视点

		restViewControl: new Signal(),//恢复view操作为初始状态
////////////////////////////////////////////////////////////////////
		createLoading:new Signal(),//创建加载条
		deleteLoading:new Signal(),//删除加载条

		setEditorCenter: new Signal(),//设置控制中心点

		sceneGraphChanged: new Signal(),//更新view并重新绘制
		//
		cameraChanged: new Signal(),//摄像机改变
		cameraChangedEnd: new Signal(),//摄像机结束改变
		cameraChangedStart: new Signal(),//摄像机开始改变

		objectSelected: new Signal(),//选中物体操作
		objectFocused: new Signal(),//选中物体焦点

		objectAdded: new Signal(),//添加物体
		objectRemoved: new Signal(),//移除物体

		windowResize: new Signal(),//屏幕大小改变--屏幕自适应

		changeColor:new Signal()//改变物体颜色

	};

	//保存文件控件
	this.link = document.createElement( 'a' );this.link.style.display = 'none';
	document.body.appendChild( this.link ); // Firefox workaround, see #6594

	this.RENDERTYPE=["COLOR","LINE"];//渲染模式

	this.SELECTMODE=["Assembly","Component","Parts"];//选择模式
	this.seModeType=this.SELECTMODE[2];//当前选择模式

	this.LABEL=["正常操作","文字标签","文字标注","圆形标注","矩形标注","图片标签"];//标签类型
	this.labelType=this.LABEL[0];//当前标签类型

	this.DISSECT=["XY剖视","YZ剖视","XZ剖视","法线剖视","自由剖视"];

	this.loader = undefined;//new Loader(this);

	this.camera = this.DEFAULT_CAMERA.clone();

	//界面对象
	this.DEFAULT_SCENEGROUP=new THREE.Group();
	this.DEFAULT_SCENEGROUP.name = 'Scene';//用于最终根节点的判断

	this.scene = new THREE.Scene();

	this.sceneGroup=this.DEFAULT_SCENEGROUP.clone();

	this.sceneHelpers = new THREE.Scene();
	//圆形和矩形标注
	this.labelGroup=new THREE.Group();
	this.lineGroup=new THREE.Group();
	//测量对象
    this.measureGroup=new THREE.Group();
    this.measureGroupHelpers=new THREE.Group();
    // this.wireframeObjects = [];

	this.selected = null;
	this.uuids='';

	//标注
	this.selectedLabel = null;

	//
	this.container = new UI.Panel();
	this.container.setId( value );
	this.container.setPosition( 'absolute' );
	//
};

Editor.prototype = {

	//初始化界面
	setView: function (path,value) {

		var sorce = this;
        try {
        	if(path=="")
        		THREE_PATH="/BimSiteApp/";
        	else
        		THREE_PATH = "/BimSiteApp/"+path+"/";
            if(value ==true)sorce.container.add( new LeftSidebar( this ) );
            var viewContainer = new Viewport( this );
            if(value == true)viewContainer.setLeft('0%');
            sorce.container.add(viewContainer);
            sorce.loader = new Loader(sorce,viewContainer);
            document.body.appendChild( sorce.container.dom );

            return 0;
        } catch ( error ) {

            alert( error );
            return -1;
        }

	},

	//打开本地模型
    openLocalModel: function (url) {

		if(url === undefined)return -1;

        if(this.sceneGroup.children.length>0)this.clear();//清空当前
		this.loader.loadFile(url);

    },
	//打开--清除原有的模型
	openModel: function (url) {

        if(url === undefined)return -1;

		if(this.sceneGroup.children.length>0)this.clear();//清空当前
		this.loader.loadJsonFile(url);
	},
	addModel: function(url){

        if(url === undefined)return -1;

		this.loader.loadJsonFile(url);
	},
	//卸载
	unloadModel: function (uid) {

		if(uid==undefined || uid.length===undefined || uid.length==0)return -2;

		var scope = this;
		var uids=uid.split('*');
		var unLoad = false;
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined){
                unLoad =true;
				scope.removeObject(object);
            }
		}
		if(unLoad)this.signals.sceneGraphChanged.dispatch();

		return (unLoad?0:-1);
	},
	clear: function () {

		if ( confirm( 'Any unsaved data will be lost. Are you sure?' ) ) {

            try {

                this.camera.copy( this.DEFAULT_CAMERA );
                this.seModeType=this.SELECTMODE[2];

                this.scene.remove(this.sceneGroup);
                this.sceneGroup=this.DEFAULT_SCENEGROUP.clone();

                this.selected = null;

                this.selectedLabel=null;

                this.deselect();

                this.labelType=this.LABEL[0];

                this.signals.editorCleared.dispatch();

                // this.signals.setLabel.dispatch(false,true);//取消标签操作
                this.signals.setFlightInfor.dispatch("正常操作");

                this.signals.sceneGraphChanged.dispatch();

                return 0;
            } catch ( error ) {

                alert( error );
                return -1;
            }

		}else{

			return -2;
		}
	},

	//恢复默认操作
    reset: function(){

        this.signals.restViewControl.dispatch();//取消操作
	},

	getObjectUuid: function(){

		this.signals.getUuid.dispatch();
		return this.uuids;
	},

	centerSelected: function(uid){

		if(uid==undefined || uid.length===undefined || uid.length==0) return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0){

			this.signals.selectedCenter.dispatch(objects);
            return 0;
		}else return -1;

	},
	zoomToView: function(){
		this.signals.zoomToView.dispatch();
	},

	mainView:function(){

		this.signals.setView.dispatch(5);
	},
	frontView:function(){

		this.signals.setView.dispatch(8);
	},
	backView:function(){

		this.signals.setView.dispatch(9);
	},
	leftView:function(){

		this.signals.setView.dispatch(10);
	},
	rightView:function(){

		this.signals.setView.dispatch(11);
	},
	topView:function(){

		this.signals.setView.dispatch(12);
	},
	bottomView:function(){

		this.signals.setView.dispatch(13);
	},

//========================剖视===============start======================
	dissectXY:function(value){

		this.signals.setDissect.dispatch(this.DISSECT[0],value);
	},
	dissectYZ:function(value){

		this.signals.setDissect.dispatch(this.DISSECT[1],value);
	},
	dissectXZ:function(value){

		this.signals.setDissect.dispatch(this.DISSECT[2],value);
	},
	dissectNormal:function(value){

		this.signals.setDissect.dispatch(this.DISSECT[3],value);
	},
	dissect:function(value){

		this.signals.setDissect.dispatch(this.DISSECT[4],value);
	},
//========================剖视===============end========================

	//========================视点===============start======================
	saveView: function(){

		this.signals.saveView.dispatch();
		return 0;
	},
	openView: function(value){

        THREE_RETURN = -1;
		this.signals.openView.dispatch(value);
		return THREE_RETURN;
	},
	deleteView: function(value){

        THREE_RETURN = -1;
        this.signals.deleteView.dispatch(value);
        return THREE_RETURN;
	},
    getViewPointArray: function(){

        this.signals.getViewPointArray.dispatch();
        return THREE_ViewPoint;
	},
	//========================视点===============end========================

//========================测量===============start======================

    twoPointsDistance:function(value){

        this.signals.setMeasure.dispatch(value,"两点距离");
        this.signals.setFlightInfor.dispatch((value)?"两点距离":"正常操作");
    },
    // twoSideDistance:function(value){
    //
    //     this.signals.setMeasure.dispatch(value,"两面距离");
    //     this.signals.setFlightInfor.dispatch((value)?"两面距离":"正常操作");
    // },
    pointToLineDistance:function(value){

        this.signals.setMeasure.dispatch(value,"点线距离");
        this.signals.setFlightInfor.dispatch((value)?"点线距离":"正常操作");
    },

    pointToPlaneDistance:function(value){

        this.signals.setMeasure.dispatch(value,"点面距离");
        this.signals.setFlightInfor.dispatch((value)?"点面距离":"正常操作");
    },
    coordinateMeasurement:function(value){

        this.signals.setMeasure.dispatch(value,"坐标测量");
        this.signals.setFlightInfor.dispatch((value)?"坐标测量":"正常操作");
    },
    straightAngleMeasurement:function(value){

        this.signals.setMeasure.dispatch(value,"直线夹角");
        this.signals.setFlightInfor.dispatch((value)?"直线夹角":"正常操作");
    },
    threePointsAngleMeasure:function(value){

        this.signals.setMeasure.dispatch(value,"三点角度");
        this.signals.setFlightInfor.dispatch((value)?"三点角度":"正常操作");
    },
//========================测量=================end======================

//========================标签===============start======================
	textLabel:function(){

		if(this.labelType===this.LABEL[1])this.labelType=this.LABEL[0];
		else this.labelType=this.LABEL[1];

		this.signals.setLabel.dispatch((this.labelType==this.LABEL[1]),true);
		this.signals.setFlightInfor.dispatch((this.labelType==this.LABEL[1])?"文字标签":"正常操作");
	},

    imageLabel:function(value){

		if(this.labelType===this.LABEL[5] || value===undefined )this.labelType=this.LABEL[0];
		else this.labelType=this.LABEL[5];

		var loadImg=(this.labelType == this.LABEL[5]);
		if(loadImg){

            // this.loader.loadImageFile( value );
            if(this.loader.loadImageFile( value ) === -2 ) {

				loadImg = false;THREE_RETURN = -2;
                this.labelType=this.LABEL[0];
            }
        }

		this.signals.setLabel.dispatch(loadImg,true);
		this.signals.setFlightInfor.dispatch((loadImg)?"图片标签":"正常操作");
	},

	textLabeling:function(){

		if(this.labelType===this.LABEL[2])this.labelType=this.LABEL[0];
		else this.labelType=this.LABEL[2];

		this.signals.setLabel.dispatch((this.labelType==this.LABEL[2]),true);
		this.signals.setFlightInfor.dispatch((this.labelType==this.LABEL[2])?"文字标注":"正常操作");
	},
	roundLabel:function(){

		if(this.labelType===this.LABEL[3])this.labelType=this.LABEL[0];
		else this.labelType=this.LABEL[3];

		this.signals.setLabel.dispatch((this.labelType==this.LABEL[3]),false);
		this.signals.setFlightInfor.dispatch((this.labelType==this.LABEL[3])?"圆形标注":"正常操作");
	},
	rectLabel:function(){

		if(this.labelType===this.LABEL[4])this.labelType=this.LABEL[0];
		else this.labelType=this.LABEL[4];

		this.signals.setLabel.dispatch((this.labelType==this.LABEL[4]),false);
		this.signals.setFlightInfor.dispatch((this.labelType==this.LABEL[4])?"矩形标注":"正常操作");
	},

	getLabelInfor: function(){

        this.signals.getLabelInfor.dispatch();
		return this.selectedLabel;
	},
    getLabelInfors: function(){

		var infors ={};
        this.signals.getLabelInfors.dispatch(infors);
        return infors;
    },
    getInforToCreateLabel: function(infor){

        this.signals.getInforToCreateLabel.dispatch(infor);
        this.signals.updateRender.dispatch();
    },

	updateTextLabel:function(parameters){

		this.signals.updateTextLabel.dispatch(parameters);
	},
	displayRemarks:function(value){

		this.signals.displayRemarks.dispatch(value);
	},
	setRemarks:function(value){

		this.signals.setRemarks.dispatch(value);
	},
//========================标签===============end========================

	colorRender:function(){
		this.signals.RenderType.dispatch(this.RENDERTYPE[0]);
		return 0;
	},
	lineRender:function(){
		this.signals.RenderType.dispatch(this.RENDERTYPE[1]);
        return 0;
	},

	flightMode:function(value){

        if(value === undefined) return -2;

        this.signals.flightMode.dispatch(value);
        return (value)?0:-1;

	},

	selectMode:function(value){

		this.seModeType=this.SELECTMODE[value];
	},

	hideObject: function(uid){

		if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var hide = false;
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined){

                hide = true;
				this.signals.hideObject.dispatch(object);
            }
		}

		if(hide === true){

            this.selected = null;
			this.signals.updateRender.dispatch();
        }

		return hide?0:-1;
	},
	viewSeparately: function(uid){

        if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}
		if(objects.length>0){
			this.signals.viewSeparately.dispatch(objects);
			this.signals.updateRender.dispatch();
		}

		return objects.length>0?0:-1;
	},
	resumeHiding: function(){

		this.signals.resumeHiding.dispatch();
		this.signals.updateRender.dispatch();
	},

	halfHideObject: function(uid){

        if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0){
			this.signals.halfHideObject.dispatch(objects);
			this.signals.updateRender.dispatch();
		}

        return objects.length>0?0:-1;
	},
	halfViewSeparately: function(uid){

        if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0){
			this.signals.halfViewSeparately.dispatch(objects);
			this.signals.updateRender.dispatch();
		}

        return objects.length>0?0:-1;
	},
	resumeHalfHiding: function(){
		this.signals.resumeHalfHiding.dispatch();
		this.signals.updateRender.dispatch();
	},

	setColor: function(uid,color){

        if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0){
			this.signals.setColor.dispatch(objects,color);
			this.signals.updateRender.dispatch();
		}

		return objects.length>0?0:-1;
	},
	recoveryColor: function(uid){

		if(uid==undefined){

            this.signals.recoveryColor.dispatch();
            this.signals.updateRender.dispatch();
			return 1;
        }

        if( uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0){
			this.signals.recoveryColor.dispatch(objects);
			this.signals.updateRender.dispatch();
		}

		return objects.length>0?0:-1;
	},
	setOpacity: function(uid,opacity){

        if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0){
			this.signals.setOpacity.dispatch(objects,opacity);
			this.signals.updateRender.dispatch();
		}

		return objects.length>0?0:-1;
	},
	setSelected: function(uid){

		if( uid==undefined || uid.length===undefined || uid.length==0 )return -2;

        this.selected = null;

		var uids=uid.split('*');
		var objects=[];
		for(var i in uids){

			var object=this.sceneGroup.getObjectByUuid(uids[i]);
			if(object!==undefined)objects.push(object);
		}

		if(objects.length>0)this.signals.objectSelected.dispatch(objects,true);

		return objects.length>0?0:-1;
	},

	setAntialias:function(value){

        if(value === undefined) return -2;

		this.signals.setAntialias.dispatch(value);
        return (value)?0:-1;
	},
	setFaceCulling:function(value){

		if(value === undefined) return -2;

		this.signals.setFaceCulling.dispatch(value);
        return (value)?0:-1;
	},

	setLogo:function(x,y, width, height,url){

        if(url === undefined || (url.length!==undefined && url.length === 0 ) ){

            alert("图片路径错误！！");
            return;
        }

		this.signals.setLogo.dispatch(x,y, width, height,url);
	},
	setBackground:function(startColor,endColor){

		this.signals.setBackground.dispatch(startColor,endColor);
	},
	setHighlight:function(color,opacity){

		this.signals.setHighlight.dispatch(color,opacity);
	},
	//保存
	toJSON: function (filename) {

		var scope = this;
		var output=[];

		for(var i=0; i<this.sceneGroup.children.length;i++){
			var object=this.sceneGroup.children[i];
			object.rotateX(Math.PI / 2);
			object.updateMatrix();
			output.push(object.toJSON());

			object.rotateX(-Math.PI / 2);
		}

		//标签物体
        this.signals.updateLabelObject.dispatch(false);//恢复选中3D标注对象
		var labelInfor = this.labelGroup.toJSON();
		labelInfor.type = 'THREE_labelObject';
		output.push( labelInfor );
        this.signals.updateLabelObject.dispatch(true);//高亮选中3D标注对象

		//标签连线
		var lineInfor = this.lineGroup.toJSON();
		lineInfor.type = 'THREE_labelLine';
		output.push( lineInfor );
		//标签
		this.signals.saveLabel.dispatch(output);

        //测量物体
        this.signals.restColor.dispatch(false);//恢复选中测量对象
        var measureInfor = this.measureGroup.toJSON();
        measureInfor.type = 'THREE_measure';
        output.push( measureInfor );
        this.signals.restColor.dispatch(true);//恢复选中测量对象
        // //测量标签
        // this.signals.saveMeasureLabel.dispatch(output);

		//视点
		this.signals.saveViewPoint.dispatch(output);

		try {

			output = JSON.stringify( output, null, '\t' );
			output = output.replace( /[\n\t]+([\d\.e\-\[\]]+)/g, '$1' );
		} catch ( e ) {

			output = JSON.stringify( output );
		}

		saveString( output, filename );

		function saveString( text, filename ) {

			save( new Blob( [ text ], { type: 'text/plain' } ), filename );

		}

		function save( blob, filename ) {

			if (window.navigator.msSaveOrOpenBlob) {

				navigator.msSaveBlob(blob, filename);
			}else{

				scope.link.href = URL.createObjectURL( blob );
				scope.link.download = filename || 'data.json';
				scope.link.click();
			}

		}

	},
	toImage: function(url){

		if(url===undefined) return -2;

        try {

            this.signals.toImage.dispatch(url);

            return 0;
        } catch ( error ) {

            alert( error );
            return -1;
        }

	},

	//
	//界面中选中物体
	select: function ( object ) {

		if ( this.selected === object && object!==null ) {

			return;
        }
		// if(object!==null ) return;

		this.selected = object;
		this.signals.objectSelected.dispatch( object , false );

	},
	//
	selectById: function ( id ) {

		if ( id === this.camera.id ) {

			this.select( this.camera );
			return;

		}

		var object=this.sceneGroup.getObjectById( id, true );
		this.select( object );

	},

	selectByUuid: function ( uuid ) {

		var scope = this;

		this.sceneGroup.traverse( function ( child ) {

			if ( child.uuid === uuid ) {

				scope.select( child );

			}

		} );

	},
	//
	deselect: function () {

		this.select( null );

	},

	focus: function ( object ) {

		this.signals.objectFocused.dispatch( object );

	},

	focusById: function ( id ) {

		this.focus( this.sceneGroup.getObjectById( id, true ) );

	},

	//添加物体信息
	addObject: function ( object ) {

		object.rotateX(-Math.PI / 2);
		this.sceneGroup.add( object );
		if(this.scene.children.length<3)this.scene.add(this.sceneGroup);

		this.signals.objectAdded.dispatch( object );
	},
	addLabelObject: function ( object ) {

		while(object.children.length>0){

			var label = object.children.pop();
			var normal = label.userData.normal;
			label.userData.normal = new THREE.Vector3(normal.x,normal.y,normal.z);
			this.labelGroup.add(label);
		}
	},
	addLabelLine: function ( object ) {

		while(object.children.length>0){

			var line = object.children.pop();
			this.lineGroup.add(line);
		}
	},
    addMeasure: function ( object ) {

        this.measureGroupHelpers.children=[];
        while(object.children.length>0){

            var measure = object.children.pop();
            this.measureGroupHelpers.add(measure);
        }
        this.signals.readMeasureLabel.dispatch("");
    },
    addMeasureLabel: function ( data ) {

        this.signals.readMeasureLabel.dispatch(data);
    },
	addLabel: function ( data ) {

		this.signals.readLabel.dispatch(data);
	},
	addViewPoint: function ( data ) {

		this.signals.readViewPoint.dispatch(data);
	},
	//移除物体
	removeObject: function ( object ) {

		if ( object.parent === null ) return; // avoid deleting the camera or scene

		object.parent.remove( object );
		this.signals.objectRemoved.dispatch( object );

	}

};
