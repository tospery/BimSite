/**
 * Created by Administrator on 2017/2/9.
 */
THREE.StraightAngleMeasure = function( editor, measure,pointsMaterial,lineMaterial ) {

    var scope = this;
//点对象相关变量
    var pointsObject = undefined;
    var points = [];
    var colors = [];
//连线对象相关变量
    var linesObject = undefined;
    var lpoints = [];
    var lcolors = [];
    var lineDistance =[];//长度数据
    var indexts =[];
    var count =0;

    var color = new THREE.Vector3(0.35294117647059,0.27058823529412,0.03921568627451);
    var tempObject = undefined;
    var tempObject0 = undefined;
    var line = undefined;

    this.name = 'SAM';

    this.restColor = function(indext){

        updatePointColor(indext,color);//还原点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,1.0,1.0));//还原连线颜色
        return '#5a450a';
    };
    this.selectColor = function(indext){

        updatePointColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中点颜色
        updateLineColor(indext,new THREE.Vector3(1.0,0.0,0.0));//选中连线颜色
        return 'red';
    };
    //当处于创建过程时，则删除临时对象
    this.deleteTempObject = function(){

        deleteTempObject0();
        deleteTempObject();
        editor.signals.updateRender.dispatch();
    };
    this.clear = function(){

        editor.measureGroup.remove(pointsObject);
        pointsObject = undefined;
        points = [];colors = [];

        editor.measureGroup.remove(linesObject);
        linesObject = undefined;
        lpoints = [];lcolors = [];lineDistance =[];//长度数据
        indexts =[];count =0;

        deleteTempObject0();
        deleteTempObject();
    };

    this.onPointerDown = function(event,point,face,object){

        if(tempObject !== undefined){

            createLines();
            deleteTempObject();
        }else {

            if(tempObject0!==undefined && tempObject0.visible === true){

                createTempObject();
            }
        }
    };
    this.onPointerMove = function(event,point,face,object){

        line = undefined;
        line  = createTempLine(face,object);
        line.updateMatrixWorld(true);

        var intersects = raycaster.intersectObject( line);

        if (intersects.length > 0) {

            var i = intersects[0].index;
            var start = line.geometry.vertices[i].clone();
            var end = line.geometry.vertices[i+1].clone();
            createTempObject0(start,end,object);
        }else{

            if(tempObject0!==undefined)tempObject0.visible = false;
        }

    };
    this.onPointerUp = function(event){

    };

    this.fromObject = function(object0,object1){

        var positions = (object1.geometry.getAttribute( 'position' )).array;
        var pcolors = (object1.geometry.getAttribute( 'customColor' )).array;
        for(var i =0;i<positions.length/3;i++){

            points.push(positions[i*3],positions[i*3+1],positions[i*3+2]);
            colors.push(pcolors[i*3],pcolors[i*3+1],pcolors[i*3+2]);
        }
        createPoints();

        var len = lineDistance.length/11+1;
        var lpositions = (object0.geometry.getAttribute( 'position' )).array;
        var lpcolors = (object0.geometry.getAttribute( 'color' )).array;
        var ld = (object0.geometry.getAttribute( 'lineDistance' )).array;
        for(var j =0;j<lpositions.length/3;j++){

            lpoints.push(lpositions[j*3],lpositions[j*3+1],lpositions[j*3+2]);
            lcolors.push(lpcolors[j*3],lpcolors[j*3+1],lpcolors[j*3+2]);
            lineDistance.push(ld[j]);
        }
        var lindexs = (object0.geometry.getIndex()).array;
        for(var k =0;k<lindexs.length;k++){

            indexts.push(lindexs[k]);
        }
        createLine();

        for(var t =len;t<=lineDistance.length/11;t++){

            var po = new THREE.Vector3(points[t*9-9],points[t*9-8],points[t*9-7]);
            var p1 = new THREE.Vector3(points[t*9-6],points[t*9-5],points[t*9-4]);
            var p2 = new THREE.Vector3(points[t*9-3],points[t*9-2],points[t*9-1]);

            var angle = (p1.sub(po)).angleTo(p2.sub(po));
            angle = 180/Math.PI * angle;
            var tangle = angle;angle = parseInt(tangle)+"°";tangle -=parseInt(tangle);
            tangle =tangle*60;angle +=parseInt(tangle)+"′";tangle -=parseInt(tangle);
            tangle =tangle*60;angle +=parseInt(tangle)+"″";

            var start = new THREE.Vector3(lpoints[t*33-6],lpoints[t*33-5],lpoints[t*33-4]);
            var end = new THREE.Vector3(lpoints[t*33-3],lpoints[t*33-2],lpoints[t*33-1]);

            createPointLabel((start.add(end).multiplyScalar(0.5)),angle,t);
        }
    };

    function createLines(){

        var tp0 = new THREE.Vector3();
        var tp1 = new THREE.Vector3();
        var tp2 = new THREE.Vector3();

        var point0 = new THREE.Vector3();
        var point1 = new THREE.Vector3();
        var point2 = new THREE.Vector3();
        var point3 = new THREE.Vector3();

        var angle = null;

        angleValue();
        if(intersectionLine(point0,point1,point2,point3)){

            points.push(tp0.x,tp0.y,tp0.z,tp1.x,tp1.y,tp1.z,tp2.x,tp2.y,tp2.z);
            colors.push(color.x,color.y,color.z,color.x,color.y,color.z,color.x,color.y,color.z);
            createPoints();

            var start0,end0,start1,end1;
            if(point0.distanceToSquared(tp0)>point1.distanceToSquared(tp0)){
                start0 = point1;end0 = point0;
            }else{
                start0 = point0;end0 = point1;
            }
            if(point2.distanceToSquared(tp0)>point3.distanceToSquared(tp0)){
                start1 = point3;end1 = point2;
            }else{
                start1 = point3;end1 = point2;
            }

            //向顶点数据中加入顶点数据
            lpoints.push(tp0.x,tp0.y,tp0.z);//不动线
            lpoints.push(start0.x,start0.y,start0.z,start1.x,start1.y,start1.z,start0.x,start0.y,start0.z,start1.x,start1.y,start1.z);//不动线
            lpoints.push(end0.x,end0.y,end0.z,end1.x,end1.y,end1.z,tp1.x,tp1.y,tp1.z,tp2.x,tp2.y,tp2.z);//不动线
            lpoints.push(tp1.x,tp1.y,tp1.z,tp2.x,tp2.y,tp2.z);//动线

            lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
            lcolors.push(1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0,1.0);
            //向长度数据中加入长度数据
            var dis0 = start0.distanceTo(tp0);
            var dis1 = start1.distanceTo(tp0);
            lineDistance.push( 0,dis0*10,dis1*10,0,0,0,0,0,0,60,60 );
            //索引值数据
            indexts.push(count*11,count*11+1, count*11,count*11+2, count*11+3,count*11+5, count*11+4,count*11+6,
                count*11+7,count*11+8, count*11+7,count*11+9, count*11+8,count*11+10);
            createLine();

            createPointLabel(((tp1.add(tp2)).multiplyScalar(0.5)),angle,lineDistance.length/11);
        }

        function angleValue(){

            point0 = tempObject.geometry.vertices[0].clone();
            point1 = tempObject.geometry.vertices[1].clone();
            point2 = tempObject0.geometry.vertices[0].clone();
            point3 = tempObject0.geometry.vertices[1].clone();

            var side0 = (point0.clone()).sub(point1);
            var side1 = (point2.clone()).sub(point3);

            angle = side0.angleTo(side1);
            angle = 180/Math.PI * angle;

        }

        function intersectionLine(p0,p1,p2,p3) {

            if(angle == 180 || angle == 0 || isNaN(angle) ){
                console.log("两直线平行！");
                return false;
            }

            var pp0 = (p1.clone()).sub(p0);
            var direction = (p3.clone()).sub(p2);
            var n1 = (pp0.clone()).cross(direction);//求两条直线的法线向量

            var n = n1.cross(pp0);

            var v = (p3.clone()).sub(p1);
            var denominator = n.dot(direction);
            if (denominator == 0){
                console.log("两直线不相交！");
                return false;
            }

            var d = (v.dot(n)) / denominator;
            tp0 = (p3.clone()).sub((direction.clone()).multiplyScalar(d));

            // console.log(p0);console.log(p1);console.log(tp0);
            //检查点tp0是否在直线pp0上
            var side0 = (p0.clone()).sub(tp0).normalize();
            var side1 = (p1.clone()).sub(tp0).normalize();

            angle = side0.angleTo(side1);
            angle = 180/Math.PI * angle;
            // console.log(angle);
            if(angle !== 180 && angle !== 0 && (!isNaN(angle)) ){
                console.log("两直线异面！");
                return false;
            }

            tp1 = (p0.distanceToSquared(tp0)>p1.distanceToSquared(tp0))?
                ( (p0.clone()).sub(tp0)).normalize().multiplyScalar(0.5).add(tp0):
                ( (p1.clone()).sub(tp0)).normalize().multiplyScalar(0.5).add(tp0);

            tp2 = (p2.distanceToSquared(tp0)>p3.distanceToSquared(tp0))?
                ( (p2.clone()).sub(tp0)).normalize().multiplyScalar(0.5).add(tp0):
                ( (p3.clone()).sub(tp0)).normalize().multiplyScalar(0.5).add(tp0);

            //计算夹角
            side0 = (tp1.clone()).sub(tp0);
            side1 = (tp2.clone()).sub(tp0);
            angle = side0.angleTo(side1);
            angle = 180/Math.PI * angle;

            if(angle == 180 || angle == 0 || isNaN(angle) ){
                console.log("两直线平行！");
                return false;
            }

            if(parseInt(angle)==0){

                console.log("角度小于1°！");
                return false;
            }

            var tangle = angle;
            angle = parseInt(tangle)+"°";
            tangle -=parseInt(tangle);
            tangle =tangle*60;
            angle +=parseInt(tangle)+"′";
            tangle -=parseInt(tangle);
            tangle =tangle*60;
            angle +=parseInt(tangle)+"″";

            return true;
        }
    }
    function createPoints(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.addAttribute( 'customColor', new THREE.BufferAttribute( new Float32Array( colors ), 3 ) );

        if(pointsObject!==undefined){

            editor.measureGroup.remove(pointsObject);
            pointsObject = undefined;
        }
        //创建点对象
        pointsObject = new THREE.Points( geometry, pointsMaterial );
        pointsObject.name='SAM';

        editor.measureGroup.add(pointsObject);//放入线对象
    }
    function createLine(){

        //几何体对象
        var geometry = new THREE.BufferGeometry();
        //向几何体缓冲对象中放入相应数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( lpoints ), 3 ) );
        geometry.addAttribute( 'color', new THREE.BufferAttribute( new Float32Array( lcolors ), 3 ) );
        geometry.addAttribute( 'lineDistance', new THREE.BufferAttribute( new Float32Array( lineDistance ), 1 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indexts ), 1 ) );

        if(linesObject!==undefined){

            editor.measureGroup.remove(linesObject);
            linesObject = undefined;
        }
        //创建线对象
        linesObject = new THREE.LineSegments(geometry,lineMaterial);
        linesObject.name='SAM';

        count = lpoints.length/33;

        editor.measureGroup.add(linesObject);//放入线对象
    }
    function createPointLabel(apoint,angle,len){

        var label = document.createElement( 'div' );
        label.id = "measure-lable";

        label.position=apoint;
        label.infor="∠ = "+angle;
        label.indext = len;
        label.parent =scope;

        label.style.whiteSpace='pre';
        label.style.color = '#5a450a';
        label.innerHTML=label.infor;

        measure.addLabelEvents(label);
    }

    //更新连线颜色--11
    function updateLineColor(indext,color){

        var i = indext;
        var lineColor = linesObject.geometry.getAttribute( 'color' );
        var lineColorArray = lineColor.array;
        for(var j =33;j>0;){

            lineColorArray[i*33-j] = color.x;j--;
            lineColorArray[i*33-j] = color.y;j--;
            lineColorArray[i*33-j] = color.z;j--;
        }

        lineColor.needsUpdate = true;
    }
    //更新连线位置
    this.updateLinePosition = function(indext,point,point0){

        var i = indext;
        var moveDist = (point.clone()).sub(point0);

        //更新连线位置
        var linePosition = linesObject.geometry.getAttribute( 'position' );
        var linePositionArray = linePosition.array;
        linePositionArray[i*33-1] += moveDist.z;linePositionArray[i*33-4] += moveDist.z;
        linePositionArray[i*33-2] += moveDist.y;linePositionArray[i*33-5] += moveDist.y;
        linePositionArray[i*33-3] += moveDist.x;linePositionArray[i*33-6] += moveDist.x;

        lpoints[i*33-1] += moveDist.z;lpoints[i*33-4] += moveDist.z;
        lpoints[i*33-2] += moveDist.y;lpoints[i*33-5] += moveDist.y;
        lpoints[i*33-3] += moveDist.x;lpoints[i*33-6] += moveDist.x;

        linePosition.needsUpdate = true;
        //更新连线间距
        var lDistance = linesObject.geometry.getAttribute( 'lineDistance' );
        var lDistanceArray = lDistance.array;
        var dis = ((new THREE.Vector3(lpoints[i*33-7],lpoints[i*33-8],lpoints[i*33-9])).distanceTo(
                new THREE.Vector3(lpoints[i*33-1],lpoints[i*33-2],lpoints[i*33-3])
            ))*20;
        lDistanceArray[i*11-1] = lDistanceArray[i*11-2] = dis;

        lineDistance[i*11-1] = lineDistance[i*11-2] = dis;

        lDistance.needsUpdate = true;
    };
    //更新点的颜色
    function updatePointColor(indext,color){

        var i = indext*3;
        var pointColor = pointsObject.geometry.getAttribute( 'customColor' );
        var pointColorArray = pointColor.array;
        pointColorArray[i*3-1] = pointColorArray[i*3-4] = pointColorArray[i*3-7] = color.z;
        pointColorArray[i*3-2] = pointColorArray[i*3-5] = pointColorArray[i*3-8] = color.y;
        pointColorArray[i*3-3] = pointColorArray[i*3-6] = pointColorArray[i*3-9] = color.x;

        pointColor.needsUpdate = true;
    }

    //临时对象方法
    function createTempObject(){

        var start = tempObject0.geometry.vertices[0].clone();
        var end = tempObject0.geometry.vertices[1].clone();

        var geometry = new THREE.Geometry();

        geometry.vertices[0] = start;
        geometry.vertices[1] = end;

        // tempObject = tempObject0.clone();
        // tempObject.material.color = new THREE.Color(0xFFFF00);

        tempObject = new THREE.LineSegments( geometry,new THREE.LineBasicMaterial( { color: 0xFF4500 } ) );
        editor.sceneHelpers.add(tempObject);//放入线对象
    }
    function deleteTempObject(){

        editor.sceneHelpers.remove(tempObject);//放入线对象
        tempObject = undefined;
    }

    function createTempObject0(start,end){

        var visible = (tempObject0!==undefined);
        var geometry = (visible)?tempObject0.geometry:new THREE.Geometry();

        geometry.vertices[0] = start;
        geometry.vertices[1] = end;

        if(!visible){

            tempObject0 = new THREE.LineSegments( geometry,new THREE.LineBasicMaterial( { color: 0xFFFF00 } ) );
            editor.sceneHelpers.add(tempObject0);//放入线对象
        }else{

            tempObject0.geometry.verticesNeedUpdate =true;
        }

        tempObject0.visible = true;
    }
    function deleteTempObject0(){

        editor.sceneHelpers.remove(tempObject0);//放入线对象
        tempObject0 = undefined;
    }

    function createTempLine(face,object){

        var geometry = new THREE.Geometry();

        var point0 = (object.geometry.vertices[face.a].clone()).applyMatrix4(object.matrixWorld);
        var point1 = (object.geometry.vertices[face.b].clone()).applyMatrix4(object.matrixWorld);
        var point2 = (object.geometry.vertices[face.c].clone()).applyMatrix4(object.matrixWorld);

        geometry.vertices[0] = geometry.vertices[5] = point0;
        geometry.vertices[1] = geometry.vertices[2] = point1;
        geometry.vertices[3] = geometry.vertices[4] = point2;


        var color = new THREE.Color(0xFFC0CB);
        geometry.colors[0] = color;geometry.colors[1] = color;
        geometry.colors[2] = color;geometry.colors[3] = color;
        geometry.colors[4] = color;geometry.colors[5] = color;

        line = new THREE.LineSegments( geometry,new THREE.LineBasicMaterial( { vertexColors: THREE.VertexColors } ) );

        return line;
    }

};