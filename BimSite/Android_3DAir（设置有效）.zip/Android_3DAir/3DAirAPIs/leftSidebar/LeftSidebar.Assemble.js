/**
 * Created by Administrator on 2016/10/18.
 */
LeftSidebar.Assemble = function ( editor ) {

    var signals = editor.signals;

    var container = new UI.Panel();
    container.setBorderTop( '0' );
    container.setPaddingTop( '0px' );

    function buildOption( object, draggable, indext  ) {

        var option = document.createElement( 'div' );
        option.v=indext;

        var infor=document.createElement( 'span' );
        infor.innerHTML=(object.name=='')?"part":object.name;
        infor.value = object.id;
        infor.uuid=object.uuid;
        //infor.draggable = draggable;

        option.appendChild(infor);

        return option;

    }

    var ignoreObjectSelectedSignal = false;

    var tree = new UI.Tree( editor );
    tree.setId( 'tree' );

    tree.onChange( function () {

        ignoreObjectSelectedSignal = true;
        //选中物体
        (editor.scene.visible)?editor.selectById( parseInt( tree.getValue() ) ):editor.selectByUuid( tree.getUuid());
        //console.log(tree.getValue());

        ignoreObjectSelectedSignal = false;

    } );
    tree.onDblClick( function () {

        //移到坐标原点
        editor.focusById( parseInt( tree.getValue() ) );

    } );

    container.add( tree );
    container.add( new UI.Break() );

    var refreshUI = function () {

        var scene = editor.sceneGroup;

        var options = [];

        ( function addObjects( objects, pad ) {

            for ( var i = 0, l = objects.length; i < l; i ++ ) {

                var object = objects[ i ];
                var option = buildOption( object, true , pad );
                options.push( option );

                addObjects( object.children, pad + 1 );

            }

        } )( scene.children, 1 );

        tree.setOptions( options );

        makeTree('tree');

    };

    signals.sceneGraphChanged.add( refreshUI );

    signals.objectSelected.add( function ( object ) {

        if ( ignoreObjectSelectedSignal === true ) return;

        tree.setValue( object !== null ? object.id : null, object !== null ? object.uuid : null );
    } );

    return container;

};