/**
 * Created by Administrator on 2016/10/18.
 */

var LeftSidebar = function ( editor ) {

    var container = new UI.Panel();
   /* container.setId( 'leftSidebar' );

    //左边操作界面
    var assembleTab = new UI.Text( '装配' ).onClick( onClick );
    //var coordinationTab = new UI.Text( '协同' ).onClick( onClick );

    var leftTabs = new UI.Div();
    leftTabs.setId( 'leftTabs' );
    leftTabs.add( assembleTab );//, coordinationTab );
    container.add( leftTabs );

    function onClick( event ) {

        select( event.target.textContent );

    }
    //
    var assemble = new UI.Span().add(
        new LeftSidebar.Assemble( editor )
    );
    container.add( assemble );

    function select( section ) {

        assembleTab.setClass( '' );
        //coordinationTab.setClass( '' );

        assemble.setDisplay( 'none' );

        switch ( section ) {
            case '装配':
                assembleTab.setClass( 'selected' );
                assemble.setDisplay( '' );
            break;
            //case '协同':
            //    coordinationTab.setClass( 'selected' );
            //break;
        }

    }

    select( '装配' );*/

    return container;

};