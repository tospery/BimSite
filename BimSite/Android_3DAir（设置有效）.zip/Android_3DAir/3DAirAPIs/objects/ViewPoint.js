/**
 * Created by Administrator on 2016/12/16.
 */

THREE.ViewPoint = function(){

    var point = [];

    this.addPoint = function(position,up,center,pos){

        var tcamera ={

            position:position.clone(),
            up:up.clone(),
            eye:center.clone(),
            pos:pos.clone()
        };
        point.push(tcamera);
    };

    this.openPoint = function(value){

        return point[value];
    };

    this.deletePoint = function(index){

        var object = point[index];
        if(object == undefined)return;

        point.splice(index,1);
        delete object.position;delete object.up;delete object.eye;delete object.pos;

        THREE_RETURN = 0;
    };

    this.clearPoints = function(){

        while(point.length>0){

            var object = point.pop();
            delete object.position;delete object.up;delete object.eye;delete object.pos;
        }
    };

    this.getPointLength = function(){

        return point.length;
    };

    this.getPoints = function(){

        return point.slice(0);
    };

    this.toJSON = function(){

        var output = {};
        output.point = point;
        output.type = 'THREE_Point';

        return output;
    };
    this.fromJSON = function(data){

        while(data.length>0){

            var infor = data.pop();
            infor.position = new THREE.Vector3(infor.position.x,infor.position.y,infor.position.z);
            point.push(infor);
        }
    };

};