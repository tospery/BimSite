/**
 * Created by Administrator on 2016/11/22.
 */

THREE.TextLabel = function(editor,container, controls) {

    var labelDiv=new UI.Div();
    container.add(labelDiv);

    var enable = false;
    var textlabels=[];
    var infor='请输入文字';
    var selected=null;

    var scope = this;

    var startBackGround=(setBackground('rgb(255,0,0)')).toDataURL();
    var selectBackGround=(setBackground('yellow')).toDataURL();

    this.clearLabel = function(){

        while(editor.lineGroup.children.length>0){

            var object = editor.lineGroup.children.pop();
            object.parent = null;
            object.dispatchEvent( { type: 'removed' } );
        }

        labelDiv.dom.innerHTML='';
        selected=null;
        textlabels=[];
        THREE_Img=undefined;

        scope.removeEvents();
    };

    this.addEvents = function(){

        enable=true;
        container.dom.addEventListener( "mousedown", onPointerDown, false );
    };
    this.removeEvents = function(){

        enable=false;
        container.dom.removeEventListener( "mousedown", onPointerDown );
    };

    this.createTextLabel = function(name,point,value,value0,value1,image,width,height){
        //createTextLabel('文字标注',mouseDown,true);//value表示是否为标注；value0表示显示文字； value1表示是否为图片标签

        var label = new UI.Div();
        label.setId( 'text-label' );label.setPosition( 'absolute' );label.setDisplay('inline');

        label.position=point;label.text=value;

        var div = document.createElement('div');
        div.infor=(value0!==undefined)?value0:infor;
        div.tColor='rgb(0,0,0)';div.bColor='rgb(255,0,0)';div.size='18px';div.font='Sans serif';
        div.type=name;div.text=value;div.parent=label;div.img=value1;
        if(div.img ===true){

            div.width=width;div.height=height;div.backGround=image;
        }
        if(value)div.backGround=startBackGround;

        setHTML(div);

        label.dom.appendChild(div);
        textlabels.push(label);
        labelDiv.add(label);

        return label;
    };

    this.updatePositions = function(camera,width,height) {

        for(var i in textlabels){

            var label=textlabels[i];
            this.updatePosition(label,width,height,camera);

        }
    };
    this.updatePosition = function(label,width,height,camera) {

        var hh= label.dom.offsetHeight;
        var ww= label.dom.offsetWidth;

        var coords2d = get2DCoords(label.position.clone(),width,height,camera);
        label.setLeft( coords2d.x-ww/2 + 'px');
        label.setTop( (coords2d.y-hh/2) + 'px');
    };

    this.setDisplay = function(value,label){

        var infor = (value)? 'inline': 'none';
        label.setDisplay(infor);
        label.dom.children[0].child.visible = (infor=='inline');

        editor.signals.updateObjectToLine.dispatch();
        editor.signals.updateRender.dispatch();
    };
    this.updateLabel = function(parameters){

        parameters = parameters || {};
        selected.infor = parameters.infor !== undefined ? parameters.infor : selected.infor;
        selected.tColor = parameters.tColor !== undefined ? parameters.tColor : selected.tColor;
        selected.bColor = parameters.bColor !== undefined ? parameters.bColor : selected.bColor;
        selected.size = parameters.size !== undefined ? parameters.size : selected.size;
        selected.font = parameters.font !== undefined ? parameters.font : selected.font;

        if(selected.img ===true){

            selected.width=parameters.width !== undefined ?parameters.width : selected.width;
            selected.height=parameters.height !== undefined ?parameters.height : selected.height;
            if( parameters.file !== undefined )this.loader.loadImageFile( parameters.file );
            selected.backGround=parameters.file !== undefined ? THREE_Img:selected.backGround;
        }

        if(selected.text)selected.backGround=parameters.bColor !== undefined ? (setBackground(parameters.bColor)).toDataURL():selected.backGround;

        selected.innerHTML ='';
        setHTML(selected);

        setLabel(selected);
        scope.updatePosition(selected.parent,container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,editor.camera);

    };
    this.setLabelText = function(label,value){

        var text=label.dom.children[0];
        text.infor = value;
        text.innerHTML ='';
        setHTML(text);

        if( selected==text ) setLabel(selected);
        scope.updatePosition(label,container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,editor.camera);
    };

    this.selectedLabel = function(){

        if(selected!==null){

            if(!selected.text)selected.style.border='2px solid '+selected.bColor;
            else{
                selected.style.background='url('+selected.backGround+') no-repeat';
                selected.style.backgroundSize='100% 100%';
            }
        }

        selected=null;
    };

    this.getSelected =function(){

        return selected;
    };

    this.getLabelInfor =function(output){

        output.label =[];
        for(var i=0;i<textlabels.length;i++){

            var label =textlabels[i];
            var labelInfor = labelbaseaInfor(label);
            if(label.dom.children[0].img ===true){

                labelInfor.backGround=label.dom.children[0].backGround;
                labelInfor.width=label.dom.children[0].width;
                labelInfor.height=label.dom.children[0].height;
            }
            if(label.object!==undefined){

                labelInfor.object = label.object.name;
                (label.object.name=='ring')?(labelInfor.parameters =
                    {innerRadius: label.object.geometry.parameters.innerRadius,
                        outerRadius: label.object.geometry.parameters.outerRadius,
                        matrix:label.object.matrixWorld.toArray()}):
                    (labelInfor.parameters =
                        {points: label.object.geometry.getAttribute('position').array,
                            indext: label.object.geometry.index.array,
                            matrix:label.object.matrixWorld.toArray(),
                            width:label.object.children[0].geometry.parameters.width,
                            size:label.object.userData.size,
                            positions:[label.object.children[0].position,label.object.children[1].position,label.object.children[2].position,label.object.children[3].position]
                        });
            }
            if(label.dom.children[0].child !==undefined)labelInfor.child = label.dom.children[0].child.geometry.vertices[0];

            output.label.push(labelInfor);
        }
        output = JSON.stringify( output, null, '\t' );
        output = output.replace( /[\n\t]+([\d\.e\-\[\]]+)/g, '$1' );

    };
    this.getInforToCreateLabel =function(infor){

        for(var i =0;i<infor.label.length;i++){

            var infors = infor.label[i];
            createLabel(infors);
        }
    };
    function createLabel(inform){

        var point = new THREE.Vector3(inform.point.x,inform.point.y,inform.point.z);
        var label = scope.createTextLabel(
            inform.name,point,inform.value,inform.value0,inform.value1,
            inform.backGround,inform.width,inform.height);
        label.setDisplay(inform.display);
        if(inform.object !== undefined){

            if(inform.object=='ring')editor.signals.createRingLabel.dispatch(inform.parameters,point.clone(),label);
            if(inform.object=='rect')editor.signals.createRectLabel.dispatch(inform.parameters,point.clone(),label);
        }
        // if(inform.value1 ===true){
        //
        //     label.dom.children[0].backGround =inform.backGround;
        //     label.dom.children[0].width =inform.width;
        //     label.dom.children[0].height =inform.height;
        //     console.log(inform.backGround);
        // }
        if(inform.child !== undefined){

            label.dom.children[0].child.geometry.vertices[0] =new THREE.Vector3(inform.child.x,inform.child.y,inform.child.z);
        }

    }

    editor.signals.updateLabelToLine.add( updateLine);
    function updateLine (clientX,clientY,object,name,positionArray){

        getCrosses(clientX,clientY,object,name,positionArray);
    }

    this.toJSON = function(){

        var output = {};
        output.label =[];

        for(var i in textlabels){

            var label =textlabels[i];
            var labelInfor = labelbaseaInfor(label);
            if(label.object!==undefined)labelInfor.object = label.object.uuid;
            if(label.dom.children[0].child !==undefined)labelInfor.child = label.dom.children[0].child.uuid;
            output.label.push(labelInfor);
        }
        output.type = 'THREE_label';
        return output;
    };
    this.fromJSON = function(data){

        for(var i=0; i< data.length; i++){

            var inform = data[i];
            var point = new THREE.Vector3(inform.point.x,inform.point.y,inform.point.z);
            var label = scope.createTextLabel(inform.name,point,inform.value,inform.value0,inform.value1);
            label.setDisplay(inform.display);
            if(inform.object !== undefined){

                var object = editor.labelGroup.getObjectByUuid(inform.object);
                label.object = object;
                object.tagg = label;
            }
            if(inform.child !== undefined){

                var object = editor.lineGroup.getObjectByUuid(inform.child);
                label.dom.children[0].child = object;
            }
        }
    };

    function labelbaseaInfor(label){

        return {
            name:label.dom.children[0].type,
            // point:label.position,
            point:{x:label.position.x,y:label.position.y,z:label.position.z},
            value:label.text,
            value0:label.dom.children[0].infor,
            value1:label.dom.children[0].img,
            display: label.dom.style.display
        };
    }

    function setHTML(div){

        setText(div);
        if(!div.text && div.child===undefined)setLine(div);

        div.style.cursor='pointer';
        div.addEventListener('mousedown', mousedown, false);

        //event
        var mouseX,mouseY;
        function mousedown(event){

            if( event.button !== 0 )return;

            if( enable===false)editor.signals.setViewEvent.dispatch(false);
            else container.dom.removeEventListener( "mousedown", onPointerDown );

            event.preventDefault();

            mouseX = event.clientX;mouseY = event.clientY;

            if(selected !== div){

                scope.selectedLabel();//还原颜色
                setLabel(div); //更改颜色
            }

            document.addEventListener( 'mousemove', mousemove, false );
            document.addEventListener('mouseup', mouseup, false);
        }
        function mousemove(event){

            if(mouseX == event.clientX && mouseY == event.clientY)return;

            var rect = container.dom.getBoundingClientRect();
            var hh= div.parent.dom.offsetHeight;
            var ww= div.parent.dom.offsetWidth;
            ww = event.clientX-rect.left-ww/2;
            hh = event.clientY-rect.top-hh/2;

            div.parent.setLeft( ww+ 'px');
            div.parent.setTop( hh + 'px');

            var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
            var onDownPosition = new THREE.Vector2( array[0],array[1] );

            THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );
            raycaster.setFromCamera( onDownPosition, editor.camera );
            var intersection = new THREE.Vector3();
            if ( raycaster.ray.intersectPlane( THREE_Plane, intersection ) ) {

                div.parent.position = intersection;
                if(!div.text){

                    // var lposition = div.child.geometry.getAttribute( 'position' );
                    // var positionArray = lposition.array;
                    // positionArray[3]=intersection.x;positionArray[4]=intersection.y;positionArray[5]=intersection.z;
                    div.child.geometry.vertices[1]=intersection.clone();

                    if(div.parent.object!==undefined){

                        div.child.geometry.vertices[0]=intersection.clone();
                        // positionArray[0]=intersection.x;positionArray[1]=intersection.y;positionArray[2]=intersection.z;
                        getCrosses(event.clientX, event.clientY,div.parent.object,div.parent.object.name,div.child.geometry.vertices);
                        // if(div.parent.object.name == 'ring'){
                        //
                        //     var point = new THREE.Vector3();
                        //     if(ringCrosses(event.clientX, event.clientY,div.parent.object,point)){
                        //
                        //         positionArray[0]=point.x;positionArray[1]=point.y;positionArray[2]=point.z;
                        //     }
                        // }else if(div.parent.object.name == 'rect'){
                        //
                        //     var point = new THREE.Vector3();
                        //     if(rectCrosses(event.clientX, event.clientY,div.parent.object,point)){
                        //
                        //         positionArray[0]=point.x;positionArray[1]=point.y;positionArray[2]=point.z;
                        //     }
                        // }

                    }

                    div.child.geometry.verticesNeedUpdate =true;
                    // lposition.needsUpdate = true;
                    editor.signals.updateRender.dispatch() ;
                }
            }

        }
        function mouseup(event){

            document.removeEventListener( 'mousemove', mousemove );
            document.removeEventListener('mouseup', mouseup );

            if( enable===false)editor.signals.setViewEvent.dispatch(true);
            else container.dom.addEventListener( "mousedown", onPointerDown, false );

        }

    }
    function setLabel(div){

        if(!div.text)div.style.border='2px solid rgb(0,255,0)';
        else{
            div.style.background='url('+selectBackGround+') no-repeat';
            div.style.backgroundSize='100% 100%';
        }
        selected=div;
    }
    function setText(element){

        if(element.img === true){

            element.style.width=element.width+'px';
            element.style.height=element.height+'px';
            element.style.background='url('+element.backGround+') no-repeat';
            element.style.backgroundSize='100% 100%';
            element.style.border='2px solid '+element.bColor;

            return;
        }

        element.style.whiteSpace='pre';
        element.style.font=element.size+" "+element.font;
        element.style.color=element.tColor;element.style.background='white';
        if(!element.text)element.style.border='2px solid '+element.bColor;
        else{

            element.style.background='url('+element.backGround+') no-repeat';
            element.style.backgroundSize='100% 100%';
        }

        var kg=(element.text)?"    ":" ";
        element.innerHTML=kg+element.infor+kg;
    }
    function setLine(element){

        var geometry = new THREE.Geometry();
        geometry.vertices[0]=element.parent.position.clone();
        geometry.vertices[1]=element.parent.position.clone();

        var line =  new THREE.Line(geometry,new THREE.LineBasicMaterial( {color: 0xFF4500, depthTest :false } ));
        element.child=line;
        editor.lineGroup.add(line);
    }
    function setBackground(color){

        var canvas = document.createElement( 'canvas' );
        var context = canvas.getContext( '2d' );

        canvas.width = 256;
        canvas.height = 128;

        context.lineWidth="3";

        var a=canvas.width/2-1;
        var b=canvas.height/2-2;
        var ox = 0.5 * a, oy = 0.6 * b;
        context.save();
        context.translate(canvas.width/2, canvas.height/2);

        context.fillStyle="white";
        context.beginPath();
        //从椭圆纵轴下端开始逆时针方向绘制
        context.moveTo(0, b);
        context.bezierCurveTo(ox, b, a, oy, a, 0);
        context.bezierCurveTo(a, -oy, ox, -b, 0, -b);
        context.bezierCurveTo(-ox, -b, -a, -oy, -a, 0);
        context.bezierCurveTo(-a, oy, -ox, b, 0, b);
        context.closePath();
        context.fill();
        context.restore();

        context.save();
        context.translate(canvas.width/2, canvas.height/2);
        context.strokeStyle=color;
        context.beginPath();
        //从椭圆纵轴下端开始逆时针方向绘制
        context.moveTo(0, b);
        context.bezierCurveTo(ox, b, a, oy, a, 0);
        context.bezierCurveTo(a, -oy, ox, -b, 0, -b);
        context.bezierCurveTo(-ox, -b, -a, -oy, -a, 0);
        context.bezierCurveTo(-a, oy, -ox, b, 0, b);
        context.closePath();
        context.stroke();
        context.restore();

        return canvas;
    }

    function get2DCoords(position,width,height,camera) {

        var vector = position.project(camera);

        vector.x = (vector.x +1)* width;
        vector.y = (1-vector.y) * height;

        return vector;
    }

    function getCrosses(clientX,clientY,object,name,positionArray){

        var point = new THREE.Vector3();

        if(name == 'ring'){

            if(ringCrosses(clientX, clientY,object,point)){positionArray[0] = point.clone();}
        }else if(name == 'rect'){

            if(rectCrosses(clientX, clientY,object,point)){positionArray[0] = point.clone();}
        }
    }
    function ringCrosses(tx,ty,object,intersection){

        var rect = container.dom.getBoundingClientRect();

        var width = container.dom.offsetWidth / 2;
        var height = container.dom.offsetHeight / 2;

        //圆点==线段起点
        var vvec = get2DCoords(object.position.clone(),width, height,editor.camera);
        var p0 = new THREE.Vector2(vvec.x,vvec.y);
        //线段终点
        var p1 = new THREE.Vector2(tx- rect.left, ty- rect.top);

        for(var i=0; i <object.geometry.vertices.length-1;i++ ){

            var point = object.geometry.vertices[i].clone();
            point.applyMatrix4(object.matrixWorld);
            var vec = get2DCoords(point,width, height,editor.camera);
            var p2 = new THREE.Vector2(vec.x,vec.y);

            point = object.geometry.vertices[i+1].clone();
            point.applyMatrix4(object.matrixWorld);
            vec = get2DCoords(point,width, height,editor.camera);
            var p3 = new THREE.Vector2(vec.x,vec.y);

            var points = new THREE.Vector2();
            if(reCrosses( p0, p1, p2,p3,points)){

                points.x +=rect.left; points.y += rect.top;
                return getPoint(points,object.userData.normal.clone(),object.position,intersection);
            }
        }

        return false;
    }
    function rectCrosses(tx,ty,object,intersection){

        /*
        0-------3
        \       \
        \       \
        1-------2
         */

        var rect = container.dom.getBoundingClientRect();

        var position = object.geometry.getAttribute( 'position' );
        var posArray = position.array;

        var width = container.dom.offsetWidth / 2;
        var height = container.dom.offsetHeight / 2;

        var point = (new THREE.Vector3(posArray[0],posArray[1],posArray[2])).applyMatrix4(object.matrixWorld);
        var vec = get2DCoords(point,width, height,editor.camera);
        var point0 = new THREE.Vector2(vec.x,vec.y);

        point = (new THREE.Vector3(posArray[3],posArray[4],posArray[5])).applyMatrix4(object.matrixWorld);
        vec = get2DCoords(point,width, height,editor.camera);
        var point1 = new THREE.Vector2(vec.x,vec.y);

        point = (new THREE.Vector3(posArray[6],posArray[7],posArray[8])).applyMatrix4(object.matrixWorld);
        vec = get2DCoords(point,width, height,editor.camera);
        var point2 = new THREE.Vector2(vec.x,vec.y);

        point = (new THREE.Vector3(posArray[9],posArray[10],posArray[11])).applyMatrix4(object.matrixWorld);
        vec = get2DCoords(point,width, height,editor.camera);
        var point3 = new THREE.Vector2(vec.x,vec.y);

        vec = get2DCoords(object.position.clone(),width, height,editor.camera);
        var p0 = new THREE.Vector2(tx- rect.left, ty- rect.top);
        var p1 = new THREE.Vector2(vec.x,vec.y);

        var points = new THREE.Vector2();
        //最左边边
        if(reCrosses(p0,p1,point0,point1,points)){

            points.x +=rect.left; points.y +=rect.top;
            return getPoint(points,object.userData.normal.clone(),object.position,intersection);
        }else if(reCrosses(p0,p1,point3,point2,points)){//最右边边

            points.x +=rect.left; points.y +=rect.top;
            return getPoint(points,object.userData.normal.clone(),object.position,intersection);
        }else if(reCrosses(p0,p1,point0,point3,points)){//最上边边

            points.x +=rect.left; points.y +=rect.top;
            return getPoint(points,object.userData.normal.clone(),object.position,intersection);
        }else if(reCrosses(p0,p1,point1,point2,points)){//最下边边

            points.x +=rect.left; points.y +=rect.top;
            return getPoint(points,object.userData.normal.clone(),object.position,intersection);
        }

        return false;
    }

    function getPoint(points,normal,position,intersection){

        var array = THREE_getMousePosition(container.dom, points.x, points.y);
        point =new THREE.Vector2(array[0], array[1]);

        THREE_Plane.setFromNormalAndCoplanarPoint(normal,position);
        raycaster.setFromCamera(point, editor.camera);
        raycaster.ray.intersectPlane( THREE_Plane, intersection );

        return true;
    }
    function reCrosses(p0,p1,p2,p3,IntersectionPts){

        var bOnThis = false;
        var bOnOther = false;

        var pp1 = p0;
        var pp2 = p1;
        //var pp2 = new THREE.Vector2(p0.x + p1.x, p0.y + p1.y);

        var pp3 = p2;
        var pp4 = p3;
        //var pp4 = new THREE.Vector2(p2.x + p3.x, p2.y + p3.y);

        var Ua = (pp4.x - pp3.x)*(pp1.y - pp3.y) - (pp4.y - pp3.y) * (pp1.x - pp3.x);
        var Ub = (pp2.x - pp1.x)*(pp1.y - pp3.y) - (pp2.y - pp1.y) * (pp1.x - pp3.x);

        var dDenominator = (pp4.y - pp3.y)*(pp2.x - pp1.x) - (pp4.x - pp3.x) * (pp2.y - pp1.y);

        if (dDenominator == 0)
            return false;

        Ua = Ua / dDenominator;
        Ub = Ub / dDenominator;

        bOnThis = (Ua >= 0 && Ua < 1);		// For ints we need the line to be the point set [a,b);
        bOnOther = (Ub >= 0 && Ub < 1);		// For ints we need the line to be the point set [a,b);
        var bResult  = bOnThis && bOnOther;

        if (bResult){

            IntersectionPts.set(pp1.x + Ua*(pp2.x - pp1.x) , pp1.y + Ua*(pp2.y - pp1.y));
        }

        return (bResult);
    }

    //event
    function onPointerDown(event){

        if(!THREE_LabelEnable || event.button !== 0 )return;

        event.preventDefault();

        scope.selectedLabel();//还原颜色

        var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
        var onDownPosition = new THREE.Vector2( array[0], array[1]);

        if(editor.labelType == '文字标注'){
            THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );
            raycaster.setFromCamera( onDownPosition, editor.camera );
            var mouseDown=new THREE.Vector3();
            if(raycaster.ray.intersectPlane( THREE_Plane, mouseDown )){

                var text = scope.createTextLabel('文字标注',mouseDown,true);
                scope.updatePosition(text,container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,editor.camera);
            }

        }else if(editor.labelType == '文字标签' || editor.labelType == '图片标签'){

            var intersects = THREE_getIntersects(onDownPosition,editor.camera,editor.sceneGroup.children,true);
            if ( intersects.length > 0 ) {

                var text;
                if(editor.labelType == '文字标签')text= scope.createTextLabel('文字标签',intersects[0].point,false);
                else text= scope.createTextLabel('图片标签',intersects[0].point,false,undefined,true,THREE_Img,128,128);
                scope.updatePosition(text,container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,editor.camera);

            }

        }

    }

    //绘制2D数据
    editor.signals.drawImage.add( drawImage );
    function drawImage(context,height){

        for(var i =0;i<textlabels.length;i++){

            var div = textlabels[i];
            if(div.dom.style.display == 'none')continue;

            var offsetX = parseInt(((div.dom.style.left).split("px"))[0]);
            var offsetY = parseInt(((div.dom.style.top).split("px"))[0]);

            var element = div.dom.children[0];

            if(element.img === true){

                var imge = new Image();
                imge.src=element.backGround;
                context.drawImage(imge,offsetX,offsetY,element.width,element.height);

                context.strokeStyle=element.bColor;
                context.lineWidth='2px';/*边框的宽度*/
                context.strokeRect(offsetX,offsetY,element.offsetWidth,element.offsetHeight);
                context.strokeRect(offsetX,offsetY,element.offsetWidth,element.offsetHeight);
                context.strokeRect(offsetX,offsetY,element.offsetWidth,element.offsetHeight);

            }else if(!element.text){

                context.fillStyle='white';
                context.fillRect(offsetX,offsetY,element.offsetWidth-2,element.offsetHeight-2);

                context.strokeStyle=element.bColor;
                context.lineWidth='2px';/*边框的宽度*/
                context.strokeRect(offsetX,offsetY,element.offsetWidth-2,element.offsetHeight-2);
                context.strokeRect(offsetX,offsetY,element.offsetWidth-2,element.offsetHeight-2);
                context.strokeRect(offsetX,offsetY,element.offsetWidth-2,element.offsetHeight-2);

                context.font=element.style.font;
                context.textAlign="center";
                context.textBaseline="middle";
                context.fillStyle=element.tColor;
                context.fillText(element.innerHTML,offsetX+element.offsetWidth/2,offsetY+element.offsetHeight/2);

            }else{

                var imge = new Image();
                imge.src=element.backGround;
                context.drawImage(imge,offsetX,offsetY,element.offsetWidth,element.offsetHeight);

                context.font=element.style.font;
                context.fillStyle=element.tColor;
                context.fillText(element.innerHTML,offsetX+element.offsetWidth/2,offsetY+element.offsetHeight/2);

            }

        }
    }

};

THREE.RoundOrRectLabel = function(editor,container, controls, Tagging){

    var label = new UI.Div();
    label.setId( 'label' );
    label.setPosition( 'absolute' );

    var selected=undefined;

    var _size=new THREE.Vector2();
    var radius=1.0;
    var arcOrRect=false;//true为圆环，false为矩形
    var color = 'red';

    var onDownPosition = new THREE.Vector2();
    var onUpPosition = new THREE.Vector2();

    var startPosition = new THREE.Vector3();

    this.clearLabel = function(){

        while(editor.labelGroup.children.length>0){

            var object = editor.labelGroup.children.pop();
            object.parent = null;
            object.dispatchEvent( { type: 'removed' } );
        }

        selected=undefined;

        this.removeEvents();
    };

    this.addEvents = function(){

        deleteLabel();
        container.dom.addEventListener( "mousedown", onPointerDown, false );
    };
    this.removeEvents = function(){

        container.dom.removeEventListener( "mousemove", onPointerMove );
        container.dom.removeEventListener( "mouseup", onPointerUp );
        container.dom.removeEventListener( "mousedown", onPointerDown );
    };

    this.getSelected = function(){

        return selected;
    };

    this.updateCenterLabel = function(camera){

        if(selected !== undefined && label.position!==undefined){

            var coords2d = get2DCoords(selected.position.clone(),container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,camera);
            label.position = new THREE.Vector2(coords2d.x,coords2d.y);

            label.setLeft( (label.position.x-radius)+ "px");
            label.setTop( (label.position.y-radius) + "px");
        }
    };

    editor.signals.createRingLabel.add( inforToCreateRing);
    function inforToCreateRing(infor,position,label){

        var mesh = new THREE.Mesh(new THREE.RingGeometry( infor.innerRadius, infor.outerRadius, 30, 0, 0, Math.PI* 2),
            new THREE.MeshBasicMaterial({color:0xFF0000, side: THREE.DoubleSide, transparent: true, depthTest :false })
        );
        //
        var matrix = new THREE.Matrix4();
        if ( infor.matrix !== undefined )matrix.fromArray( infor.matrix );
        mesh.applyMatrix(matrix);
        mesh.position.copy(position);

        mesh.userData.normal = mesh.getWorldDirection();
        mesh.name = 'ring';

        label.object=mesh;mesh.tagg = label;

        editor.labelGroup.add( mesh );
        editor.signals.updateRender.dispatch() ;
    }

    editor.signals.createRectLabel.add( inforToCreateRect);
    function inforToCreateRect(infor,position,label){

        // var points =[];
        // for(var j=0;j<infor.points.length;j++){points.push(infor.points[j]);}
        // var geometry = new THREE.BufferGeometry();
        // geometry.addAttribute( 'position', new THREE.BufferAttribute(  new Float32Array( points ), 3)  );
        // geometry.setIndex( new THREE.BufferAttribute( infor.indext, 1) );

        var points =[];
        var indext =[];
        for(var j=0;;j++){//j<infor.points.length
            if(infor.points[j]===undefined)break;
            points.push(infor.points[j]);
        }
        for(var k=0;;k++){//j<infor.indext.length
            if(infor.indext[k]===undefined)break;
            indext.push(infor.indext[k]);
        }
        var geometry = new THREE.BufferGeometry();
        geometry.addAttribute( 'position', new THREE.BufferAttribute(  new Float32Array( points ), 3)  );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indext ), 1 ) );

        var mesh = new THREE.Mesh(geometry,new THREE.MeshBasicMaterial({color:0xFF0000, side: THREE.DoubleSide, depthTest :false }));
        var child = new THREE.Mesh(new THREE.PlaneGeometry(infor.width,infor.width,1,1),new THREE.MeshBasicMaterial({color:0xFFFF00, side: THREE.DoubleSide, depthTest :false }));

        for(var i=0;i<infor.positions.length;i++){

            child = child.clone();
            child.position.set(infor.positions[i].x,infor.positions[i].y,infor.positions[i].z);
            child.visible=true;child.name = i+1;mesh.add(child);
        }

        var matrix = new THREE.Matrix4();
        if ( infor.matrix !== undefined )matrix.fromArray( infor.matrix );
        mesh.applyMatrix(matrix);
        mesh.position.copy(position);
        mesh.name = 'rect';

        mesh.userData.normal = mesh.getWorldDirection();
        mesh.userData.size = new THREE.Vector2(infor.size.x,infor.size.y);

        label.object=mesh;mesh.tagg = label;

        editor.labelGroup.add( mesh );
        editor.signals.updateRender.dispatch();
    }

    var name=-1;
    this.pickLabel = function(point,event){

        if(editor.labelGroup.children.length>0){

            var intersects = THREE_getIntersects(point,editor.camera,editor.labelGroup.children);
            if ( intersects.length > 0 ) {

                var object = intersects[ 0 ].object;
                startPosition.copy(intersects[ 0].point);
                onDownPosition.copy(point);
                move.set(event.clientX,event.clientY);

                if(object.name == 'rect'){

                    var tintersects = THREE_getIntersects(point,editor.camera,object.children);
                    if ( tintersects.length > 0 ) {

                        name = tintersects[0].object.name;
                        object.userData.scaleEnable=true;
                    }else object.userData.scaleEnable=false;
                }

                if(selected!==object){

                    var select=false;
                    if(selected!==undefined){//还原上一选中物体

                        deleteCenterLabel();
                        select=true;
                    }

                    object.currentHex = object.material.color.getHex();
                    object.material.color.setHex(0xFFFF00);

                    if(object.name == 'ring')createArc(object.position);
                    if(object.name == 'rect'){

                        updateRect(object,true);
                    }

                    selected=object;

                    if(select === false) editor.select( null );
                    else editor.signals.updateRender.dispatch();//绘制
                }

                document.addEventListener( 'mouseup', pointUp, false );
                container.dom.addEventListener( 'mousemove', pointMove, false );

                return true;
            }
            if(selected!==undefined){

                deleteCenterLabel();
            }
            return false;
        }
        return false;
    };
    function pointMove(event){

        var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
        onUpPosition.fromArray( array );

        if (selected !== undefined) {

            if (selected.name === 'ring'){

                scaleRing();
            }else if (selected.name === 'rect') {

                if (selected.userData.scaleEnable === true) {//缩放

                    scaleRect(event);
                } else {//平移

                    moveRect();
                }
            }

            editor.signals.updateRender.dispatch();//绘制
        }
    }
    function pointUp(event){

        container.dom.removeEventListener( 'mousemove', pointMove );
        document.removeEventListener( 'mouseup', pointUp );
    }

    function scaleRing(){

        THREE_Plane.setFromNormalAndCoplanarPoint(selected.userData.normal.clone(), selected.position);
        raycaster.setFromCamera(onUpPosition, editor.camera);
        var pointMouse = new THREE.Vector3();
        raycaster.ray.intersectPlane(THREE_Plane, pointMouse);

        var scale = pointMouse.distanceTo(selected.position);

        var mesh = new THREE.Mesh(
            new THREE.RingGeometry( scale, scale+(0.1*(controls.getDistance())/20.0), 30, 0, 0, Math.PI* 2  ),
            new THREE.MeshBasicMaterial({color:0xFFFF00, side: THREE.DoubleSide, transparent: true, depthTest :false })
        );

        mesh.applyMatrix(selected.matrixWorld);

        mesh.currentHex = selected.currentHex;
        mesh.userData.normal = selected.userData.normal.clone();
        mesh.name = 'ring';
        mesh.tagg = selected.tagg;mesh.tagg.object=mesh;

        var indext = editor.labelGroup.children.indexOf(selected);
        editor.labelGroup.children[indext]=mesh;

        selected = mesh;

        //更新连线
        scaleLabel();
    }
    function scaleRect(event){

        THREE_Plane.setFromNormalAndCoplanarPoint(selected.userData.normal.clone(), selected.position);

        raycaster.setFromCamera(onUpPosition, editor.camera);
        var pointMouse = new THREE.Vector3();
        raycaster.ray.intersectPlane(THREE_Plane, pointMouse);

        raycaster.setFromCamera(onDownPosition, editor.camera);
        var startMouse = new THREE.Vector3();
        raycaster.ray.intersectPlane(THREE_Plane, startMouse);

        var ttx = (event.clientX>move.x);
        var fhX = (name<=1)?(ttx?-1.0:1.0):((ttx?1.0:-1.0));
        var tty = (event.clientY>move.y);
        var fhY = (name==0||name==2)?(tty?-1.0:1.0):((tty?1.0:-1.0));

        var point0 = new THREE.Vector2(onDownPosition.x,onUpPosition.y);
        raycaster.setFromCamera(point0, editor.camera);
        var firstMouse = new THREE.Vector3();
        raycaster.ray.intersectPlane(THREE_Plane, firstMouse);

        var point1 = new THREE.Vector2(onUpPosition.x,onDownPosition.y);
        raycaster.setFromCamera(point1, editor.camera);
        var secondMouse = new THREE.Vector3();
        raycaster.ray.intersectPlane(THREE_Plane, secondMouse);

        var height = (firstMouse.distanceTo(startMouse))*2;
        var width = (secondMouse.distanceTo(startMouse))*2;

        var scaleX = selected.userData.size.x+width*fhX;
        selected.userData.size.x = scaleX;
        scaleX /=2;

        var scaleY = selected.userData.size.y+height*fhY;
        selected.userData.size.y = scaleY;
        scaleY /=2;

        var twidth=0.1*(controls.getDistance())/20.0;

        var positions = selected.geometry.getAttribute( 'position' );
        var posArray = positions.array;
        posArray[0]=posArray[3]=-scaleX;
        posArray[1]=posArray[10]=scaleY;
        posArray[4]=posArray[7]=-scaleY;
        posArray[6]=posArray[9]=scaleX;

        posArray[12]=posArray[15]=-scaleX+twidth;
        posArray[13]=posArray[22]=scaleY-twidth;
        posArray[16]=posArray[19]=-scaleY+twidth;
        posArray[18]=posArray[21]=scaleX-twidth;

        //四个边角的更新
        selected.children[0].position.set(-scaleX+twidth/2,scaleY-twidth/2,0);
        selected.children[1].position.set(-scaleX+twidth/2,-scaleY+twidth/2,0);
        selected.children[2].position.set(scaleX-twidth/2,scaleY-twidth/2,0);
        selected.children[3].position.set(scaleX-twidth/2,-scaleY+twidth/2,0);

        positions.needsUpdate = true;

        selected.geometry.computeBoundingBox();
        selected.geometry.computeBoundingSphere();

        //更新连线
        scaleLabel();

        onDownPosition.copy(onUpPosition);
        move.set(event.clientX,event.clientY);
    }
    function moveRect(){

        THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection(THREE_Plane.normal), controls.center);
        raycaster.setFromCamera(onUpPosition, editor.camera);
        var pointMouse = new THREE.Vector3();
        raycaster.ray.intersectPlane(THREE_Plane, pointMouse);

        var distect = (pointMouse.clone()).sub(startPosition);
        selected.position.add(distect);
        updateLabel(distect);

        startPosition.copy(pointMouse);
    }
    //更新备注标签---连线随着object缩放而缩放
    editor.signals.updateObjectToLine.add( scaleLabel);
    function scaleLabel(){

        if(selected.tagg.dom.children[0].child.visible === false )return;

        selected.updateMatrixWorld();
        //更新连线============================================
        var lposition = selected.tagg.dom.children[0].child.geometry.vertices;

        var coords2d = get2DCoords(selected.tagg.position.clone(),
            container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,editor.camera);
        var rect = container.dom.getBoundingClientRect();
        coords2d.x +=rect.left;
        coords2d.y +=rect.top;

        editor.signals.updateLabelToLine.dispatch(coords2d.x,coords2d.y,selected.tagg.object,selected.name,lposition);

        selected.tagg.dom.children[0].child.geometry.verticesNeedUpdate = true;
    }
    //更新备注标签的位置--随着object移动而移动
    function updateLabel(distect){

        var lposition = selected.tagg.dom.children[0].child.geometry.vertices;
        lposition[0].add(distect);lposition[1].add(distect);
        selected.tagg.dom.children[0].child.geometry.verticesNeedUpdate = true;

        selected.tagg.position.add(distect);
    }
    //更新矩形的四个角--是否显示
    function updateRect(object,value){

        for(var i in object.children){

            object.children[i].visible = value;
        }
    }

    //创建圆环的中心点--2标签
    function createArc(point){

        arcOrRect=true;
        label.setBackground('red');
        radius = 2.0;

        var coords2d = get2DCoords(point.clone(),container.dom.offsetWidth / 2, container.dom.offsetHeight / 2,editor.camera);
        label.position = new THREE.Vector2(coords2d.x,coords2d.y);

        label.dom.addEventListener('mousedown', mousedown, false);

        updateDraw();
        container.add(label);
    }
    //获取2D坐标--3D转2D
    function get2DCoords(position,width,height,camera) {

        var vector = position.project(camera);//editor.camera

        vector.x = (vector.x +1)* width;
        vector.y = (1-vector.y) * height;

        return vector;
    }
    //设置矩形位置以及大小数据--创建时调用--2D标签时
    function setPosition(point,dis){

        label.position=point;
        _size.set(Math.abs(dis.x),Math.abs(dis.y));

    }

    function deleteLabel(){

        if(selected!==undefined){

            selected.material.color.setHex( selected.currentHex );
            if(selected.name == 'rect')updateRect(selected,false);
            editor.signals.updateRender.dispatch();
        }
        selected = undefined;

        if(label.position!==undefined)container.remove(label);

        label.dom.removeEventListener('mousedown', mousedown);

        delete label.position;
        label.setBackground('');label.setBorder('');label.setBorderRadius('');

        _size.set(0,0);
        color = 'red';
        radius=1.0;
        arcOrRect=false;//true为圆环，false为矩形
    }
    //删除圆环的中心点标签
    function deleteCenterLabel(){

        selected.material.color.setHex( selected.currentHex );

        if(selected.name == 'rect')updateRect(selected,false);
        selected = undefined;

        if(label.position!==undefined){

            container.remove(label);

            label.dom.removeEventListener('mousedown', mousedown);

            delete label.position;
            label.setBackground('');
            label.setBorder('');
            label.setBorderRadius('');

            radius=1.0;
            arcOrRect=false;//true为圆环，false为矩形
        }
    }

    function updateDraw (){

        label.setBorder('1px solid '+color);

        if(arcOrRect){//圆

            label.setBorderRadius(radius+'px');

            label.setLeft( (label.position.x-radius)+ "px");
            label.setTop( (label.position.y-radius) + "px");

            label.setWidth(2*radius+"px");
            label.setHeight(2*radius+"px");
        }
        else {//矩形

            label.setLeft( label.position.x + "px");
            label.setTop( label.position.y + "px");

            label.setWidth(_size.x+"px");
            label.setHeight(_size.y+"px");
        }

    }

    function createRing(){

        if ( onDownPosition.distanceTo( onUpPosition ) === 0) return;

        THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );

        raycaster.setFromCamera( onUpPosition, editor.camera );
        var endMouse=new THREE.Vector3();
        raycaster.ray.intersectPlane( THREE_Plane, endMouse );

        raycaster.setFromCamera( onDownPosition, editor.camera );
        var startMouse=new THREE.Vector3();
        raycaster.ray.intersectPlane( THREE_Plane, startMouse );

        var tradius = endMouse.distanceTo(startMouse);

        var geometry = new THREE.RingGeometry( tradius, tradius+(0.1*(controls.getDistance())/20.0), 30, 0, 0, Math.PI* 2  );

        var mesh = new THREE.Mesh(geometry,
            new THREE.MeshBasicMaterial({color:0xFF0000, side: THREE.DoubleSide, transparent: true, depthTest :false })
        );
        //
        mesh.applyMatrix(editor.camera.matrixWorld);
        mesh.position.copy(startMouse);

        mesh.userData.normal = mesh.getWorldDirection();
        mesh.name = 'ring';
//创建备注标签
        var tagg = Tagging.createTextLabel("备注", startMouse,false,'备注');
        tagg.setDisplay('none');
        tagg.dom.children[0].child.visible=false;
        tagg.object=mesh;
        mesh.tagg = tagg;

        editor.labelGroup.add( mesh );
        editor.signals.updateRender.dispatch() ;

    }
    function createRect(){

        if ( onDownPosition.distanceTo( onUpPosition ) === 0) return;

        THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );

        var rect = container.dom.getBoundingClientRect();
        var rectPoint = new THREE.Vector2();

        //第一个点
        rectPoint.x = (label.position.x / rect.width)*2 -1;
        rectPoint.y = -(label.position.y / rect.height)*2 +1;
        raycaster.setFromCamera( rectPoint, editor.camera );
        var firstMouse=new THREE.Vector3();
        raycaster.ray.intersectPlane( THREE_Plane, firstMouse );

        //第二个点
        rectPoint.x = (label.position.x / rect.width)*2 -1;
        rectPoint.y = -((label.position.y+_size.y) / rect.height)*2 +1;
        raycaster.setFromCamera( rectPoint, editor.camera );
        var secondMouse=new THREE.Vector3();
        raycaster.ray.intersectPlane( THREE_Plane, secondMouse );

        //第三个点
        rectPoint.x = ((label.position.x+_size.x/2) / rect.width)*2 -1;
        rectPoint.y = -((label.position.y+_size.y/2) / rect.height)*2 +1;
        raycaster.setFromCamera( rectPoint, editor.camera );
        var thirdMouse=new THREE.Vector3();
        raycaster.ray.intersectPlane( THREE_Plane, thirdMouse );

        //第四个点
        rectPoint.x = ((label.position.x+_size.x) / rect.width)*2 -1;
        rectPoint.y = -(label.position.y / rect.height)*2 +1;
        raycaster.setFromCamera( rectPoint, editor.camera );
        var fourthMouse=new THREE.Vector3();
        raycaster.ray.intersectPlane( THREE_Plane, fourthMouse );

        var width = (firstMouse.distanceTo(fourthMouse))/2.0;
        var height = (firstMouse.distanceTo(secondMouse))/2.0;

        var twidth=0.1*(controls.getDistance())/20.0;

        var width0 = width + twidth;
        var height0 = height + twidth;

        var points = [
            -width0,height0,0, -width0,-height0,0, width0,-height0,0, width0,height0,0,
            -width,height,0, -width,-height,0, width,-height,0, width,height,0
        ];
        var indext =[0,1,4,4,1,5,  1,2,5,5,2,6, 7,6,3,3,6,2,  0,4,7,0,7,3];

        var geometry = new THREE.BufferGeometry();
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( points ), 3 ) );
        geometry.setIndex( new THREE.BufferAttribute( new Uint16Array( indext ), 1 ) );

        var mesh = new THREE.Mesh(
            geometry,
            new THREE.MeshBasicMaterial({color:0xFF0000, side: THREE.DoubleSide, depthTest :false })
        );

        var ww =twidth;
        var hh =twidth;
        // geometry = new THREE.PlaneGeometry(ww,hh,1,1);
        var child = new THREE.Mesh(
            new THREE.PlaneGeometry(ww,hh,1,1),
            new THREE.MeshBasicMaterial({color:0xFFFF00, side: THREE.DoubleSide, depthTest :false })//, transparent: true
        );
        child.position.set(-width-twidth/2,height+twidth/2,0);
        child.visible=false;
        child.name = 0;
        mesh.add(child);

        child = child.clone();
        child.position.set(-width-twidth/2,-height-twidth/2,0);
        child.visible=false;
        child.name = 1;
        mesh.add(child);

        child = child.clone();
        child.position.set(width+twidth/2,height+twidth/2,0);
        child.visible=false;
        child.name = 2;
        mesh.add(child);

        child = child.clone();
        child.position.set(width+twidth/2,-height-twidth/2,0);
        child.visible=false;
        child.name = 3;
        mesh.add(child);

        mesh.applyMatrix(editor.camera.matrix);
        mesh.position.copy(thirdMouse);
        mesh.name = 'rect';

        mesh.userData.normal = mesh.getWorldDirection();
        mesh.userData.size = new THREE.Vector2((width+twidth)*2,(height+twidth)*2);

//创建备注标签
        var tagg = Tagging.createTextLabel("备注", thirdMouse,false,'备注');
        tagg.setDisplay('none');
        tagg.dom.children[0].child.visible=false;
        tagg.object=mesh;
        mesh.tagg = tagg;

        editor.labelGroup.add( mesh );
        editor.signals.updateRender.dispatch();
    }

    editor.signals.updateLabelObject.add(labelObjectToJson);
    function labelObjectToJson(value){

        if( selected === undefined ) return;

        if(value === true){

            selected.currentHex = selected.material.color.getHex();
            selected.material.color.setHex(0xFFFF00);

        }else {

            selected.material.color.setHex( selected.currentHex );

        }
        updateRect(selected,value);
    }

    //event
    var move=new THREE.Vector2();
//标签移动
    function mousedown(event){

        editor.signals.setViewEvent.dispatch(false);
        document.addEventListener( 'mousemove', mousemove, false );
        document.addEventListener('mouseup', mouseup, false);
    }
    function mousemove(event){

        var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
        onUpPosition.fromArray( array );

        THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );
        raycaster.setFromCamera( onUpPosition, editor.camera );
        var intersection = new THREE.Vector3();
        if ( raycaster.ray.intersectPlane( THREE_Plane, intersection ) ) {

            updateLabel((intersection.clone()).sub(selected.position));
            selected.position.copy(intersection);
            editor.signals.updateRender.dispatch();
        }
    }
    function mouseup(event){

        document.removeEventListener( 'mousemove', mousemove );
        document.removeEventListener('mouseup', mouseup);
        editor.signals.setViewEvent.dispatch(true);
    }
//创建过程
    function onPointerDown(event){

        if( !THREE_LabelEnable || event.button !== 0 )return;

        event.preventDefault();

        move.set(event.clientX, event.clientY);

        var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
        onDownPosition.fromArray( array );

        var rect = container.dom.getBoundingClientRect();
        var onDown = new THREE.Vector2();
        onDown.x=move.x-rect.left;onDown.y= move.y- rect.top;

        arcOrRect= (editor.labelType == '圆形标注');
        label.position=onDown;
        updateDraw();

        container.add(label);

        container.dom.addEventListener( "mousemove", onPointerMove, false );
        container.dom.addEventListener( "mouseup", onPointerUp, false );
    }
    function onPointerMove(event){

        radius=move.distanceTo(new THREE.Vector2(event.clientX,event.clientY));
        if(!arcOrRect){//矩形

            var rect = container.dom.getBoundingClientRect();
            var onDown = new THREE.Vector2();
            onDown.x= Math.min(event.clientX, move.x)-rect.left;
            onDown.y= Math.min(event.clientY, move.y)- rect.top;

            setPosition(onDown,new THREE.Vector2(move.x-event.clientX,move.y-event.clientY));
        }
        updateDraw();
    }
    function onPointerUp(event){

        var array = THREE_getMousePosition( container.dom, event.clientX, event.clientY );
        onUpPosition.fromArray( array );

        if(arcOrRect)createRing();
        else createRect();

        deleteLabel();

        container.dom.removeEventListener( "mousemove", onPointerMove );
        container.dom.removeEventListener( "mouseup", onPointerUp );
    }

};
