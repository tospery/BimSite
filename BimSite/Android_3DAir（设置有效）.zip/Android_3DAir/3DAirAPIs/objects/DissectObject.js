/**
 * Created by Administrator on 2016/11/25.
 */
THREE.DissectObject = function(editor,container,dissectPlanes,color,indext,controls){

    //剖视平面
    this.dissect=undefined;
    this.dissectPlane=undefined;

    var enableCreate = false;

    var control=new THREE.TransformDissectControls( editor.camera, container.dom);
    control.addEventListener( 'change', function () {

        editor.signals.updateRender.dispatch() ;
    } );

    var scope = this;
    //创建物体
    this.createDissect = function(sceneBox ){

        var center=sceneBox.center();

        var distance=sceneBox.max.sub(sceneBox.min);
        var width=(indext==='XY')?Math.abs(distance.x):((indext==='XZ')?Math.abs(distance.x):Math.abs(distance.z));
        var height=(indext==='XY')?Math.abs(distance.y):((indext==='XZ')?Math.abs(distance.z):Math.abs(distance.y));
//操作物体
        var planeGeometry =new THREE.PlaneGeometry( width+4, height+4, 1, 1 );
        if(indext==='XZ')planeGeometry.rotateX(-Math.PI / 2);
        else if(indext==='YZ')planeGeometry.rotateY(-Math.PI / 2);

        var material=new THREE.MeshBasicMaterial( {
            color:color,side:THREE.DoubleSide,opacity:0.3,transparent:true} );
        scope.dissect = new THREE.Mesh( planeGeometry, material );
        scope.dissect.position.copy(center);
        if(indext==='XZ')scope.dissect.position.x +=1.0;
        else if(indext==='YZ')scope.dissect.position.z +=1.0;

        editor.sceneHelpers.add(scope.dissect);
//剖视物体
        var position = (indext==='XY')?new THREE.Vector3(0,0,-1):((indext==='XZ')?new THREE.Vector3(0,-1,0):new THREE.Vector3(-1,0,0));
        var dis = (indext==='XY')?center.z:((indext==='XZ')?center.y:center.x);
        scope.dissectPlane = new THREE.Plane( position, dis );

        dissectPlanes.push(scope.dissectPlane);
//控制器--轴物体
        control.attach( scope.dissect ,scope.dissectPlane, position.clone() );
        control.setAxis((indext==='XY')?'Z':((indext==='XZ')?'Y':'X'));
        editor.sceneHelpers.add( control );

        enableCreate = true;
    };
    //创建XYZ物体
    function createXYZDissect(point0,point1){

        var center = new THREE.Vector3((point0.x+point1.x)/2.0,(point0.y+point1.y)/2.0,(point0.z+point1.z)/2.0);
        var distance=sceneBox.max.sub(sceneBox.min);
        var width=Math.abs(distance.x);
        var height=Math.abs(distance.y);
//操作物体
        var v1 = new THREE.Vector3();var v2 = new THREE.Vector3();
        var normal = v1.subVectors( editor.camera.position, point1 ).cross( v2.subVectors( center, point1 ) ).normalize();

        var planeGeometry =new THREE.PlaneGeometry( width+4, height+4, 1, 1 );
        var material=new THREE.MeshBasicMaterial( {color:color,side:THREE.DoubleSide,opacity:0.3,transparent:true} );
        scope.dissect = new THREE.Mesh( planeGeometry, material );

        scope.dissect.position.copy(center);
        var tnormal = (center.clone()).add(normal.clone().multiplyScalar(-1));
        scope.dissect.lookAt(tnormal);
        scope.dissect.updateMatrixWorld();

        editor.sceneHelpers.add(scope.dissect);
//剖视物体
        scope.dissectPlane = new THREE.Plane();
        scope.dissectPlane.setFromNormalAndCoplanarPoint(normal,center);
        dissectPlanes.push(scope.dissectPlane);
//控制器--轴物体
        control.attach( scope.dissect ,scope.dissectPlane ,new THREE.Vector3(0,0,-1) );
        control.setAxis('Z');
        editor.sceneHelpers.add( control );

        enableCreate = true;
    }
    //创建法线物体
    function createNormalDissect(object,face,point ){

        var distance=sceneBox.max.sub(sceneBox.min);
        var width=Math.abs(distance.x);
        var height=Math.abs(distance.y);
//剖视物体
        scope.dissectPlane = new THREE.Plane();

        var nor = face.normal.clone();
        nor.applyMatrix4(object.matrixWorld);

        scope.dissectPlane.setFromNormalAndCoplanarPoint(nor.multiplyScalar(-1),point );
        dissectPlanes.push(scope.dissectPlane);
//操作物体
        var planeGeometry =new THREE.PlaneGeometry( width+4, height+4, 1, 1 );

        var material=new THREE.MeshBasicMaterial( {color:color,side:THREE.DoubleSide,opacity:0.3,transparent:true} );
        scope.dissect = new THREE.Mesh( planeGeometry, material );

        var normal = (point.clone()).add(scope.dissectPlane.normal.clone().multiplyScalar(-1));
        scope.dissect.position.copy(point);
        scope.dissect.lookAt(normal);

        editor.sceneHelpers.add(scope.dissect);
//控制器--轴物体
        control.attach( scope.dissect, scope.dissectPlane, new THREE.Vector3(0,0,-1) );
        control.setAxis('Z');
        editor.sceneHelpers.add( control );

        enableCreate = true;
    }

    //删除物体
    this.removeDissect = function(){

        if(!enableCreate)return;

        if(scope.dissectPlane!==undefined){

            dissectPlanes.splice(dissectPlanes.indexOf(scope.dissectPlane),1);

            editor.sceneHelpers.remove(scope.dissect);
            editor.sceneHelpers.remove( control );

            scope.dissect.geometry.dispose();scope.dissect.material.dispose();
            control.detach();

            scope.dissectPlane=undefined;
            scope.dissect=undefined;
        }

        enableCreate = false;

        deleteLine();
    };
    //
    this.getEnable = function(){

        return enableCreate;
    };
    //
    this.addEvents = function(object,box){

        editor.signals.setViewEvent.dispatch(false);

        sceneBox = box;
        objects = object;
        enableCreate=true;
        container.dom.addEventListener( "mousedown", mousedown, false );
        container.dom.addEventListener( "touchstart", mousedown, false );
    };
    //以包围盒是否为undefined来判断是否进行剖切面的自选择创建操作
    this.getBoxEmpty = function(){

        return (sceneBox !== undefined);
    };
    this.restDissect =function(){

        enableCreate = false;
        if(line !== undefined){

            editor.sceneHelpers.remove(line);
            line = undefined;
        }
        objects = undefined;
        sceneBox = undefined;

        THREE_DissectEnabled=false;

        container.dom.removeEventListener( "mousedown", mousedown );
        container.dom.removeEventListener( 'mousemove', mousemove );

        container.dom.removeEventListener( "touchstart", mousedown );
        container.dom.removeEventListener( 'touchmove', mousemove );
        container.dom.removeEventListener( 'touchend', touchUp );
    };

    var startPoint = new THREE.Vector3();
    var endPoint = new THREE.Vector3();

    var line = undefined;
    var objects = undefined;
    var sceneBox = undefined;
    function createLine(point){

        var geometry = new THREE.BufferGeometry();
        var positions = [point.x,point.y,point.z,point.x,point.y,point.z];//顶点数据
        geometry.addAttribute( 'position', new THREE.BufferAttribute( new Float32Array( positions ), 3 ) );
        var material = new THREE.LineBasicMaterial( {color: 0xFF4500, depthTest :false } );

        line =  new THREE.Line(geometry,material);

        editor.sceneHelpers.add(line);
    }
    function deleteLine(){

        if(line !== undefined){

            editor.sceneHelpers.remove(line);
            line = undefined;
        }
        objects = undefined;
        sceneBox = undefined;

        editor.signals.setViewEvent.dispatch(true);

        THREE_DissectEnabled=false;

        container.dom.removeEventListener( "mousedown", mousedown );
        container.dom.removeEventListener( 'mousemove', mousemove );

        container.dom.removeEventListener( "touchstart", mousedown );
        container.dom.removeEventListener( 'touchmove', mousemove );
        container.dom.removeEventListener( 'touchend', touchUp );
    }

    function mousedown(event){

        if( event.button === 0 || event.button===undefined ){

            event.preventDefault();

            var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
            var array = THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY );
            var mousePoint =new THREE.Vector2( array[0], array[1]);

            if(indext==="normal"){

                var intersects = THREE_getIntersects(mousePoint, editor.camera, objects);
                if (intersects.length > 0) {

                    createNormalDissect(intersects[0].object,intersects[0].face,intersects[0].point);
                    deleteLine();
                    editor.signals.updateRender.dispatch();
                }
            }if(indext==="XYZ"){

                THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );
                raycaster.setFromCamera( mousePoint, editor.camera );
                if(raycaster.ray.intersectPlane( THREE_Plane, endPoint )){

                    if(line!==undefined){

                        createXYZDissect(startPoint,endPoint);
                        deleteLine();
                        editor.signals.updateRender.dispatch();
                        return;
                    }

                    createLine(endPoint);
                    editor.signals.updateRender.dispatch();
                    startPoint.copy(endPoint);

                    THREE_DissectEnabled=true;
                    container.dom.addEventListener( "mousemove", mousemove, false );

                    container.dom.addEventListener( "touchmove", mousemove, false );
                    container.dom.addEventListener( "touchend", touchUp, false );
                }
            }

        }
        else{

            if(line !== undefined){

                editor.sceneHelpers.remove(line);
                line = undefined;
            }
            THREE_DissectEnabled=false;
            container.dom.removeEventListener( 'mousemove', mousemove );
            container.dom.removeEventListener( 'touchmove', mousemove );
            container.dom.removeEventListener( 'touchend', touchUp );
        }

    }
    function mousemove(event){

        event.preventDefault();

        var pointer = event.changedTouches ? event.changedTouches[ 0 ] : event;
        var array = THREE_getMousePosition( container.dom, pointer.clientX, pointer.clientY );
        var mousePoint =new THREE.Vector2( array[0], array[1]);

        raycaster.setFromCamera( mousePoint, editor.camera );
        var movePoint = new THREE.Vector3();
        if(raycaster.ray.intersectPlane( THREE_Plane, movePoint )){

            var lposition = line.geometry.getAttribute( 'position' );
            var positionArray = lposition.array;
            positionArray[3]=movePoint.x;positionArray[4]=movePoint.y;positionArray[5]=movePoint.z;
            lposition.needsUpdate = true;

            editor.signals.updateRender.dispatch();
        }

    }

    function touchUp(event){

        var array = THREE_getMousePosition( container.dom, event.changedTouches[ 0 ].clientX, event.changedTouches[ 0 ].clientY );
        var mousePoint =new THREE.Vector2( array[0], array[1]);

        THREE_Plane.setFromNormalAndCoplanarPoint(editor.camera.getWorldDirection( THREE_Plane.normal ),controls.center );
        raycaster.setFromCamera( mousePoint, editor.camera );
        if(raycaster.ray.intersectPlane( THREE_Plane, endPoint )) {

            if (line !== undefined) {

                createXYZDissect(startPoint, endPoint);
                deleteLine();
                editor.signals.updateRender.dispatch();
            }

        }

    }

};