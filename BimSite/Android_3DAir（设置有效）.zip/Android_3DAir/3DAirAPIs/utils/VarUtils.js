/**
 * Created by Administrator on 2016/11/1.
 */
//返回值
var THREE_RETURN = -1;
//
var divEnabled=false;
//控制剖视操作---被DissectControls和Viewport调用
var THREE_DissectEnabled=false;
//图片标签对象
var THREE_Img=undefined;
//允许创建标签
var THREE_LabelEnable = true;

//测量选中对象
var THREE_SelectedMeasure = null;

var THREE_offset=100;
//视图数组
var THREE_ViewPoint = [];
//旋转速度
var THREE_rotateSpeedX = 180.0/320.0;
var THREE_rotateSpeedY = 180.0/320.0;
//键盘按下标志
var THREE_KEY = false;
//路径
var THREE_PATH ="";

//拾取平面
var THREE_Plane = new THREE.Plane();

var pointCenter=new THREE.Points(
    (function(){
        var geometry = new THREE.Geometry();
        geometry.vertices.push( new THREE.Vector3(0,0,0) );
        return geometry;
    })(),
    new THREE.PointsMaterial( { size: 4, sizeAttenuation: false,color: 0xFF4500, depthTest :false } ) );
pointCenter.visible=false;

function THREE_getMousePosition( dom, x, y) {

    var rect = dom.getBoundingClientRect();
    var tx=( x - rect.left ) / rect.width;
    var ty=( y - rect.top ) / rect.height;

    return [ ( tx * 2 ) - 1, - (ty * 2 ) + 1 ];
}

var raycaster = new THREE.Raycaster();
function THREE_getIntersects( point, camera,objects , recursive) {

    raycaster.setFromCamera( point, camera );

    return raycaster.intersectObjects( objects,recursive);

}
function THREE_getIntersect( object , recursive) {

    // raycaster.setFromCamera( point, camera );

    return raycaster.intersectObject( object,recursive);

}