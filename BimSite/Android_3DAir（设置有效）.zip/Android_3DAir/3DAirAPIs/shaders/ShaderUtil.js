/**
 * Created by Administrator on 2017/1/11.
 */
//平面着色器
THREE.ShaderLib[ 'InstancedPlane' ] = {

    uniforms: {
        // texture:{value: null }
    },

    vertexShader: [

        "attribute vec3 mcol0;",
        "attribute vec3 mcol1;",
        "attribute vec3 mcol2;",
        "attribute vec3 translate;",
        "attribute vec3 color;",

        "varying vec3 tColor;",
        "varying vec3 vPosition;",
        "varying float dis;",

        "void main() {",

        "tColor=color;",
        "vPosition = position;",

        "mat4 matrix = mat4(",
        "vec4( mcol0, 0 ),",
        "vec4( mcol1, 0 ),",
        "vec4( mcol2, 0 ),",
        "vec4( translate, 1 )",
        ");",

        "vec4 mvPosition = projectionMatrix * ( modelViewMatrix * matrix * vec4( position, 1.0 ) );",

        "dis = 0.005 * mvPosition.w;",

        "gl_Position = mvPosition;",
        "}"

    ].join( "\n" ),

    fragmentShader: [

        "precision highp float; ",

        "varying vec3 tColor;",
        "varying vec3 vPosition;",
        "varying float dis;",

        "void main() ",
        "{",

        "float size = 0.5;",
        // "float dis = 0.05;",
        "gl_FragColor = vec4( tColor, 1.0 );",

        "float valx = size-abs(vPosition.x);",
        "float valy = size-abs(vPosition.y);",
        "gl_FragColor.a = ((valx>dis)?0.1:(1.0-valx/dis)) + ((valy>dis)?0.1:(1.0-valy/dis));",

        "}"
    ].join( "\n" )

};

//连线着色器
THREE.ShaderLib[ 'lineShader' ] = {

    uniforms: {
        dashSize:{value: 1.0 },
        totalSize:{value: 2.0}
    },

    vertexShader: [

        "attribute float lineDistance;",
        "attribute vec3 color;",

        "varying float vLineDistance;",
        "varying vec3 vPosition;",
        "varying vec3 vColor;",

        "void main() {",

        "vLineDistance=lineDistance;",
        "vPosition=position;",
        "vColor = color;",

        "vec4 mvPosition =  modelViewMatrix * vec4( position, 1.0 );",
        "gl_Position = projectionMatrix * mvPosition;",

        "}"

    ].join( "\n" ),

    fragmentShader: [

        "precision highp float; ",
        "uniform float dashSize;",
        "uniform float totalSize;",

        "varying float vLineDistance;",
        "varying vec3 vPosition;",
        "varying vec3 vColor;",

        "void main() {",

        "bool vis = (mod(vLineDistance,totalSize)>dashSize);",
        "if(vis){",
        "discard;",
        "}else{",
        "gl_FragColor =vec4(vColor,1.0);",
        "}",
        "}"

    ].join( "\n" )

};

//点着色器
THREE.ShaderLib[ 'pointShader' ] = {

    uniforms: {
        // texture:{value: null }
    },

    vertexShader: [

        // "attribute float size;",
        "attribute vec3 customColor;",

        "varying vec3 vColor;",

        "void main() {",

        "vColor = customColor;",
        "vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );",
        "gl_PointSize = 4.0;",
        "gl_Position = projectionMatrix * mvPosition;",

        "}"

    ].join( "\n" ),

    fragmentShader: [

        "precision highp float; ",
        // "uniform sampler2D texture;",

        "varying vec3 vColor;",

        "void main() {",

        "gl_FragColor = vec4( vColor, 1.0 );",
        // "gl_FragColor = gl_FragColor * texture2D( texture, gl_PointCoord );",

        "}"

    ].join( "\n" )

};
