/**
 * Created by Administrator on 2016/12/16.
 */
THREE.FlyControls = function ( object, domElement ) {

    var scope = this;

    this.enabled = false;
    this.object = object;
    domElement = ( domElement !== undefined ) ? domElement : document;

    this.movementSpeed = 1.0;
    this.rollSpeed = 0.25;//Math.PI / 24;//0.005;

    this.moveState = { up: 0, down: 0, left: 0, right: 0, forward: 0, back: 0, pitchUp: 0, pitchDown: 0, yawLeft: 0, yawRight: 0, rollLeft: 0, rollRight: 0 };
    this.moveVector = new THREE.Vector3( 0, 0, 0 );
    this.rotationVector = new THREE.Vector3( 0, 0, 0 );

    this.tmpQuaternion = new THREE.Quaternion();

    var clock = new THREE.Clock();
    var changeEvent = { type: 'change' };

    this.enabledControls = function(value){

        scope.enabled = value;
        if(value){

            domElement.addEventListener( 'mousedown', mousedown, false );
        }else {

            domElement.removeEventListener( 'mousewheel', onmousewheel );
            domElement.removeEventListener( 'MozMousePixelScroll', onmousewheel );
            domElement.removeEventListener( 'mousedown', mousedown );
            domElement.removeEventListener( 'mousemove', mousemove );
            domElement.removeEventListener( 'mouseup', mouseup );
        }
    };

    this.update = function( ) {

        var delta = clock.getDelta();

        var moveMult = delta * scope.movementSpeed;
        var rotMult = delta * scope.rollSpeed;

        scope.object.translateX( scope.moveVector.x * moveMult );
        scope.object.translateY( scope.moveVector.y * moveMult );
        scope.object.translateZ( scope.moveVector.z * moveMult );

        scope.tmpQuaternion.set( scope.rotationVector.x * rotMult, scope.rotationVector.y * rotMult, scope.rotationVector.z * rotMult, 1 ).normalize();
        scope.object.quaternion.multiply( scope.tmpQuaternion );

        // expose the rotation vector for convenience
        scope.object.rotation.setFromQuaternion( scope.object.quaternion, scope.object.rotation.order );

        scope.dispatchEvent( changeEvent );

        scope.moveState.yawLeft = scope.moveState.pitchDown = 0;
        updateRotationVector();
    };

    function updateMovementVector(){

        scope.moveVector.x = ( - scope.moveState.left    + scope.moveState.right );
        scope.moveVector.y = ( - scope.moveState.down    + scope.moveState.up );
        scope.moveVector.z = (-scope.moveState.forward+ scope.moveState.back);

    }
    function updateRotationVector() {

        scope.rotationVector.x = ( - scope.moveState.pitchDown + scope.moveState.pitchUp );
        scope.rotationVector.y = ( - scope.moveState.yawRight  + scope.moveState.yawLeft );
        scope.rotationVector.z = ( - scope.moveState.rollRight + scope.moveState.rollLeft );

    }

    var mouse = new THREE.Vector2();
    function mousedown( event ){

        if ( scope.enabled === false) return;

        event.preventDefault();
        event.stopPropagation();

        switch ( event.button ) {

            case 0: scope.moveState.forward = 1; break;
            case 2: scope.moveState.back = 1; break;

        }
        mouse.set( event.pageX, event.pageY );
        updateMovementVector();

        domElement.addEventListener( 'mousemove', mousemove, false );
        domElement.addEventListener( 'mouseup', mouseup, false );
        domElement.addEventListener( 'mousewheel', onmousewheel, false );
        domElement.addEventListener( 'MozMousePixelScroll', onmousewheel, false ); // firefox
    }
    function mouseup( event ) {

        scope.moveState.yawLeft = scope.moveState.pitchDown = 0;
        updateRotationVector();

        scope.moveState.forward = scope.moveState.back = 0;
        updateMovementVector();

        domElement.removeEventListener( 'mousemove', mousemove );
        domElement.removeEventListener( 'mouseup', mouseup );
        domElement.removeEventListener( 'mousewheel', onmousewheel );
        domElement.removeEventListener( 'MozMousePixelScroll', onmousewheel );

    }
    function mousemove( event ) {

        scope.moveState.yawLeft   =  (event.pageX - mouse.x)*0.25;
        scope.moveState.pitchDown =  -( event.pageY - mouse.y )*0.25;

        updateRotationVector();

        mouse.set( event.pageX, event.pageY );
    }

    function onmousewheel( event ) {

        if ( scope.enabled === false ) return;

        event.preventDefault();
        var delta = 0;

        if ( event.wheelDelta ) {

            // WebKit / Opera / Explorer 9
            delta = - event.wheelDelta;
        } else if ( event.detail ) {

            // Firefox
            delta = event.detail * 10;
        }

        if ( delta > 0 ) {
            scope.movementSpeed +=0.5;
        }else if ( delta < 0 ) {
            scope.movementSpeed = ((scope.movementSpeed-0.1)<0.0)?0.0:(scope.movementSpeed-0.1);
        }
console.log(scope.movementSpeed);
    }

};

THREE.FlyControls.prototype = Object.create( THREE.EventDispatcher.prototype );
THREE.FlyControls.prototype.constructor = THREE.FlyControls;